import React, { useState } from 'react';
import { X, ArrowRightLeft, QrCode, Check } from 'lucide-react';
import { InventoryItem } from '../../types';

interface BorrowModalProps {
  item: InventoryItem | null;
  isOpen: boolean;
  onClose: () => void;
  onConfirmBorrow: (itemId: string, borrowerName: string, projectName: string) => void;
}

export const BorrowModal: React.FC<BorrowModalProps> = ({
  item,
  isOpen,
  onClose,
  onConfirmBorrow,
}) => {
  const [borrowerName, setBorrowerName] = useState('Anas M.');
  const [projectName, setProjectName] = useState('RoboCup Atlas Rover');
  const [duration, setDuration] = useState('3 jours');

  if (!isOpen || !item) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!borrowerName.trim()) return;
    onConfirmBorrow(item.id, borrowerName.trim(), projectName.trim());
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/85 backdrop-blur-md">
      <div className="glass-panel w-full max-w-md rounded-3xl border border-[#FF6B00]/40 p-6 space-y-4 shadow-[0_0_35px_rgba(255,107,0,0.3)]">
        
        <button
          onClick={onClose}
          className="absolute top-4 right-4 p-2 rounded-xl bg-white/5 text-slate-400 hover:text-white"
        >
          <X className="w-5 h-5" />
        </button>

        <div className="flex items-center space-x-3">
          <div className="p-2.5 rounded-2xl bg-[#FF6B00]/20 text-[#FF6B00] border border-[#FF6B00]/30">
            <ArrowRightLeft className="w-6 h-6" />
          </div>
          <div>
            <h3 className="font-['Orbitron'] font-bold text-lg text-white">
              Emprunt de Matériel
            </h3>
            <p className="text-xs font-mono text-cyan-400">{item.sku}</p>
          </div>
        </div>

        <div className="p-3.5 rounded-2xl bg-black/50 border border-white/5 space-y-1 text-xs font-mono">
          <div className="text-white font-semibold text-sm">{item.name}</div>
          <div className="text-slate-400">Emplacement : {item.location}</div>
          <div className="text-emerald-400 font-medium">Stock disponible : {item.available} unités</div>
        </div>

        <form onSubmit={handleSubmit} className="space-y-3 pt-1">
          <div>
            <label className="block text-xs font-mono uppercase text-slate-400 mb-1">
              Nom de l'Emprunteur (Membre) *
            </label>
            <input
              type="text"
              required
              value={borrowerName}
              onChange={(e) => setBorrowerName(e.target.value)}
              placeholder="ex: Anas Mansouri"
              className="glass-input w-full px-3.5 py-2.5 rounded-xl text-xs font-mono text-white"
            />
          </div>

          <div>
            <label className="block text-xs font-mono uppercase text-slate-400 mb-1">
              Projet / Robot Assigné
            </label>
            <input
              type="text"
              value={projectName}
              onChange={(e) => setProjectName(e.target.value)}
              placeholder="ex: Atlas Rover 4WD"
              className="glass-input w-full px-3.5 py-2.5 rounded-xl text-xs font-mono text-white"
            />
          </div>

          <div>
            <label className="block text-xs font-mono uppercase text-slate-400 mb-1">
              Durée Estimée
            </label>
            <select
              value={duration}
              onChange={(e) => setDuration(e.target.value)}
              className="glass-input w-full px-3.5 py-2.5 rounded-xl text-xs font-mono text-slate-200 bg-[#070B14]"
            >
              <option value="1 session (Aujourd'hui)">1 session (Aujourd'hui)</option>
              <option value="3 jours">3 jours</option>
              <option value="1 semaine">1 semaine</option>
              <option value="Jusqu'à fin de compétition">Jusqu'à fin de compétition</option>
            </select>
          </div>

          <div className="pt-2 flex gap-3">
            <button
              type="submit"
              className="flex-1 py-3 rounded-xl bg-gradient-to-r from-[#FF6B00] to-amber-500 text-slate-950 font-['Orbitron'] font-bold text-xs uppercase tracking-wider hover:shadow-lg transition-all"
            >
              Valider Sortie & Générer Reçu
            </button>
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-3 rounded-xl bg-white/10 text-slate-300 font-mono text-xs hover:bg-white/20"
            >
              Annuler
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
