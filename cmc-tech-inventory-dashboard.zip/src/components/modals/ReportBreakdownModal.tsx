import React, { useState } from 'react';
import { X, AlertTriangle, Flame } from 'lucide-react';
import { InventoryItem } from '../../types';

interface ReportBreakdownModalProps {
  isOpen: boolean;
  onClose: () => void;
  inventory: InventoryItem[];
  onSubmitReport: (sku: string, severity: 'Critical' | 'Moderate' | 'Minor', desc: string, reporter: string) => void;
}

export const ReportBreakdownModal: React.FC<ReportBreakdownModalProps> = ({
  isOpen,
  onClose,
  inventory,
  onSubmitReport,
}) => {
  const [selectedSku, setSelectedSku] = useState(inventory[0]?.sku || '');
  const [severity, setSeverity] = useState<'Critical' | 'Moderate' | 'Minor'>('Critical');
  const [description, setDescription] = useState('');
  const [reporter, setReporter] = useState('Anas M.');

  if (!isOpen) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!description.trim()) return;
    onSubmitReport(selectedSku, severity, description.trim(), reporter.trim());
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/85 backdrop-blur-md">
      <div className="glass-panel w-full max-w-lg rounded-3xl border border-rose-500/40 p-6 space-y-4 shadow-[0_0_35px_rgba(244,63,94,0.3)]">
        
        <button
          onClick={onClose}
          className="absolute top-4 right-4 p-2 rounded-xl bg-white/5 text-slate-400 hover:text-white"
        >
          <X className="w-5 h-5" />
        </button>

        <div className="flex items-center space-x-3">
          <div className="p-2.5 rounded-2xl bg-rose-500/20 text-rose-400 border border-rose-500/30">
            <AlertTriangle className="w-6 h-6" />
          </div>
          <div>
            <h3 className="font-['Orbitron'] font-bold text-lg text-white">
              Signalement de Panne Matériel
            </h3>
            <p className="text-xs font-mono text-slate-400">
              Notification envoyée immédiatement au Chef de Cellule Technique
            </p>
          </div>
        </div>

        <form onSubmit={handleSubmit} className="space-y-4 pt-1">
          <div>
            <label className="block text-xs font-mono uppercase text-slate-400 mb-1">
              Composant Endommagé *
            </label>
            <select
              value={selectedSku}
              onChange={(e) => setSelectedSku(e.target.value)}
              className="glass-input w-full px-3.5 py-2.5 rounded-xl text-xs font-mono text-slate-200 bg-[#070B14]"
            >
              {inventory.map((i) => (
                <option key={i.id} value={i.sku}>
                  {i.sku} — {i.name}
                </option>
              ))}
            </select>
          </div>

          <div>
            <label className="block text-xs font-mono uppercase text-slate-400 mb-1">
              Niveau de Gravité *
            </label>
            <div className="grid grid-cols-3 gap-2">
              {[
                { level: 'Minor', label: 'Mineur', color: 'text-amber-300 border-amber-500/40 bg-amber-500/10' },
                { level: 'Moderate', label: 'Modéré', color: 'text-orange-300 border-orange-500/40 bg-orange-500/10' },
                { level: 'Critical', label: 'Critique (Court-circuit/Fumée)', color: 'text-rose-400 border-rose-500/50 bg-rose-500/15' },
              ].map((s) => (
                <button
                  key={s.level}
                  type="button"
                  onClick={() => setSeverity(s.level as any)}
                  className={`p-2 rounded-xl text-xs font-mono border transition-all text-center ${
                    severity === s.level ? s.color + ' ring-1 ring-white/20' : 'bg-white/5 border-white/5 text-slate-400'
                  }`}
                >
                  {s.label}
                </button>
              ))}
            </div>
          </div>

          <div>
            <label className="block text-xs font-mono uppercase text-slate-400 mb-1">
              Symptômes observés & Circonstances *
            </label>
            <textarea
              required
              rows={3}
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              placeholder="ex: Surchauffe anormale après connexion en 12V, driver moteur bloqué, odeur de brûlé..."
              className="glass-input w-full px-3.5 py-2.5 rounded-xl text-xs font-mono text-white placeholder-slate-500"
            />
          </div>

          <div>
            <label className="block text-xs font-mono uppercase text-slate-400 mb-1">
              Signalé par (Membre)
            </label>
            <input
              type="text"
              value={reporter}
              onChange={(e) => setReporter(e.target.value)}
              className="glass-input w-full px-3.5 py-2.5 rounded-xl text-xs font-mono text-white"
            />
          </div>

          <div className="pt-2 flex gap-3">
            <button
              type="submit"
              className="flex-1 py-3 rounded-xl bg-gradient-to-r from-rose-500 to-red-600 text-white font-['Orbitron'] font-bold text-xs uppercase tracking-wider hover:shadow-[0_0_20px_rgba(244,63,94,0.5)] transition-all"
            >
              Envoyer pour Triage Labo
            </button>
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-3 rounded-xl bg-white/10 text-slate-300 font-mono text-xs hover:bg-white/20"
            >
              Annuler
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
