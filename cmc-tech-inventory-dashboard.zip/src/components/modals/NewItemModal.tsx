import React, { useState } from 'react';
import { X, PlusCircle, Cpu } from 'lucide-react';
import { ComponentCategory, InventoryItem } from '../../types';

interface NewItemModalProps {
  isOpen: boolean;
  onClose: () => void;
  onAddItem: (item: Omit<InventoryItem, 'id'>) => void;
}

export const NewItemModal: React.FC<NewItemModalProps> = ({ isOpen, onClose, onAddItem }) => {
  const [name, setName] = useState('');
  const [category, setCategory] = useState<ComponentCategory>('Microcontrollers');
  const [stock, setStock] = useState<number>(5);
  const [location, setLocation] = useState('Tiroir A-04');
  const [specs, setSpecs] = useState('');
  const [voltage, setVoltage] = useState('3.3V / 5V');

  if (!isOpen) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim()) return;

    // Generate clean SKU
    const prefixMap: Record<ComponentCategory, string> = {
      Microcontrollers: 'MCU',
      Sensors: 'SNS',
      Actuators: 'ACT',
      Power: 'PWR',
      Communication: 'COM',
      'Lab Tools': 'TOOL',
      'Displays & Screens': 'DISP',
    };
    const prefix = prefixMap[category] || 'SKU';
    const randNum = Math.floor(1000 + Math.random() * 9000);
    const sku = `SKU-${prefix}-${randNum}`;

    onAddItem({
      sku,
      name: name.trim(),
      category,
      stock: Number(stock) || 1,
      available: Number(stock) || 1,
      status: 'AVAILABLE',
      location: location.trim() || 'Bay 04 Main Rack',
      specs: specs.trim() || 'Spécifications de laboratoire standard',
      voltage: voltage.trim(),
    });

    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/85 backdrop-blur-md">
      <div className="glass-panel w-full max-w-lg rounded-3xl border border-purple-500/40 p-6 relative overflow-hidden shadow-[0_0_35px_rgba(139,92,246,0.3)]">
        
        <button
          onClick={onClose}
          className="absolute top-4 right-4 p-2 rounded-xl bg-white/5 text-slate-400 hover:text-white"
        >
          <X className="w-5 h-5" />
        </button>

        <div className="flex items-center space-x-3 mb-5">
          <div className="p-2.5 rounded-2xl bg-purple-500/20 text-purple-300 border border-purple-500/30">
            <PlusCircle className="w-6 h-6" />
          </div>
          <div>
            <h3 className="font-['Orbitron'] font-bold text-lg text-white">
              Enregistrer Nouveau Composant
            </h3>
            <p className="text-xs font-mono text-slate-400">
              Génération automatique de SKU et allocation de tiroir
            </p>
          </div>
        </div>

        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <label className="block text-xs font-mono uppercase text-slate-400 mb-1.5">
              Désignation du Composant *
            </label>
            <input
              type="text"
              required
              value={name}
              onChange={(e) => setName(e.target.value)}
              placeholder="ex: Raspberry Pi 5 8GB RAM"
              className="glass-input w-full px-3.5 py-2.5 rounded-xl text-sm font-mono text-white placeholder-slate-500"
            />
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block text-xs font-mono uppercase text-slate-400 mb-1.5">
                Catégorie *
              </label>
              <select
                value={category}
                onChange={(e) => setCategory(e.target.value as ComponentCategory)}
                className="glass-input w-full px-3.5 py-2.5 rounded-xl text-xs font-mono text-slate-200 bg-[#070B14]"
              >
                <option value="Microcontrollers">Microcontrollers</option>
                <option value="Sensors">Sensors</option>
                <option value="Actuators">Actuators</option>
                <option value="Power">Power & Batteries</option>
                <option value="Communication">Communication</option>
                <option value="Lab Tools">Lab Tools</option>
              </select>
            </div>

            <div>
              <label className="block text-xs font-mono uppercase text-slate-400 mb-1.5">
                Quantité Initiale *
              </label>
              <input
                type="number"
                min="1"
                required
                value={stock}
                onChange={(e) => setStock(Number(e.target.value))}
                className="glass-input w-full px-3.5 py-2.5 rounded-xl text-sm font-mono text-white"
              />
            </div>
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block text-xs font-mono uppercase text-slate-400 mb-1.5">
                Tiroir / Emplacement
              </label>
              <input
                type="text"
                value={location}
                onChange={(e) => setLocation(e.target.value)}
                placeholder="Tiroir A-04"
                className="glass-input w-full px-3.5 py-2.5 rounded-xl text-sm font-mono text-white"
              />
            </div>

            <div>
              <label className="block text-xs font-mono uppercase text-slate-400 mb-1.5">
                Tension de Fonctionnement
              </label>
              <input
                type="text"
                value={voltage}
                onChange={(e) => setVoltage(e.target.value)}
                placeholder="3.3V / 5V"
                className="glass-input w-full px-3.5 py-2.5 rounded-xl text-sm font-mono text-white"
              />
            </div>
          </div>

          <div>
            <label className="block text-xs font-mono uppercase text-slate-400 mb-1.5">
              Spécifications Clés
            </label>
            <input
              type="text"
              value={specs}
              onChange={(e) => setSpecs(e.target.value)}
              placeholder="ex: Dual-Core 240MHz, 8MB Flash, Wi-Fi 6"
              className="glass-input w-full px-3.5 py-2.5 rounded-xl text-xs font-mono text-white"
            />
          </div>

          <div className="pt-2 flex gap-3">
            <button
              type="submit"
              className="flex-1 py-3 rounded-xl bg-gradient-to-r from-purple-500 to-indigo-600 text-white font-['Orbitron'] font-bold text-xs uppercase tracking-wider hover:shadow-[0_0_20px_rgba(139,92,246,0.5)] transition-all"
            >
              Enregistrer & Générer QR Tag
            </button>
            <button
              type="button"
              onClick={onClose}
              className="px-5 py-3 rounded-xl bg-white/10 hover:bg-white/20 text-white text-xs font-mono"
            >
              Annuler
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
