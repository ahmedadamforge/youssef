import React, { useState, useEffect, useRef } from 'react';
import { 
  X, 
  QrCode, 
  Camera, 
  Scan, 
  CheckCircle, 
  Zap, 
  ArrowRightLeft, 
  RotateCcw,
  RefreshCw,
  VideoOff
} from 'lucide-react';
import { InventoryItem } from '../../types';

interface QRScannerModalProps {
  isOpen: boolean;
  onClose: () => void;
  inventory: InventoryItem[];
  onOpenBorrow: (item: InventoryItem) => void;
  onReturnItem: (itemId: string) => void;
  onTestOnBench: (item: InventoryItem) => void;
}

export const QRScannerModal: React.FC<QRScannerModalProps> = ({
  isOpen,
  onClose,
  inventory,
  onOpenBorrow,
  onReturnItem,
  onTestOnBench,
}) => {
  const [cameraActive, setCameraActive] = useState<boolean>(false);
  const [cameraError, setCameraError] = useState<string | null>(null);
  const [detectedItem, setDetectedItem] = useState<InventoryItem | null>(null);
  const videoRef = useRef<HTMLVideoElement | null>(null);
  const streamRef = useRef<MediaStream | null>(null);

  // Initialize camera when modal opens
  useEffect(() => {
    if (!isOpen) {
      stopCamera();
      setDetectedItem(null);
      return;
    }

    startCamera();

    return () => {
      stopCamera();
    };
  }, [isOpen]);

  const startCamera = async () => {
    setCameraError(null);
    try {
      if (!navigator.mediaDevices || !navigator.mediaDevices.getUserMedia) {
        setCameraError('Camera stream is not supported in this environment. Use simulated tag detection.');
        return;
      }

      const stream = await navigator.mediaDevices.getUserMedia({
        video: { facingMode: 'environment', width: { ideal: 640 }, height: { ideal: 480 } },
      });

      streamRef.current = stream;
      if (videoRef.current) {
        videoRef.current.srcObject = stream;
      }
      setCameraActive(true);
    } catch (err: any) {
      setCameraError('Accès caméra non autorisé ou caméra indisponible. Vous pouvez utiliser la détection simulée ci-dessous.');
      setCameraActive(false);
    }
  };

  const stopCamera = () => {
    if (streamRef.current) {
      streamRef.current.getTracks().forEach((track) => track.stop());
      streamRef.current = null;
    }
    setCameraActive(false);
  };

  const handleSimulateScan = (item: InventoryItem) => {
    setDetectedItem(item);
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/85 backdrop-blur-md">
      <div className="glass-panel w-full max-w-xl rounded-3xl border border-cyan-500/40 p-6 relative overflow-hidden shadow-[0_0_40px_rgba(0,242,254,0.3)] max-h-[90vh] overflow-y-auto">
        
        {/* Close Button */}
        <button
          onClick={onClose}
          className="absolute top-4 right-4 p-2 rounded-xl bg-white/5 text-slate-400 hover:text-white transition-colors"
        >
          <X className="w-5 h-5" />
        </button>

        {/* Header */}
        <div className="flex items-center space-x-3 mb-4">
          <div className="p-2.5 rounded-2xl bg-cyan-500/20 text-cyan-400 border border-cyan-500/30">
            <QrCode className="w-6 h-6" />
          </div>
          <div>
            <h3 className="font-['Orbitron'] font-bold text-lg text-white">
              Scanner Optique de QR Tags
            </h3>
            <p className="text-xs font-mono text-slate-400">
              Pointez la caméra vers l'étiquette QR d'un tiroir ou composant
            </p>
          </div>
        </div>

        {/* Viewport Frame */}
        <div className="relative w-full h-64 sm:h-72 rounded-2xl bg-black border border-white/15 overflow-hidden flex flex-col items-center justify-center">
          <div className="absolute inset-0 opacity-20 tech-grid pointer-events-none" />

          {/* Real Camera Stream */}
          {cameraActive ? (
            <video
              ref={videoRef}
              autoPlay
              playsInline
              muted
              className="w-full h-full object-cover"
            />
          ) : (
            <div className="text-center p-4 text-slate-500 font-mono text-xs space-y-2">
              <Camera className="w-10 h-10 mx-auto text-slate-600 opacity-60" />
              <p>{cameraError || 'Initialisation du flux caméra...'}</p>
            </div>
          )}

          {/* Laser Sweep Line */}
          <div className="laser-beam absolute left-0 right-0 h-1 bg-gradient-to-r from-transparent via-cyan-400 to-transparent shadow-[0_0_15px_rgba(0,242,254,0.9)] z-10 pointer-events-none" />

          {/* Target Reticle */}
          <div className="absolute w-44 h-44 border-2 border-dashed border-cyan-400/50 rounded-2xl flex flex-col items-center justify-center pointer-events-none">
            <span className="absolute -top-2 -left-2 w-6 h-6 border-t-4 border-l-4 border-cyan-400" />
            <span className="absolute -top-2 -right-2 w-6 h-6 border-t-4 border-r-4 border-cyan-400" />
            <span className="absolute -bottom-2 -left-2 w-6 h-6 border-b-4 border-l-4 border-cyan-400" />
            <span className="absolute -bottom-2 -right-2 w-6 h-6 border-b-4 border-r-4 border-cyan-400" />
            
            <Scan className="w-12 h-12 text-white/30 animate-pulse" />
            <span className="font-mono text-[10px] text-cyan-300 mt-2 bg-black/70 px-2 py-0.5 rounded">
              ALIGNER QR CODE
            </span>
          </div>

          <div className="absolute bottom-2 text-center text-[10px] font-mono text-slate-400 bg-black/60 px-3 py-1 rounded-full">
            Auto-Focus : ON • Décodage : Code128 / QR Matrix
          </div>
        </div>

        {/* Quick Simulated Tag Detectors */}
        <div className="mt-4 space-y-2">
          <div className="flex items-center justify-between text-[11px] font-mono text-slate-400">
            <span>Détection instantanée (Simulation) :</span>
            <span className="text-cyan-400">Cliquez pour tester</span>
          </div>
          <div className="grid grid-cols-3 gap-2">
            {inventory.slice(0, 3).map((item) => (
              <button
                key={item.id}
                onClick={() => handleSimulateScan(item)}
                className="p-2 rounded-xl bg-white/5 hover:bg-[#FF6B00]/20 border border-white/10 hover:border-[#FF6B00]/50 text-left text-[11px] font-mono transition-colors"
              >
                <div className="font-bold text-white truncate">{item.name}</div>
                <div className="text-slate-400 text-[10px]">{item.sku}</div>
              </button>
            ))}
          </div>
        </div>

        {/* Detection Result Card */}
        {detectedItem && (
          <div className="mt-4 p-4 rounded-2xl bg-cyan-950/40 border border-cyan-500/40 space-y-3 animate-in fade-in zoom-in duration-200">
            <div className="flex items-center justify-between">
              <div className="flex items-center space-x-2">
                <CheckCircle className="w-5 h-5 text-emerald-400" />
                <span className="font-['Orbitron'] font-bold text-sm text-white">
                  Composant Détecté !
                </span>
              </div>
              <span className="text-xs font-mono px-2 py-0.5 rounded bg-cyan-400/20 text-cyan-300">
                {detectedItem.sku}
              </span>
            </div>

            <div className="text-xs font-mono text-slate-300 space-y-1">
              <div className="text-white font-semibold text-sm">{detectedItem.name}</div>
              <div className="text-slate-400">
                Localisation : <strong className="text-slate-200">{detectedItem.location}</strong>
              </div>
              <div className="text-slate-400">
                Stock disponible :{' '}
                <strong className={detectedItem.available > 0 ? 'text-emerald-400' : 'text-rose-400'}>
                  {detectedItem.available} / {detectedItem.stock} unités
                </strong>
              </div>
              {detectedItem.borrower && (
                <div className="text-amber-400">
                  Actuellement emprunté par : {detectedItem.borrower}
                </div>
              )}
            </div>

            {/* Actions for detected component */}
            <div className="pt-2 flex flex-wrap gap-2">
              <button
                onClick={() => {
                  onClose();
                  onOpenBorrow(detectedItem);
                }}
                disabled={detectedItem.available === 0}
                className="flex-1 py-2 px-3 rounded-xl bg-gradient-to-r from-[#FF6B00] to-amber-500 text-slate-950 font-['Orbitron'] font-bold text-xs uppercase tracking-wider flex items-center justify-center space-x-1.5 disabled:opacity-40"
              >
                <ArrowRightLeft className="w-3.5 h-3.5" />
                <span>Emprunter</span>
              </button>

              {detectedItem.available < detectedItem.stock && (
                <button
                  onClick={() => {
                    onReturnItem(detectedItem.id);
                    setDetectedItem(null);
                  }}
                  className="py-2 px-3 rounded-xl bg-emerald-500/20 border border-emerald-500/40 text-emerald-300 font-mono text-xs flex items-center space-x-1"
                >
                  <RotateCcw className="w-3.5 h-3.5" />
                  <span>Restituer</span>
                </button>
              )}

              <button
                onClick={() => {
                  onClose();
                  onTestOnBench(detectedItem);
                }}
                className="py-2 px-3 rounded-xl bg-cyan-500/20 border border-cyan-500/40 text-cyan-300 font-mono text-xs flex items-center space-x-1"
              >
                <Zap className="w-3.5 h-3.5" />
                <span>Banc de Test</span>
              </button>
            </div>
          </div>
        )}

      </div>
    </div>
  );
};
