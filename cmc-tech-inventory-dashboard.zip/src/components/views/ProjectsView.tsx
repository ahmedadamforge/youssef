import React, { useState } from 'react';
import { 
  Bot, 
  ShieldCheck, 
  ExternalLink, 
  Cpu, 
  Battery, 
  Layers, 
  Users, 
  Compass, 
  X,
  Radio,
  FileCode2
} from 'lucide-react';
import { ProjectBot } from '../../types';

interface ProjectsViewProps {
  projects: ProjectBot[];
}

export const ProjectsView: React.FC<ProjectsViewProps> = ({ projects }) => {
  const [selectedCategory, setSelectedCategory] = useState<string>('ALL');
  const [activeModalProject, setActiveModalProject] = useState<ProjectBot | null>(null);

  const categories = ['ALL', 'ROVER', 'COMBAT', 'BIONIC', 'DRONE'];

  const filteredProjects = selectedCategory === 'ALL'
    ? projects
    : projects.filter((p) => p.category === selectedCategory);

  return (
    <div className="space-y-6">
      
      {/* Top Banner */}
      <div className="p-6 rounded-3xl glass-panel border border-white/10 flex flex-col md:flex-row md:items-center justify-between gap-4 shadow-xl">
        <div>
          <div className="flex items-center space-x-2 text-xs font-mono text-[#FF6B00] mb-1">
            <span className="w-2 h-2 rounded-full bg-[#FF6B00]" />
            <span className="uppercase tracking-wider font-semibold">CELLULE TECHNIQUE SHOWCASE</span>
          </div>
          <h1 className="font-['Orbitron'] font-black text-2xl sm:text-3xl text-white">
            ROBOTS & PROJECT LAB
          </h1>
          <p className="text-xs text-slate-400 font-mono mt-0.5">
            Machines de compétition et prototypes robotiques conçus à la Cité des Métiers et des Compétences
          </p>
        </div>

        {/* Filter Tabs */}
        <div className="flex items-center space-x-1.5 bg-black/40 p-1 rounded-xl border border-white/10 text-xs font-mono">
          {categories.map((cat) => (
            <button
              key={cat}
              onClick={() => setSelectedCategory(cat)}
              className={`px-3 py-1.5 rounded-lg transition-colors ${
                selectedCategory === cat
                  ? 'bg-[#FF6B00] text-slate-950 font-bold'
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              {cat}
            </button>
          ))}
        </div>
      </div>

      {/* Projects Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {filteredProjects.map((project) => (
          <div
            key={project.id}
            className="glass-panel rounded-3xl p-6 border border-white/10 flex flex-col justify-between hover:border-[#00F2FE]/40 transition-all group relative overflow-hidden"
          >
            <div className="space-y-4">
              {/* Card Header */}
              <div className="flex items-center justify-between">
                <span className="text-[11px] font-mono px-2.5 py-0.5 rounded-full bg-cyan-500/15 text-cyan-300 border border-cyan-500/30 font-semibold">
                  {project.categoryLabel}
                </span>

                <span className={`text-xs font-mono px-2 py-0.5 rounded ${
                  project.status === 'National Winner' 
                    ? 'bg-amber-500/15 text-amber-300 border border-amber-500/30 font-bold' 
                    : project.status === 'Competition Ready'
                    ? 'bg-emerald-500/15 text-emerald-300 border border-emerald-500/30'
                    : 'bg-purple-500/15 text-purple-300 border border-purple-500/30'
                }`}>
                  {project.status}
                </span>
              </div>

              {/* Title & Description */}
              <div>
                <h2 className="font-['Orbitron'] font-black text-xl text-white group-hover:text-cyan-300 transition-colors">
                  {project.title}
                </h2>
                <p className="text-xs text-slate-300 mt-2 leading-relaxed">
                  {project.description}
                </p>
              </div>

              {/* Hardware Blueprint Specifications */}
              <div className="p-4 rounded-2xl bg-black/50 border border-white/5 space-y-2 text-xs font-mono">
                <div className="text-[10px] text-slate-500 uppercase tracking-wider font-bold">
                  Blueprint Spécifications
                </div>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-[11px]">
                  <div>
                    <span className="text-cyan-400">Compute:</span>{' '}
                    <span className="text-slate-200">{project.specs.compute}</span>
                  </div>
                  <div>
                    <span className="text-cyan-400">Actionneurs:</span>{' '}
                    <span className="text-slate-200">{project.specs.actuation}</span>
                  </div>
                  <div>
                    <span className="text-[#FF6B00]">Batterie:</span>{' '}
                    <span className="text-slate-200">{project.specs.power}</span>
                  </div>
                  <div>
                    <span className="text-[#FF6B00]">Poids / Dim:</span>{' '}
                    <span className="text-slate-200">{project.specs.weight}</span>
                  </div>
                </div>
              </div>

              {/* Tags */}
              <div className="flex flex-wrap gap-1.5 pt-1">
                {project.tags.map((tag, idx) => (
                  <span
                    key={idx}
                    className="text-[10px] font-mono px-2 py-0.5 rounded-md bg-white/5 border border-white/5 text-slate-300"
                  >
                    #{tag}
                  </span>
                ))}
              </div>
            </div>

            {/* Bottom Actions */}
            <div className="mt-6 pt-4 border-t border-white/10 flex items-center justify-between text-xs font-mono">
              <span className="text-slate-400">
                Lead : <strong className="text-white">{project.lead}</strong>
              </span>

              <button
                onClick={() => setActiveModalProject(project)}
                className="flex items-center space-x-1.5 px-3 py-1.5 rounded-xl bg-cyan-500/15 hover:bg-cyan-500/25 border border-cyan-500/40 text-cyan-300 hover:text-white transition-colors"
              >
                <span>Dossier Technique</span>
                <ExternalLink className="w-3.5 h-3.5" />
              </button>
            </div>
          </div>
        ))}
      </div>

      {/* Engineering Blueprint Modal */}
      {activeModalProject && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/85 backdrop-blur-md">
          <div className="glass-panel max-w-2xl w-full rounded-3xl border border-cyan-500/40 p-6 space-y-5 shadow-[0_0_35px_rgba(0,242,254,0.25)] relative max-h-[90vh] overflow-y-auto">
            
            <button
              onClick={() => setActiveModalProject(null)}
              className="absolute top-5 right-5 p-2 rounded-xl bg-white/5 text-slate-400 hover:text-white"
            >
              <X className="w-5 h-5" />
            </button>

            <div className="flex items-center space-x-3">
              <div className="p-2.5 rounded-2xl bg-cyan-500/20 text-cyan-400 border border-cyan-500/30">
                <Bot className="w-6 h-6" />
              </div>
              <div>
                <h3 className="font-['Orbitron'] font-bold text-xl text-white">
                  {activeModalProject.title}
                </h3>
                <p className="text-xs font-mono text-cyan-400">{activeModalProject.categoryLabel}</p>
              </div>
            </div>

            <p className="text-xs text-slate-300 leading-relaxed font-sans">
              {activeModalProject.description}
            </p>

            {/* Key Features */}
            <div className="space-y-2">
              <h4 className="font-['Orbitron'] font-bold text-xs text-slate-200 uppercase tracking-wider">
                Points Clés d'Ingénierie
              </h4>
              <ul className="space-y-1.5 text-xs font-mono text-slate-300">
                {activeModalProject.features.map((feat, i) => (
                  <li key={i} className="flex items-start space-x-2">
                    <span className="text-[#FF6B00]">▹</span>
                    <span>{feat}</span>
                  </li>
                ))}
              </ul>
            </div>

            {/* Team Members */}
            <div className="p-4 rounded-2xl bg-black/50 border border-white/5">
              <div className="text-[11px] font-mono text-slate-400 uppercase mb-2">Équipe Projet CMC</div>
              <div className="flex flex-wrap gap-2">
                {activeModalProject.team.map((member, idx) => (
                  <span
                    key={idx}
                    className="text-xs font-mono px-3 py-1 rounded-xl bg-white/5 border border-white/10 text-white"
                  >
                    {member}
                  </span>
                ))}
              </div>
            </div>

            {/* Firmware / CAD actions */}
            <div className="pt-2 flex flex-wrap gap-3">
              <button
                onClick={() => {
                  alert(`Téléchargement du dossier CAO / STEP pour ${activeModalProject.title} lancé !`);
                }}
                className="flex-1 py-2.5 rounded-xl bg-gradient-to-r from-cyan-400 to-blue-500 text-slate-950 font-['Orbitron'] font-bold text-xs uppercase tracking-wider hover:shadow-lg transition-all"
              >
                Télécharger Fichiers CAO (SolidWorks/Fusion)
              </button>

              <button
                onClick={() => {
                  alert(`Code source ROS2 / C++ pour ${activeModalProject.title} ouvert dans le dépôt Git CMC.`);
                }}
                className="px-4 py-2.5 rounded-xl bg-white/10 hover:bg-white/20 text-white font-mono text-xs transition-colors"
              >
                Code Firmware Git
              </button>
            </div>
          </div>
        </div>
      )}

    </div>
  );
};
