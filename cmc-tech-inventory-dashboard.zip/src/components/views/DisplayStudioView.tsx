import React, { useState, useEffect } from 'react';
import { 
  Tv, 
  Cpu, 
  Zap, 
  Sliders, 
  RotateCcw, 
  Copy, 
  Check, 
  Play, 
  Eye, 
  Sparkles, 
  Code2, 
  Battery, 
  Radio, 
  Layers,
  Terminal,
  Grid
} from 'lucide-react';
import { VirtualDisplayType } from '../../types';

interface DisplayStudioViewProps {
  onSendCommand?: (cmd: string) => void;
  isSerialConnected?: boolean;
}

export const DisplayStudioView: React.FC<DisplayStudioViewProps> = ({
  onSendCommand,
  isSerialConnected = false,
}) => {
  const [displayType, setDisplayType] = useState<VirtualDisplayType>('OLED_SSD1306');

  // OLED SSD1306 State
  const [oledLine1, setOledLine1] = useState('CMC ROBOTIQUE');
  const [oledLine2, setOledLine2] = useState('SYS: NOMINAL 100%');
  const [oledLine3, setOledLine3] = useState('DIST: 24.8 CM [OK]');
  const [oledLine4, setOledLine4] = useState('IP: 192.168.4.1');
  const [oledInverted, setOledInverted] = useState(false);
  const [oledShowGrid, setOledShowGrid] = useState(true);
  const [oledContrast, setOledContrast] = useState(100);

  // LCD 1602 State
  const [lcdLine1, setLcdLine1] = useState('ROBOTICS.MA LAB');
  const [lcdLine2, setLcdLine2] = useState('CELLULE OK 16:42');
  const [lcdTheme, setLcdTheme] = useState<'blue' | 'green' | 'amber'>('blue');
  const [lcdBacklight, setLcdBacklight] = useState(true);

  // 7-Segment State
  const [sevenSegVal, setSevenSegVal] = useState('1642');
  const [showColon, setShowColon] = useState(true);

  // 8x8 LED Matrix State (64 boolean pixels)
  const defaultRobotFace = [
    0, 1, 1, 0, 0, 1, 1, 0,
    0, 1, 1, 0, 0, 1, 1, 0,
    0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 1, 1, 1, 1, 0, 0,
    0, 1, 0, 0, 0, 0, 1, 0,
    0, 1, 1, 1, 1, 1, 1, 0,
    0, 0, 0, 1, 1, 0, 0, 0,
    0, 0, 1, 0, 0, 1, 0, 0,
  ];
  const [ledMatrix, setLedMatrix] = useState<number[]>(defaultRobotFace);

  const [copiedCode, setCopiedCode] = useState(false);

  // Toggle colon blink every second for 7 segment
  useEffect(() => {
    const interval = setInterval(() => {
      setShowColon((prev) => !prev);
    }, 1000);
    return () => clearInterval(interval);
  }, []);

  const togglePixel = (index: number) => {
    setLedMatrix((prev) => {
      const next = [...prev];
      next[index] = next[index] === 1 ? 0 : 1;
      return next;
    });
  };

  const loadPreset = (presetName: string) => {
    if (presetName === 'nominal') {
      setOledLine1('CMC ROBOTIQUE');
      setOledLine2('SYS: NOMINAL 100%');
      setOledLine3('BATTERY: 15.8V 4S');
      setOledLine4('STATUS: READY');

      setLcdLine1('CMC ROBOTIQUE');
      setLcdLine2('SYSTEM: NOMINAL');
      setSevenSegVal('2026');
    } else if (presetName === 'telemetry') {
      setOledLine1('ATLAS ROVER 4WD');
      setOledLine2('LIDAR: 360 DEG');
      setOledLine3('DIST: 18.4 CM');
      setOledLine4('SPEED: 1.2 M/S');

      setLcdLine1('ATLAS ROVER 4WD');
      setLcdLine2('DIST: 18.4cm NAV');
      setSevenSegVal('1840');
    } else if (presetName === 'alarm') {
      setOledLine1('! ALERTE LABO !');
      setOledLine2('SURCHAUFFE DRV');
      setOledLine3('TEMP: 68.4 C');
      setOledLine4('ARRET D URGENCE');

      setLcdLine1('! ALERTE PANNE !');
      setLcdLine2('COURT-CIRCUIT');
      setSevenSegVal('9999');
    }
  };

  const sendToSerial = () => {
    if (!onSendCommand) return;

    if (displayType === 'OLED_SSD1306') {
      onSendCommand(`OLED:PRINT:"${oledLine1}","${oledLine2}"`);
    } else if (displayType === 'LCD_1602') {
      onSendCommand(`LCD:PRINT:"${lcdLine1}","${lcdLine2}"`);
    } else if (displayType === 'SEVEN_SEG') {
      onSendCommand(`7SEG:VAL:${sevenSegVal}`);
    } else {
      onSendCommand(`MATRIX:PATTERN:${ledMatrix.join('')}`);
    }
    alert(`✓ Signal d'affichage transmis au bus microcontrôleur (${displayType}) !`);
  };

  // Generate Arduino C++ code dynamically
  const generateArduinoCode = () => {
    if (displayType === 'OLED_SSD1306') {
      return `/*
 * CMC Robotique — Driver Écran OLED SSD1306 0.96" (I2C 0x3C)
 */
#include <Wire.h>
#include <Adafruit_GFX.h>
#include <Adafruit_SSD1306.h>

#define SCREEN_WIDTH 128
#define SCREEN_HEIGHT 64
Adafruit_SSD1306 display(SCREEN_WIDTH, SCREEN_HEIGHT, &Wire, -1);

void setup() {
  Wire.begin();
  if(!display.begin(SSD1306_SWITCHCAPVCC, 0x3C)) {
    for(;;); // Arrêt si écran non détecté
  }
  display.clearDisplay();
  display.setTextSize(1);
  display.setTextColor(${oledInverted ? 'BLACK, WHITE' : 'WHITE'});
  
  display.setCursor(0, 0);
  display.println(F("${oledLine1}"));
  display.setCursor(0, 16);
  display.println(F("${oledLine2}"));
  display.setCursor(0, 32);
  display.println(F("${oledLine3}"));
  display.setCursor(0, 48);
  display.println(F("${oledLine4}"));
  
  display.display();
}

void loop() {
  // Rafraîchissement périodique
}`;
    }

    if (displayType === 'LCD_1602') {
      return `/*
 * CMC Robotique — Driver Afficheur LCD 16x2 I2C (PCF8574 0x27)
 */
#include <Wire.h>
#include <LiquidCrystal_I2C.h>

LiquidCrystal_I2C lcd(0x27, 16, 2);

void setup() {
  lcd.init();
  lcd.backlight();
  
  lcd.setCursor(0, 0);
  lcd.print("${lcdLine1.slice(0, 16)}");
  
  lcd.setCursor(0, 1);
  lcd.print("${lcdLine2.slice(0, 16)}");
}

void loop() {
  // Code dynamique
}`;
    }

    if (displayType === 'SEVEN_SEG') {
      return `/*
 * CMC Robotique — Driver 7-Segments 4 Digits TM1637
 */
#include <TM1637Display.h>

#define CLK 2
#define DIO 3

TM1637Display display(CLK, DIO);

void setup() {
  display.setBrightness(0x0f);
  display.showNumberDecEx(${parseInt(sevenSegVal) || 1642}, 0b01000000, true);
}

void loop() {}`;
    }

    return `// Matrice LED 8x8 MAX7219
byte pattern[8] = {
  0b${ledMatrix.slice(0, 8).join('')},
  0b${ledMatrix.slice(8, 16).join('')},
  0b${ledMatrix.slice(16, 24).join('')},
  0b${ledMatrix.slice(24, 32).join('')},
  0b${ledMatrix.slice(32, 40).join('')},
  0b${ledMatrix.slice(40, 48).join('')},
  0b${ledMatrix.slice(48, 56).join('')},
  0b${ledMatrix.slice(56, 64).join('')}
};`;
  };

  const handleCopyCode = () => {
    navigator.clipboard.writeText(generateArduinoCode());
    setCopiedCode(true);
    setTimeout(() => setCopiedCode(false), 2000);
  };

  return (
    <div className="space-y-6">
      
      {/* Top Banner */}
      <div className="p-6 rounded-3xl glass-panel border border-white/10 flex flex-col md:flex-row md:items-center justify-between gap-4 shadow-xl">
        <div>
          <div className="flex items-center space-x-2 text-xs font-mono text-[#00F2FE] mb-1">
            <span className="w-2 h-2 rounded-full bg-[#00F2FE] animate-pulse" />
            <span className="uppercase tracking-wider font-semibold">LABORATOIRE D'AFFICHAGE & SIMULATEUR I2C/SPI</span>
          </div>
          <h1 className="font-['Orbitron'] font-black text-2xl sm:text-3xl text-white">
            VIRTUAL DISPLAY STUDIO
          </h1>
          <p className="text-xs text-slate-400 font-mono mt-0.5">
            Émulateur d'écrans physiques : OLED SSD1306 128x64, LCD 16x2 I2C, 7-Segments TM1637 & Matrice LED 8x8
          </p>
        </div>

        {/* Display Type Selector Buttons */}
        <div className="flex items-center space-x-1.5 bg-black/50 p-1.5 rounded-2xl border border-white/10 text-xs font-mono">
          {[
            { id: 'OLED_SSD1306', label: 'OLED 128x64' },
            { id: 'LCD_1602', label: 'LCD 16x2' },
            { id: 'SEVEN_SEG', label: '7-Segments' },
            { id: 'LED_MATRIX', label: 'Matrice 8x8' },
          ].map((item) => (
            <button
              key={item.id}
              onClick={() => setDisplayType(item.id as VirtualDisplayType)}
              className={`px-3 py-1.5 rounded-xl transition-all ${
                displayType === item.id
                  ? 'bg-gradient-to-r from-[#FF6B00] to-amber-500 text-slate-950 font-bold shadow-[0_0_15px_rgba(255,107,0,0.3)]'
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              {item.label}
            </button>
          ))}
        </div>
      </div>

      {/* Main Grid: Visual Hardware Screen & Controls */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
        
        {/* Left Column: Visual Screen Hardware Simulator (7 Cols) */}
        <div className="lg:col-span-7 glass-panel rounded-3xl border border-white/10 p-6 space-y-6 shadow-2xl relative overflow-hidden">
          
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-2">
              <Tv className="w-5 h-5 text-cyan-400" />
              <h2 className="font-['Orbitron'] font-bold text-sm text-white">
                {displayType === 'OLED_SSD1306' && 'ÉCRAN OLED SSD1306 0.96" (I2C 0x3C)'}
                {displayType === 'LCD_1602' && 'AFFICHEUR LCD 16x2 HD44780 (I2C 0x27)'}
                {displayType === 'SEVEN_SEG' && 'AFFICHEUR 4 DIGITS 7-SEGMENTS (TM1637)'}
                {displayType === 'LED_MATRIX' && 'MATRICE 64 LEDS 8x8 (MAX7219)'}
              </h2>
            </div>

            <div className="flex items-center space-x-2">
              <button
                onClick={sendToSerial}
                className="flex items-center space-x-1.5 px-3 py-1.5 rounded-xl bg-cyan-500/15 hover:bg-cyan-500/25 border border-cyan-500/40 text-cyan-300 text-xs font-mono transition-colors"
                title="Transmettre la trame au banc série"
              >
                <Zap className="w-3.5 h-3.5 text-cyan-400" />
                <span>Injecter au Banc</span>
              </button>
            </div>
          </div>

          {/* ======================================================== */}
          {/* HARDWARE SCREEN 1: OLED SSD1306 (128x64 Pixels) */}
          {/* ======================================================== */}
          {displayType === 'OLED_SSD1306' && (
            <div className="relative mx-auto max-w-lg p-5 rounded-3xl bg-gradient-to-b from-slate-900 via-black to-slate-950 border-2 border-slate-700 shadow-2xl">
              {/* Header PCB markings */}
              <div className="flex justify-between items-center text-[10px] font-mono text-slate-500 pb-2 border-b border-white/5">
                <span>GND · VCC · SCL · SDA</span>
                <span className="text-cyan-400 font-semibold">SSD1306 OLED 128x64</span>
              </div>

              {/* The OLED Glass Panel */}
              <div 
                className={`mt-3 w-full h-56 rounded-2xl p-4 font-mono transition-all duration-300 relative overflow-hidden flex flex-col justify-between border ${
                  oledInverted 
                    ? 'bg-[#00F2FE] text-black border-cyan-300 shadow-[0_0_35px_rgba(0,242,254,0.7)]' 
                    : 'bg-[#03060E] text-[#00F2FE] border-cyan-500/40 shadow-[0_0_35px_rgba(0,242,254,0.35)]'
                }`}
                style={{ opacity: oledContrast / 100 }}
              >
                {/* Subtle Pixel Grid overlay */}
                {oledShowGrid && (
                  <div className="absolute inset-0 opacity-15 pointer-events-none bg-[radial-gradient(#00F2FE_1px,transparent_1px)] [background-size:8px_8px]" />
                )}

                {/* Top Status Bar on OLED */}
                <div className="flex justify-between items-center text-[11px] pb-1 border-b border-current/20">
                  <span className="font-bold flex items-center space-x-1">
                    <Radio className="w-3 h-3 inline mr-1" />
                    <span>CMC_NODE_04</span>
                  </span>
                  <span className="flex items-center space-x-1">
                    <span>98%</span>
                    <Battery className="w-3.5 h-3.5 inline" />
                  </span>
                </div>

                {/* 4 Lines of Text */}
                <div className="space-y-1.5 my-auto text-xs sm:text-sm tracking-wide">
                  <div className="font-bold text-sm sm:text-base leading-tight break-all">
                    {oledLine1 || ' '}
                  </div>
                  <div className="opacity-90 leading-tight break-all">
                    {oledLine2 || ' '}
                  </div>
                  <div className="opacity-80 leading-tight break-all">
                    {oledLine3 || ' '}
                  </div>
                  <div className="opacity-70 text-[11px] leading-tight break-all">
                    {oledLine4 || ' '}
                  </div>
                </div>

                {/* Bottom Ticker bar on OLED */}
                <div className="flex justify-between items-center text-[10px] pt-1 border-t border-current/20 opacity-80">
                  <span>I2C: 0x3C</span>
                  <span>400 kHz SPEED</span>
                </div>
              </div>

              {/* Pins at bottom */}
              <div className="flex justify-center space-x-4 pt-3 text-[10px] font-mono text-slate-500">
                <span className="w-2 h-2 rounded-full bg-slate-600" />
                <span className="w-2 h-2 rounded-full bg-slate-600" />
                <span className="w-2 h-2 rounded-full bg-slate-600" />
                <span className="w-2 h-2 rounded-full bg-slate-600" />
              </div>
            </div>
          )}

          {/* ======================================================== */}
          {/* HARDWARE SCREEN 2: LCD 1602 (16x2 Characters) */}
          {/* ======================================================== */}
          {displayType === 'LCD_1602' && (
            <div className="relative mx-auto max-w-lg p-5 rounded-3xl bg-slate-900 border-2 border-slate-700 shadow-2xl">
              <div className="flex justify-between items-center text-[10px] font-mono text-slate-500 pb-2 border-b border-white/5">
                <span>I2C BACKPACK PCF8574</span>
                <span className="text-amber-400 font-semibold">LCD 1602 (HD44780)</span>
              </div>

              {/* Liquid Crystal Display Frame */}
              <div className="mt-3 p-4 rounded-2xl bg-black/90 border border-slate-700">
                <div 
                  className={`w-full h-36 rounded-xl p-4 font-mono transition-all duration-300 flex flex-col justify-center space-y-2 border ${
                    !lcdBacklight
                      ? 'bg-slate-950 text-slate-700 border-slate-800'
                      : lcdTheme === 'blue'
                      ? 'bg-[#002B7F] text-white border-blue-400 shadow-[0_0_30px_rgba(0,100,255,0.4)]'
                      : lcdTheme === 'green'
                      ? 'bg-[#153B15] text-[#76FF03] border-emerald-500 shadow-[0_0_30px_rgba(118,255,3,0.3)]'
                      : 'bg-[#3D2600] text-[#FFB300] border-amber-500 shadow-[0_0_30px_rgba(255,179,0,0.3)]'
                  }`}
                >
                  {/* Row 1 (16 chars) */}
                  <div className="text-sm sm:text-base font-bold tracking-[0.2em] uppercase select-none overflow-hidden whitespace-pre">
                    {lcdLine1.padEnd(16, ' ').slice(0, 16)}
                  </div>
                  {/* Row 2 (16 chars) */}
                  <div className="text-sm sm:text-base font-bold tracking-[0.2em] uppercase select-none overflow-hidden whitespace-pre">
                    {lcdLine2.padEnd(16, ' ').slice(0, 16)}
                  </div>
                </div>
              </div>

              {/* Bezel details */}
              <div className="flex justify-between items-center pt-3 text-[11px] font-mono text-slate-400">
                <span>Rétroéclairage : {lcdBacklight ? 'ON' : 'OFF'}</span>
                <span>Adresse I2C : 0x27</span>
              </div>
            </div>
          )}

          {/* ======================================================== */}
          {/* HARDWARE SCREEN 3: 4-DIGITS 7-SEGMENTS (TM1637) */}
          {/* ======================================================== */}
          {displayType === 'SEVEN_SEG' && (
            <div className="relative mx-auto max-w-lg p-6 rounded-3xl bg-slate-950 border-2 border-slate-800 shadow-2xl flex flex-col items-center">
              <div className="w-full flex justify-between items-center text-[10px] font-mono text-slate-500 pb-3 border-b border-white/5">
                <span>TM1637 4-DIGIT DISPLAY</span>
                <span className="text-rose-400 font-semibold">RED LED ARRAY</span>
              </div>

              {/* Glowing 7-Segment Tube */}
              <div className="my-6 px-8 py-5 rounded-2xl bg-black border border-rose-950 flex items-center justify-center space-x-3 shadow-[0_0_35px_rgba(244,63,94,0.3)]">
                {sevenSegVal.slice(0, 2).padEnd(2, '0').split('').map((char, i) => (
                  <span key={i} className="text-5xl sm:text-6xl font-['Orbitron'] font-black text-rose-500 drop-shadow-[0_0_12px_rgba(244,63,94,0.9)] tabular-nums">
                    {char}
                  </span>
                ))}

                {/* Colon */}
                <span className={`text-4xl sm:text-5xl font-['Orbitron'] font-black text-rose-500 transition-opacity ${showColon ? 'opacity-100' : 'opacity-20'}`}>
                  :
                </span>

                {sevenSegVal.slice(2, 4).padEnd(2, '0').split('').map((char, i) => (
                  <span key={i} className="text-5xl sm:text-6xl font-['Orbitron'] font-black text-rose-500 drop-shadow-[0_0_12px_rgba(244,63,94,0.9)] tabular-nums">
                    {char}
                  </span>
                ))}
              </div>

              <div className="text-xs font-mono text-slate-400">
                Luminosité : 100% · Vitesse de rafraîchissement : 50 Hz
              </div>
            </div>
          )}

          {/* ======================================================== */}
          {/* HARDWARE SCREEN 4: 8x8 LED MATRIX (MAX7219) */}
          {/* ======================================================== */}
          {displayType === 'LED_MATRIX' && (
            <div className="relative mx-auto max-w-lg p-6 rounded-3xl bg-slate-950 border-2 border-slate-800 shadow-2xl flex flex-col items-center">
              <div className="w-full flex justify-between items-center text-[10px] font-mono text-slate-500 pb-3 border-b border-white/5">
                <span>MAX7219 MATRIX 8x8</span>
                <span className="text-amber-400 font-semibold">64 RED LEDS (INTERACTIVE)</span>
              </div>

              {/* 8x8 Interactive Grid */}
              <div className="my-5 p-4 rounded-2xl bg-black border border-white/10 grid grid-cols-8 gap-2 shadow-[0_0_30px_rgba(255,107,0,0.25)]">
                {ledMatrix.map((val, idx) => (
                  <button
                    key={idx}
                    onClick={() => togglePixel(idx)}
                    className={`w-6 h-6 sm:w-7 sm:h-7 rounded-full border transition-all ${
                      val === 1
                        ? 'bg-[#FF6B00] border-amber-300 shadow-[0_0_12px_rgba(255,107,0,0.9)] scale-105'
                        : 'bg-slate-900 border-white/10 hover:border-white/30'
                    }`}
                  />
                ))}
              </div>

              <div className="flex items-center space-x-3 text-xs font-mono text-slate-400">
                <button
                  onClick={() => setLedMatrix(new Array(64).fill(0))}
                  className="px-3 py-1 rounded-lg bg-white/5 hover:bg-white/10 text-slate-300"
                >
                  Effacer
                </button>
                <button
                  onClick={() => setLedMatrix(defaultRobotFace)}
                  className="px-3 py-1 rounded-lg bg-white/5 hover:bg-white/10 text-cyan-400"
                >
                  Tête Robot
                </button>
                <button
                  onClick={() => setLedMatrix(new Array(64).fill(1))}
                  className="px-3 py-1 rounded-lg bg-white/5 hover:bg-white/10 text-slate-300"
                >
                  Tout Allumer
                </button>
              </div>
            </div>
          )}

          {/* Quick Presets Bar */}
          <div className="flex items-center space-x-2 pt-2 border-t border-white/10 overflow-x-auto text-xs font-mono">
            <span className="text-slate-500">Presets :</span>
            <button
              onClick={() => loadPreset('nominal')}
              className="px-3 py-1 rounded-xl bg-white/5 hover:bg-emerald-500/20 hover:text-emerald-300 border border-white/10 transition-colors whitespace-nowrap"
            >
              Système Nominal
            </button>
            <button
              onClick={() => loadPreset('telemetry')}
              className="px-3 py-1 rounded-xl bg-white/5 hover:bg-cyan-500/20 hover:text-cyan-300 border border-white/10 transition-colors whitespace-nowrap"
            >
              Télémétrie Rover
            </button>
            <button
              onClick={() => loadPreset('alarm')}
              className="px-3 py-1 rounded-xl bg-white/5 hover:bg-rose-500/20 hover:text-rose-300 border border-white/10 transition-colors whitespace-nowrap"
            >
              Alerte Panne
            </button>
          </div>

        </div>

        {/* Right Column: Parameters, Text Editor & Arduino Code (5 Cols) */}
        <div className="lg:col-span-5 space-y-6">
          
          {/* Display Controls Form */}
          <div className="glass-panel rounded-3xl border border-white/10 p-6 space-y-4">
            <h3 className="font-['Orbitron'] font-bold text-xs uppercase tracking-wider text-white flex items-center space-x-2">
              <Sliders className="w-4 h-4 text-[#FF6B00]" />
              <span>Contrôle & Configuration des Lignes</span>
            </h3>

            {/* OLED Controls */}
            {displayType === 'OLED_SSD1306' && (
              <div className="space-y-3">
                <div>
                  <label className="block text-[11px] font-mono text-slate-400 mb-1">Ligne 1 (Titre)</label>
                  <input
                    type="text"
                    value={oledLine1}
                    onChange={(e) => setOledLine1(e.target.value)}
                    className="glass-input w-full px-3 py-2 rounded-xl text-xs font-mono text-white"
                  />
                </div>
                <div>
                  <label className="block text-[11px] font-mono text-slate-400 mb-1">Ligne 2</label>
                  <input
                    type="text"
                    value={oledLine2}
                    onChange={(e) => setOledLine2(e.target.value)}
                    className="glass-input w-full px-3 py-2 rounded-xl text-xs font-mono text-white"
                  />
                </div>
                <div>
                  <label className="block text-[11px] font-mono text-slate-400 mb-1">Ligne 3</label>
                  <input
                    type="text"
                    value={oledLine3}
                    onChange={(e) => setOledLine3(e.target.value)}
                    className="glass-input w-full px-3 py-2 rounded-xl text-xs font-mono text-white"
                  />
                </div>
                <div>
                  <label className="block text-[11px] font-mono text-slate-400 mb-1">Ligne 4</label>
                  <input
                    type="text"
                    value={oledLine4}
                    onChange={(e) => setOledLine4(e.target.value)}
                    className="glass-input w-full px-3 py-2 rounded-xl text-xs font-mono text-white"
                  />
                </div>

                <div className="pt-2 flex items-center justify-between text-xs font-mono">
                  <label className="flex items-center space-x-2 cursor-pointer">
                    <input
                      type="checkbox"
                      checked={oledInverted}
                      onChange={(e) => setOledInverted(e.target.checked)}
                      className="accent-cyan-400"
                    />
                    <span>Inverser l'affichage</span>
                  </label>

                  <label className="flex items-center space-x-2 cursor-pointer">
                    <input
                      type="checkbox"
                      checked={oledShowGrid}
                      onChange={(e) => setOledShowGrid(e.target.checked)}
                      className="accent-cyan-400"
                    />
                    <span>Grille pixels</span>
                  </label>
                </div>
              </div>
            )}

            {/* LCD Controls */}
            {displayType === 'LCD_1602' && (
              <div className="space-y-3">
                <div>
                  <label className="block text-[11px] font-mono text-slate-400 mb-1">
                    Ligne 1 (Max 16 caractères)
                  </label>
                  <input
                    type="text"
                    maxLength={16}
                    value={lcdLine1}
                    onChange={(e) => setLcdLine1(e.target.value)}
                    className="glass-input w-full px-3 py-2 rounded-xl text-xs font-mono text-white"
                  />
                </div>
                <div>
                  <label className="block text-[11px] font-mono text-slate-400 mb-1">
                    Ligne 2 (Max 16 caractères)
                  </label>
                  <input
                    type="text"
                    maxLength={16}
                    value={lcdLine2}
                    onChange={(e) => setLcdLine2(e.target.value)}
                    className="glass-input w-full px-3 py-2 rounded-xl text-xs font-mono text-white"
                  />
                </div>

                <div className="pt-2">
                  <label className="block text-[11px] font-mono text-slate-400 mb-1">Thème de rétroéclairage</label>
                  <div className="grid grid-cols-3 gap-2">
                    {[
                      { id: 'blue', label: 'Bleu / Blanc' },
                      { id: 'green', label: 'Vert / Noir' },
                      { id: 'amber', label: 'Ambre / Noir' },
                    ].map((t) => (
                      <button
                        key={t.id}
                        onClick={() => setLcdTheme(t.id as any)}
                        className={`py-1.5 rounded-xl text-xs font-mono border transition-all ${
                          lcdTheme === t.id
                            ? 'bg-[#FF6B00] text-slate-950 font-bold border-[#FF6B00]'
                            : 'bg-white/5 border-white/10 text-slate-300'
                        }`}
                      >
                        {t.label}
                      </button>
                    ))}
                  </div>
                </div>

                <div className="pt-2 flex items-center justify-between text-xs font-mono">
                  <label className="flex items-center space-x-2 cursor-pointer">
                    <input
                      type="checkbox"
                      checked={lcdBacklight}
                      onChange={(e) => setLcdBacklight(e.target.checked)}
                      className="accent-[#FF6B00]"
                    />
                    <span>Activer Rétroéclairage</span>
                  </label>
                </div>
              </div>
            )}

            {/* 7-Segment Controls */}
            {displayType === 'SEVEN_SEG' && (
              <div className="space-y-3">
                <div>
                  <label className="block text-[11px] font-mono text-slate-400 mb-1">
                    Valeur des 4 Digits (Nombre ou Texte)
                  </label>
                  <input
                    type="text"
                    maxLength={4}
                    value={sevenSegVal}
                    onChange={(e) => setSevenSegVal(e.target.value)}
                    className="glass-input w-full px-3 py-2 rounded-xl text-xs font-mono text-white"
                  />
                </div>
                <div className="flex gap-2">
                  {['1642', '2026', '2480', '8888'].map((v) => (
                    <button
                      key={v}
                      onClick={() => setSevenSegVal(v)}
                      className="flex-1 py-1 rounded-xl bg-white/5 hover:bg-white/10 text-xs font-mono text-cyan-400 border border-white/10"
                    >
                      {v}
                    </button>
                  ))}
                </div>
              </div>
            )}

            {/* Button to send to Web Serial */}
            <button
              onClick={sendToSerial}
              className="w-full mt-2 py-3 rounded-2xl bg-gradient-to-r from-[#FF6B00] to-amber-500 text-slate-950 font-['Orbitron'] font-bold text-xs uppercase tracking-wider hover:shadow-[0_0_20px_rgba(255,107,0,0.4)] transition-all flex items-center justify-center space-x-2"
            >
              <Zap className="w-4 h-4 fill-slate-950" />
              <span>Transmettre à l'Arduino / ESP32</span>
            </button>
          </div>

          {/* Generated Arduino Code Snippet */}
          <div className="glass-panel rounded-3xl border border-white/10 p-6 space-y-3">
            <div className="flex items-center justify-between pb-2 border-b border-white/10">
              <div className="flex items-center space-x-2 text-xs font-mono text-slate-300">
                <Code2 className="w-4 h-4 text-cyan-400" />
                <span>Code Arduino C++ Prêt à Flasher</span>
              </div>
              <button
                onClick={handleCopyCode}
                className="flex items-center space-x-1 px-2.5 py-1 rounded-lg bg-white/10 hover:bg-white/20 text-[11px] font-mono text-slate-200 transition-colors"
              >
                {copiedCode ? <Check className="w-3 h-3 text-emerald-400" /> : <Copy className="w-3 h-3" />}
                <span>{copiedCode ? 'Copié !' : 'Copier'}</span>
              </button>
            </div>

            <div className="bg-black/80 rounded-2xl p-3 font-mono text-[11px] overflow-x-auto max-h-48 text-slate-300 leading-relaxed">
              <pre>
                <code>{generateArduinoCode()}</code>
              </pre>
            </div>
          </div>

        </div>

      </div>

    </div>
  );
};
