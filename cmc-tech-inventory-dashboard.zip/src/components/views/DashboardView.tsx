import React, { useState } from 'react';
import { 
  Boxes, 
  Radio, 
  CheckCircle2, 
  Flame, 
  QrCode, 
  PlusCircle, 
  AlertTriangle, 
  Terminal, 
  Camera, 
  ExternalLink, 
  Cpu, 
  Scan, 
  Zap, 
  ArrowRight,
  Tv
} from 'lucide-react';
import { InventoryItem, SerialLogMessage } from '../../types';

interface DashboardViewProps {
  inventory: InventoryItem[];
  onOpenScanner: () => void;
  onOpenNewItem: () => void;
  onOpenBreakdown: () => void;
  onNavigateTab: (tab: string) => void;
  onInspectItem: (item: InventoryItem) => void;
  terminalLogs: SerialLogMessage[];
}

export const DashboardView: React.FC<DashboardViewProps> = ({
  inventory,
  onOpenScanner,
  onOpenNewItem,
  onOpenBreakdown,
  onNavigateTab,
  onInspectItem,
  terminalLogs,
}) => {
  const [filterCategory, setFilterCategory] = useState<string>('All');

  // Compute live stats
  const totalItems = inventory.reduce((acc, curr) => acc + curr.stock, 0);
  const totalAvailable = inventory.reduce((acc, curr) => acc + curr.available, 0);
  const totalInUse = totalItems - totalAvailable;
  const totalDamaged = inventory.filter((i) => i.status === 'FAULTY' || i.status === 'MAINTENANCE').length;

  const filteredItems = filterCategory === 'All'
    ? inventory
    : inventory.filter((item) => item.category.toLowerCase().includes(filterCategory.toLowerCase()));

  return (
    <div className="space-y-6">
      
      {/* ======================================================== */}
      {/* 1. HERO BANNER & QUICK ACTION LAUNCHERS */}
      {/* ======================================================== */}
      <div className="p-5 sm:p-7 rounded-3xl glass-panel relative overflow-hidden bg-gradient-to-r from-[#0B1528] via-[#091122] to-[#120D1D] shadow-2xl">
        <div className="absolute -right-12 -top-12 w-64 h-64 bg-[#FF6B00]/10 rounded-full blur-3xl pointer-events-none" />
        <div className="absolute -left-12 -bottom-12 w-64 h-64 bg-[#00F2FE]/10 rounded-full blur-3xl pointer-events-none" />

        <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-6 relative z-10">
          <div>
            <div className="flex items-center space-x-2 text-xs font-mono text-[#FF6B00] mb-2">
              <span className="w-2 h-2 rounded-full bg-[#FF6B00] animate-pulse" />
              <span className="tracking-widest uppercase font-semibold">Bay 04 • Workshop Cellule Technique</span>
              <span className="text-slate-500">·</span>
              <span className="text-slate-400">Terminal Node CMC-RABAT</span>
            </div>
            <h1 className="font-['Orbitron'] font-black text-2xl sm:text-3xl text-white tracking-wide">
              HARDWARE MATRIX & BENCHMARK
            </h1>
            <p className="text-xs sm:text-sm text-slate-300 mt-1.5 max-w-2xl leading-relaxed">
              Plateforme unifiée de la Cellule Technique CMC Robotique. Gestion autonome des composants, banc de test série Web Serial et préparation aux compétitions nationales.
            </p>
          </div>

          {/* Quick Action Buttons */}
          <div className="flex flex-wrap items-center gap-3 shrink-0">
            <button
              onClick={onOpenScanner}
              className="flex items-center space-x-2 px-4 py-2.5 rounded-xl bg-gradient-to-r from-[#FF6B00] to-amber-500 text-slate-950 font-['Orbitron'] font-bold text-xs uppercase tracking-wider hover:shadow-[0_0_20px_rgba(255,107,0,0.5)] active:scale-95 transition-all"
            >
              <QrCode className="w-4 h-4 text-slate-950" />
              <span>Scan QR Code</span>
            </button>

            <button
              onClick={() => onNavigateTab('circuit-tester')}
              className="flex items-center space-x-2 px-4 py-2.5 rounded-xl bg-cyan-500/15 border border-cyan-400/40 text-cyan-300 hover:text-white hover:bg-cyan-500/25 text-xs font-['Orbitron'] tracking-wider uppercase transition-all"
            >
              <Zap className="w-4 h-4 text-cyan-400" />
              <span>Circuit Tester</span>
            </button>

            <button
              onClick={() => onNavigateTab('affichage')}
              className="flex items-center space-x-2 px-4 py-2.5 rounded-xl bg-purple-500/15 border border-purple-500/40 text-purple-300 hover:text-white hover:bg-purple-500/25 text-xs font-['Orbitron'] tracking-wider uppercase transition-all"
            >
              <Tv className="w-4 h-4 text-purple-400" />
              <span>Affichage & Écrans</span>
            </button>

            <button
              onClick={onOpenNewItem}
              className="flex items-center space-x-2 px-4 py-2.5 rounded-xl glass-panel border border-white/10 text-slate-300 hover:text-white hover:border-white/30 text-xs font-['Orbitron'] tracking-wider uppercase transition-all"
            >
              <PlusCircle className="w-4 h-4 text-slate-400" />
              <span>New Item</span>
            </button>

            <button
              onClick={onOpenBreakdown}
              className="flex items-center space-x-2 px-3.5 py-2.5 rounded-xl glass-panel border border-rose-500/30 text-rose-300 hover:text-white hover:border-rose-400 text-xs font-['Orbitron'] tracking-wider uppercase transition-all"
            >
              <AlertTriangle className="w-4 h-4 text-rose-400" />
              <span className="hidden sm:inline">Report Breakdown</span>
            </button>
          </div>
        </div>
      </div>

      {/* ======================================================== */}
      {/* 2. STAT CARDS (4 Grid Columns) */}
      {/* ======================================================== */}
      <section className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        
        {/* Card 1: Total Electronic Units */}
        <div className="glass-panel rounded-2xl p-5 relative overflow-hidden group hover:-translate-y-0.5 transition-all">
          <div className="flex items-center justify-between mb-3">
            <span className="text-xs font-mono uppercase tracking-wider text-slate-400">Total Units</span>
            <div className="p-2 rounded-xl bg-[#00F2FE]/10 text-cyan-400 border border-cyan-500/20">
              <Boxes className="w-4 h-4" />
            </div>
          </div>
          <div className="flex items-baseline space-x-2 mb-2">
            <span className="font-['Orbitron'] font-bold text-3xl text-white tabular-nums">{totalItems}</span>
            <span className="text-xs font-mono text-emerald-400 font-medium">12 SKUs catalogués</span>
          </div>
          <div className="space-y-1.5">
            <div className="w-full bg-slate-800 rounded-full h-1.5 overflow-hidden">
              <div className="bg-gradient-to-r from-cyan-400 to-blue-500 h-1.5 rounded-full" style={{ width: '84%' }} />
            </div>
            <div className="flex justify-between text-[11px] font-mono text-slate-400">
              <span>Capacité Tiroirs</span>
              <span>84%</span>
            </div>
          </div>
        </div>

        {/* Card 2: Items In Active Projects */}
        <div className="glass-panel rounded-2xl p-5 relative overflow-hidden group hover:-translate-y-0.5 transition-all">
          <div className="flex items-center justify-between mb-3">
            <span className="text-xs font-mono uppercase tracking-wider text-slate-400">Active In Projects</span>
            <div className="p-2 rounded-xl bg-[#FF6B00]/10 text-[#FF6B00] border border-[#FF6B00]/20">
              <Radio className="w-4 h-4" />
            </div>
          </div>
          <div className="flex items-baseline space-x-2 mb-2">
            <span className="font-['Orbitron'] font-bold text-3xl text-[#FF6B00] tabular-nums">{totalInUse}</span>
            <span className="text-xs font-mono text-slate-400 font-medium">Sur 4 Robots</span>
          </div>
          <div className="space-y-1.5">
            <div className="w-full bg-slate-800 rounded-full h-1.5 overflow-hidden">
              <div 
                className="bg-gradient-to-r from-[#FF6B00] to-amber-400 h-1.5 rounded-full" 
                style={{ width: `${Math.round((totalInUse / totalItems) * 100)}%` }} 
              />
            </div>
            <div className="flex justify-between text-[11px] font-mono text-slate-400">
              <span>Taux d'Emprunt</span>
              <span>{Math.round((totalInUse / totalItems) * 100)}%</span>
            </div>
          </div>
        </div>

        {/* Card 3: Items in Stock */}
        <div className="glass-panel rounded-2xl p-5 relative overflow-hidden group hover:-translate-y-0.5 transition-all">
          <div className="flex items-center justify-between mb-3">
            <span className="text-xs font-mono uppercase tracking-wider text-slate-400">Available In Stock</span>
            <div className="p-2 rounded-xl bg-emerald-500/10 text-emerald-400 border border-emerald-500/20">
              <CheckCircle2 className="w-4 h-4" />
            </div>
          </div>
          <div className="flex items-baseline space-x-2 mb-2">
            <span className="font-['Orbitron'] font-bold text-3xl text-emerald-400 tabular-nums">{totalAvailable}</span>
            <span className="text-xs font-mono text-slate-400 font-medium">Prêts</span>
          </div>
          <div className="space-y-1.5">
            <div className="w-full bg-slate-800 rounded-full h-1.5 overflow-hidden">
              <div 
                className="bg-gradient-to-r from-emerald-500 to-teal-400 h-1.5 rounded-full" 
                style={{ width: `${Math.round((totalAvailable / totalItems) * 100)}%` }} 
              />
            </div>
            <div className="flex justify-between text-[11px] font-mono text-slate-400">
              <span>Disponibilité Lab</span>
              <span>{Math.round((totalAvailable / totalItems) * 100)}%</span>
            </div>
          </div>
        </div>

        {/* Card 4: Breakdown Alerts */}
        <div className="glass-panel rounded-2xl p-5 border-rose-500/20 relative overflow-hidden group hover:-translate-y-0.5 transition-all bg-gradient-to-b from-rose-500/[0.04] to-transparent">
          <div className="flex items-center justify-between mb-3">
            <span className="text-xs font-mono uppercase tracking-wider text-rose-400 font-semibold">Breakdown Alerts</span>
            <div className="p-2 rounded-xl bg-rose-500/15 text-rose-400 border border-rose-500/30">
              <Flame className="w-4 h-4 animate-pulse" />
            </div>
          </div>
          <div className="flex items-baseline space-x-2 mb-2">
            <span className="font-['Orbitron'] font-bold text-3xl text-rose-400 tabular-nums">{totalDamaged}</span>
            <span className="text-xs font-mono text-rose-300 font-medium">1 Critique</span>
          </div>
          <div className="space-y-1.5">
            <div className="w-full bg-slate-800 rounded-full h-1.5 overflow-hidden">
              <div className="bg-gradient-to-r from-rose-500 to-red-600 h-1.5 rounded-full" style={{ width: '25%' }} />
            </div>
            <div className="flex justify-between text-[11px] font-mono text-slate-400">
              <span>Statut Réparation</span>
              <span className="text-rose-400">Triage en cours</span>
            </div>
          </div>
        </div>

      </section>

      {/* ======================================================== */}
      {/* 3. CORE SPLIT: HARDWARE ACTIVITY TABLE & SCANNER WIDGET */}
      {/* ======================================================== */}
      <div className="grid grid-cols-1 xl:grid-cols-3 gap-6">
        
        {/* Table Column (Span 2) */}
        <div className="xl:col-span-2 glass-panel rounded-2xl border border-white/10 overflow-hidden flex flex-col justify-between">
          <div>
            {/* Header with Segmented Filter Buttons */}
            <div className="p-5 border-b border-white/10 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
              <div>
                <h2 className="font-['Orbitron'] font-bold text-base text-white tracking-wide">
                  Hardware Movement Registry
                </h2>
                <p className="text-xs text-slate-400 mt-0.5 font-mono">
                  Suivi des entrées, sorties et assignations des microcontrôleurs
                </p>
              </div>

              {/* Functional filter buttons */}
              <div className="flex items-center space-x-1 bg-black/40 p-1 rounded-xl border border-white/10 text-xs font-mono">
                {['All', 'Microcontrollers', 'Sensors', 'Actuators'].map((cat) => (
                  <button
                    key={cat}
                    onClick={() => setFilterCategory(cat)}
                    className={`px-3 py-1 rounded-lg transition-colors ${
                      filterCategory === cat
                        ? 'bg-[#FF6B00]/20 text-[#FF6B00] border border-[#FF6B00]/40 font-semibold'
                        : 'text-slate-400 hover:text-white'
                    }`}
                  >
                    {cat}
                  </button>
                ))}
              </div>
            </div>

            {/* Responsive Table */}
            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs sm:text-sm">
                <thead className="bg-black/40 border-b border-white/5 font-mono text-[11px] uppercase text-slate-400">
                  <tr>
                    <th className="py-3 px-4 font-semibold">Composant / SKU</th>
                    <th className="py-3 px-4 font-semibold hidden md:table-cell">Catégorie</th>
                    <th className="py-3 px-4 font-semibold">Lieu / Emprunteur</th>
                    <th className="py-3 px-4 font-semibold">Statut</th>
                    <th className="py-3 px-4 font-semibold text-right">Détails</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-white/5 text-slate-300 font-sans">
                  {filteredItems.slice(0, 6).map((item) => (
                    <tr key={item.id} className="hover:bg-white/[0.03] transition-colors group">
                      <td className="py-3.5 px-4">
                        <div className="flex items-center space-x-3">
                          <div className="w-8 h-8 rounded-lg bg-cyan-950/50 border border-cyan-800/40 flex items-center justify-center text-cyan-400 shrink-0">
                            <Cpu className="w-4 h-4" />
                          </div>
                          <div>
                            <div className="font-medium text-white group-hover:text-cyan-400 transition-colors">
                              {item.name}
                            </div>
                            <div className="font-mono text-[11px] text-slate-500">
                              {item.sku}
                            </div>
                          </div>
                        </div>
                      </td>
                      <td className="py-3.5 px-4 hidden md:table-cell font-mono text-xs text-slate-400">
                        {item.category}
                      </td>
                      <td className="py-3.5 px-4 font-mono text-xs text-slate-300">
                        {item.borrower ? (
                          <div className="flex items-center space-x-1.5 text-[#FF6B00]">
                            <span>{item.borrower}</span>
                            <span className="text-[10px] text-slate-500">({item.borrowedAt})</span>
                          </div>
                        ) : (
                          <span className="text-slate-400">{item.location}</span>
                        )}
                      </td>
                      <td className="py-3.5 px-4">
                        {item.status === 'AVAILABLE' && (
                          <span className="inline-flex items-center space-x-1.5 px-2.5 py-1 rounded-full text-[11px] font-mono bg-emerald-500/15 text-emerald-300 border border-emerald-500/30">
                            <span className="w-1.5 h-1.5 rounded-full bg-emerald-400" />
                            <span>Available ({item.available})</span>
                          </span>
                        )}
                        {item.status === 'BORROWED' && (
                          <span className="inline-flex items-center space-x-1.5 px-2.5 py-1 rounded-full text-[11px] font-mono bg-amber-500/15 text-amber-300 border border-amber-500/30">
                            <span className="w-1.5 h-1.5 rounded-full bg-amber-400" />
                            <span>Borrowed</span>
                          </span>
                        )}
                        {item.status === 'FAULTY' && (
                          <span className="inline-flex items-center space-x-1.5 px-2.5 py-1 rounded-full text-[11px] font-mono bg-rose-500/15 text-rose-400 border border-rose-500/30">
                            <span className="w-1.5 h-1.5 rounded-full bg-rose-500 animate-ping" />
                            <span>Damaged</span>
                          </span>
                        )}
                        {item.status === 'MAINTENANCE' && (
                          <span className="inline-flex items-center space-x-1.5 px-2.5 py-1 rounded-full text-[11px] font-mono bg-blue-500/15 text-blue-300 border border-blue-500/30">
                            <span>Maintenance</span>
                          </span>
                        )}
                      </td>
                      <td className="py-3.5 px-4 text-right">
                        <button
                          onClick={() => onInspectItem(item)}
                          className="p-1.5 rounded-lg hover:bg-white/10 text-slate-400 hover:text-white transition-colors"
                          title="Inspect Component"
                        >
                          <ExternalLink className="w-4 h-4" />
                        </button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>

          {/* Table Footer */}
          <div className="p-4 border-t border-white/5 flex items-center justify-between text-xs font-mono text-slate-400 bg-black/20">
            <span>Affichage de {filteredItems.length} composants</span>
            <button
              onClick={() => onNavigateTab('inventory')}
              className="text-[#FF6B00] hover:underline flex items-center space-x-1"
            >
              <span>Accéder à la matrice complète</span>
              <ArrowRight className="w-3.5 h-3.5" />
            </button>
          </div>
        </div>

        {/* Right Widgets: Scanner Telemetry & Terminal Stream */}
        <div className="space-y-6">
          
          {/* Optical QR Scanner Viewport */}
          <div className="glass-panel rounded-2xl p-5 relative overflow-hidden">
            <div className="flex items-center justify-between mb-4">
              <h3 className="font-['Orbitron'] font-bold text-sm text-white flex items-center space-x-2">
                <Camera className="w-4 h-4 text-cyan-400" />
                <span>Camera QR Station</span>
              </h3>
              <span className="text-[10px] font-mono text-cyan-400 bg-cyan-950/80 px-2 py-0.5 rounded border border-cyan-700">
                LENS READY
              </span>
            </div>

            <div
              onClick={onOpenScanner}
              className="relative w-full h-44 rounded-xl bg-slate-950 border border-cyan-500/30 overflow-hidden flex flex-col items-center justify-center group cursor-pointer"
            >
              <div className="absolute inset-0 opacity-20 tech-grid" />
              <div className="laser-beam absolute left-0 right-0 h-0.5 bg-gradient-to-r from-transparent via-cyan-400 to-transparent shadow-[0_0_12px_rgba(0,242,254,0.8)]" />

              <div className="relative w-24 h-24 border border-cyan-400/40 rounded-xl flex items-center justify-center">
                <span className="absolute -top-1 -left-1 w-3 h-3 border-t-2 border-l-2 border-cyan-400" />
                <span className="absolute -top-1 -right-1 w-3 h-3 border-t-2 border-r-2 border-cyan-400" />
                <span className="absolute -bottom-1 -left-1 w-3 h-3 border-b-2 border-l-2 border-cyan-400" />
                <span className="absolute -bottom-1 -right-1 w-3 h-3 border-b-2 border-r-2 border-cyan-400" />
                <Scan className="w-8 h-8 text-cyan-400/60 group-hover:scale-110 transition-transform" />
              </div>

              <div className="absolute bottom-2 text-center text-[10px] font-mono text-slate-400 group-hover:text-cyan-400 transition-colors">
                Cliquez pour activer le scanner optique
              </div>
            </div>
          </div>

          {/* Terminal Logs Stream */}
          <div className="glass-panel rounded-2xl p-5 font-mono text-xs">
            <div className="flex items-center justify-between mb-3">
              <h3 className="font-['Orbitron'] font-bold text-xs text-white tracking-wider flex items-center space-x-2">
                <Terminal className="w-3.5 h-3.5 text-purple-400" />
                <span>TERMINAL LOGS // STREAM</span>
              </h3>
              <button 
                onClick={() => onNavigateTab('circuit-tester')}
                className="text-[10px] text-cyan-400 hover:underline"
              >
                Open Bench &gt;
              </button>
            </div>

            <div className="space-y-1.5 bg-black/60 p-3 rounded-xl border border-white/5 text-[11px] leading-relaxed text-slate-300 max-h-48 overflow-y-auto">
              {terminalLogs.length === 0 ? (
                <div className="text-slate-500 py-3 text-center">
                  Aucun log récent. Ouvrez le banc de test série.
                </div>
              ) : (
                terminalLogs.slice(-6).map((log) => (
                  <p key={log.id} className="break-all">
                    <span className="text-cyan-400">[{log.timestamp}]</span>{' '}
                    {log.type === 'TX' && <span className="text-purple-400 font-bold">TX&gt; </span>}
                    {log.type === 'RX' && <span className="text-cyan-300 font-bold">&lt;RX </span>}
                    {log.type === 'SYS' && <span className="text-amber-400 font-bold">SYS: </span>}
                    <span className={log.data.includes('ERR') || log.data.includes('FAULT') ? 'text-rose-400' : 'text-slate-300'}>
                      {log.data}
                    </span>
                  </p>
                ))
              )}
            </div>
          </div>

        </div>

      </div>

    </div>
  );
};
