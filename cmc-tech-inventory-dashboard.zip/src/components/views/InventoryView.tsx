import React, { useState } from 'react';
import { 
  Search, 
  Plus, 
  AlertTriangle, 
  Cpu, 
  MapPin, 
  Zap, 
  CheckCircle, 
  ArrowRightLeft, 
  RotateCcw,
  SlidersHorizontal
} from 'lucide-react';
import { InventoryItem, ComponentCategory } from '../../types';

interface InventoryViewProps {
  inventory: InventoryItem[];
  onOpenNewItem: () => void;
  onOpenBreakdown: () => void;
  onOpenBorrow: (item: InventoryItem) => void;
  onReturnItem: (itemId: string) => void;
  onTestOnBench: (item: InventoryItem) => void;
}

export const InventoryView: React.FC<InventoryViewProps> = ({
  inventory,
  onOpenNewItem,
  onOpenBreakdown,
  onOpenBorrow,
  onReturnItem,
  onTestOnBench,
}) => {
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState<string>('All');
  const [selectedStatus, setSelectedStatus] = useState<string>('All');

  const categories = [
    'All',
    'Microcontrollers',
    'Sensors',
    'Actuators',
    'Power',
    'Communication',
    'Lab Tools',
  ];

  const filteredItems = inventory.filter((item) => {
    const matchesSearch = 
      item.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      item.sku.toLowerCase().includes(searchQuery.toLowerCase()) ||
      (item.specs && item.specs.toLowerCase().includes(searchQuery.toLowerCase())) ||
      item.location.toLowerCase().includes(searchQuery.toLowerCase());

    const matchesCategory = selectedCategory === 'All' || item.category === selectedCategory;
    const matchesStatus = selectedStatus === 'All' || item.status === selectedStatus;

    return matchesSearch && matchesCategory && matchesStatus;
  });

  return (
    <div className="space-y-6">
      
      {/* Top Controls Header */}
      <div className="p-6 rounded-3xl glass-panel border border-white/10 flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center space-x-2 text-xs font-mono text-[#FF6B00] mb-1">
            <span className="w-2 h-2 rounded-full bg-[#FF6B00]" />
            <span className="uppercase tracking-wider font-semibold">MATRICE LOGISTIQUE CMC</span>
          </div>
          <h1 className="font-['Orbitron'] font-black text-2xl text-white">
            ELECTRONIC COMPONENTS MATRIX
          </h1>
          <p className="text-xs text-slate-400 font-mono mt-0.5">
            Inventaire en temps réel des tiroirs de prototypage de la Cellule Technique
          </p>
        </div>

        {/* Action Buttons */}
        <div className="flex items-center gap-3">
          <button
            onClick={onOpenNewItem}
            className="flex items-center space-x-2 px-4 py-2.5 rounded-xl bg-gradient-to-r from-[#FF6B00] to-amber-500 text-slate-950 font-['Orbitron'] font-bold text-xs uppercase tracking-wider hover:shadow-[0_0_20px_rgba(255,107,0,0.4)] active:scale-95 transition-all"
          >
            <Plus className="w-4 h-4 text-slate-950" />
            <span>Nouveau Composant</span>
          </button>

          <button
            onClick={onOpenBreakdown}
            className="flex items-center space-x-2 px-3.5 py-2.5 rounded-xl glass-panel border border-rose-500/30 text-rose-300 hover:text-white hover:border-rose-400 text-xs font-['Orbitron'] uppercase tracking-wider transition-all"
          >
            <AlertTriangle className="w-4 h-4 text-rose-400" />
            <span className="hidden sm:inline">Signaler Panne</span>
          </button>
        </div>
      </div>

      {/* Search & Filter Toolbar */}
      <div className="space-y-3">
        <div className="flex flex-col sm:flex-row items-stretch gap-3">
          {/* Search Input */}
          <div className="relative flex-1">
            <Search className="w-4 h-4 absolute left-3.5 top-1/2 -translate-y-1/2 text-slate-400" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Rechercher par désignation, SKU (#SKU-ESP...), spécification ou tiroir..."
              className="glass-input w-full pl-10 pr-4 py-2.5 rounded-xl text-xs sm:text-sm text-white placeholder-slate-500 font-mono"
            />
            {searchQuery && (
              <button 
                onClick={() => setSearchQuery('')}
                className="absolute right-3 top-1/2 -translate-y-1/2 text-xs font-mono text-slate-400 hover:text-white"
              >
                Effacer
              </button>
            )}
          </div>

          {/* Status Filter */}
          <div className="flex items-center space-x-1.5 shrink-0 bg-black/40 p-1 rounded-xl border border-white/10 text-xs font-mono">
            {['All', 'AVAILABLE', 'BORROWED', 'FAULTY'].map((st) => (
              <button
                key={st}
                onClick={() => setSelectedStatus(st)}
                className={`px-3 py-1.5 rounded-lg transition-colors ${
                  selectedStatus === st
                    ? 'bg-[#00F2FE]/20 text-cyan-300 border border-cyan-400/40 font-semibold'
                    : 'text-slate-400 hover:text-white'
                }`}
              >
                {st === 'All' ? 'Tous Statuts' : st}
              </button>
            ))}
          </div>
        </div>

        {/* Categories Bar */}
        <div className="flex items-center space-x-1.5 overflow-x-auto pb-1 text-xs font-mono">
          <span className="text-slate-500 text-[11px] pr-1 flex items-center">
            <SlidersHorizontal className="w-3.5 h-3.5 mr-1" /> Catégories:
          </span>
          {categories.map((cat) => (
            <button
              key={cat}
              onClick={() => setSelectedCategory(cat)}
              className={`px-3 py-1.5 rounded-xl whitespace-nowrap transition-all ${
                selectedCategory === cat
                  ? 'bg-[#FF6B00] text-slate-950 font-bold shadow-[0_0_15px_rgba(255,107,0,0.3)]'
                  : 'bg-white/5 border border-white/5 text-slate-300 hover:text-white hover:bg-white/10'
              }`}
            >
              {cat}
            </button>
          ))}
        </div>
      </div>

      {/* Grid of Components */}
      {filteredItems.length === 0 ? (
        <div className="p-12 text-center glass-panel rounded-3xl border border-white/10 space-y-3">
          <Cpu className="w-10 h-10 text-slate-600 mx-auto" />
          <h3 className="font-['Orbitron'] font-bold text-lg text-white">Aucun composant trouvé</h3>
          <p className="text-xs font-mono text-slate-400 max-w-sm mx-auto">
            Aucun résultat ne correspond à "{searchQuery}". Essayez une autre requête ou réinitialisez les filtres.
          </p>
          <button
            onClick={() => { setSearchQuery(''); setSelectedCategory('All'); setSelectedStatus('All'); }}
            className="px-4 py-2 rounded-xl bg-white/10 text-xs font-mono text-cyan-400 hover:bg-white/20"
          >
            Réinitialiser les filtres
          </button>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
          {filteredItems.map((item) => {
            const isOutOfStock = item.available === 0;
            const isDamaged = item.status === 'FAULTY';

            return (
              <div 
                key={item.id} 
                className="glass-panel rounded-2xl p-5 border border-white/10 flex flex-col justify-between hover:border-[#FF6B00]/40 transition-all group"
              >
                <div>
                  {/* Top Bar: SKU and Status Badge */}
                  <div className="flex items-center justify-between text-xs font-mono mb-2.5">
                    <span className="text-slate-400 font-semibold">{item.sku}</span>
                    
                    {item.status === 'AVAILABLE' && (
                      <span className="px-2 py-0.5 rounded-full bg-emerald-500/15 text-emerald-300 border border-emerald-500/30 flex items-center space-x-1">
                        <span className="w-1.5 h-1.5 rounded-full bg-emerald-400" />
                        <span>Disponible</span>
                      </span>
                    )}
                    {item.status === 'BORROWED' && (
                      <span className="px-2 py-0.5 rounded-full bg-amber-500/15 text-amber-300 border border-amber-500/30 flex items-center space-x-1">
                        <span className="w-1.5 h-1.5 rounded-full bg-amber-400" />
                        <span>Emprunté</span>
                      </span>
                    )}
                    {item.status === 'FAULTY' && (
                      <span className="px-2 py-0.5 rounded-full bg-rose-500/15 text-rose-300 border border-rose-500/30 flex items-center space-x-1">
                        <span className="w-1.5 h-1.5 rounded-full bg-rose-500 animate-ping" />
                        <span>En Panne</span>
                      </span>
                    )}
                    {item.status === 'MAINTENANCE' && (
                      <span className="px-2 py-0.5 rounded-full bg-blue-500/15 text-blue-300 border border-blue-500/30">
                        Maintenance
                      </span>
                    )}
                  </div>

                  {/* Component Title */}
                  <h3 className="font-['Orbitron'] font-bold text-white text-base group-hover:text-cyan-300 transition-colors">
                    {item.name}
                  </h3>

                  {/* Category & Specs */}
                  <div className="mt-2 text-xs font-mono text-slate-300 space-y-1">
                    <div className="text-cyan-400">{item.category}</div>
                    {item.specs && (
                      <p className="text-[11px] text-slate-400 line-clamp-2 leading-relaxed">
                        {item.specs}
                      </p>
                    )}
                  </div>

                  {/* Storage Location & Voltage */}
                  <div className="mt-3.5 pt-3 border-t border-white/5 flex items-center justify-between text-xs font-mono text-slate-400">
                    <span className="flex items-center space-x-1">
                      <MapPin className="w-3.5 h-3.5 text-[#FF6B00]" />
                      <span>{item.location}</span>
                    </span>
                    {item.voltage && (
                      <span className="text-amber-400 font-semibold">{item.voltage}</span>
                    )}
                  </div>

                  {/* Borrower info if currently in use */}
                  {item.borrower && (
                    <div className="mt-2 px-2.5 py-1.5 rounded-lg bg-black/40 border border-white/5 text-[11px] font-mono text-slate-300 flex items-center justify-between">
                      <span className="text-slate-400">Emprunté par :</span>
                      <span className="text-[#FF6B00] font-semibold">{item.borrower}</span>
                    </div>
                  )}

                  {/* Stock Bar */}
                  <div className="mt-3 space-y-1">
                    <div className="flex justify-between text-[11px] font-mono">
                      <span className="text-slate-500">Stock disponible:</span>
                      <span className={`font-bold ${item.available > 0 ? 'text-emerald-400' : 'text-rose-400'}`}>
                        {item.available} / {item.stock} unités
                      </span>
                    </div>
                    <div className="w-full bg-slate-800 rounded-full h-1.5 overflow-hidden">
                      <div 
                        className={`h-1.5 rounded-full ${
                          item.available > 0 ? 'bg-gradient-to-r from-emerald-500 to-cyan-400' : 'bg-rose-500'
                        }`} 
                        style={{ width: `${Math.round((item.available / item.stock) * 100)}%` }}
                      />
                    </div>
                  </div>
                </div>

                {/* Card Actions */}
                <div className="mt-5 pt-3 border-t border-white/10 flex items-center gap-2">
                  <button
                    disabled={isOutOfStock || isDamaged}
                    onClick={() => onOpenBorrow(item)}
                    className="flex-1 py-2 px-3 rounded-xl bg-gradient-to-r from-[#FF6B00] to-amber-500 hover:from-[#FF882E] hover:to-amber-400 text-slate-950 font-['Orbitron'] font-bold text-xs uppercase tracking-wider transition-all disabled:opacity-30 disabled:pointer-events-none flex items-center justify-center space-x-1.5"
                  >
                    <ArrowRightLeft className="w-3.5 h-3.5" />
                    <span>Emprunter</span>
                  </button>

                  {item.available < item.stock && (
                    <button
                      onClick={() => onReturnItem(item.id)}
                      title="Restituer 1 unité au tiroir"
                      className="p-2 rounded-xl bg-emerald-500/15 border border-emerald-500/30 text-emerald-300 hover:bg-emerald-500/25 transition-colors"
                    >
                      <RotateCcw className="w-3.5 h-3.5" />
                    </button>
                  )}

                  <button
                    onClick={() => onTestOnBench(item)}
                    title="Tester ce composant sur le banc série"
                    className="p-2 rounded-xl bg-cyan-500/15 border border-cyan-500/30 text-cyan-300 hover:bg-cyan-500/25 transition-colors"
                  >
                    <Zap className="w-3.5 h-3.5" />
                  </button>
                </div>
              </div>
            );
          })}
        </div>
      )}

    </div>
  );
};
