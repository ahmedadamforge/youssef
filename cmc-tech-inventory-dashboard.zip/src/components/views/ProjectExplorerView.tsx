import React, { useState } from 'react';
import { 
  FolderGit2, 
  FileCode, 
  Download, 
  Copy, 
  Check, 
  Terminal, 
  Folder, 
  FolderOpen, 
  File, 
  ChevronRight, 
  FileText,
  Smartphone,
  Globe,
  Cpu,
  Database
} from 'lucide-react';
import { MONOREPO_PROJECT_FILES } from '../../data/mockData';

export const ProjectExplorerView: React.FC = () => {
  const [selectedFilePath, setSelectedFilePath] = useState<string>('firmware/cmc_testbench_firmware.ino');
  const [copied, setCopied] = useState<boolean>(false);

  const selectedFile = MONOREPO_PROJECT_FILES.find((f) => f.path === selectedFilePath) || MONOREPO_PROJECT_FILES[0];

  const handleCopy = () => {
    navigator.clipboard.writeText(selectedFile.content);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handleDownloadFile = () => {
    const blob = new Blob([selectedFile.content], { type: 'text/plain;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = selectedFile.path.split('/').pop() || 'file.txt';
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  };

  const handleDownloadAllBundle = () => {
    // Generate combined bundle script or JSON
    const bundleText = MONOREPO_PROJECT_FILES.map(
      (f) => `// ========================================================\n// FILE: ${f.path}\n// DESC: ${f.description}\n// ========================================================\n\n${f.content}\n\n`
    ).join('\n');

    const blob = new Blob([bundleText], { type: 'text/plain;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'robotics-ma-monorepo-full-source.txt';
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
    alert('✓ Dossier complet du projet (Turborepo + Web + Mobile + Firmware + Supabase) téléchargé avec succès !');
  };

  return (
    <div className="space-y-6">
      
      {/* Top Banner */}
      <div className="p-6 rounded-3xl glass-panel border border-white/10 flex flex-col md:flex-row md:items-center justify-between gap-4 shadow-xl">
        <div>
          <div className="flex items-center space-x-2 text-xs font-mono text-[#FF6B00] mb-1">
            <span className="w-2 h-2 rounded-full bg-[#FF6B00]" />
            <span className="uppercase tracking-wider font-semibold">TURBOREPO MONOREPO STRUCTURE</span>
          </div>
          <h1 className="font-['Orbitron'] font-black text-2xl sm:text-3xl text-white">
            PROJECT CODE & DIRECTORY EXPORTER
          </h1>
          <p className="text-xs text-slate-400 font-mono mt-0.5">
            Dossier complet du projet : Web (Next.js 15), Mobile (Expo), Firmware Arduino C++ & Base de données Supabase
          </p>
        </div>

        <button
          onClick={handleDownloadAllBundle}
          className="flex items-center space-x-2 px-5 py-3 rounded-2xl bg-gradient-to-r from-[#FF6B00] to-amber-500 text-slate-950 font-['Orbitron'] font-bold text-xs uppercase tracking-wider hover:shadow-[0_0_25px_rgba(255,107,0,0.4)] active:scale-95 transition-all shrink-0"
        >
          <Download className="w-4 h-4 text-slate-950" />
          <span>Télécharger Tout le Projet</span>
        </button>
      </div>

      {/* Main Split: File Tree & Code Viewer */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
        
        {/* Left Column: File Tree (4 Cols) */}
        <div className="lg:col-span-4 glass-panel rounded-3xl border border-white/10 p-5 space-y-4">
          <div className="flex items-center justify-between pb-3 border-b border-white/10">
            <div className="text-xs font-mono text-slate-400 uppercase tracking-wider flex items-center space-x-1.5">
              <FolderGit2 className="w-4 h-4 text-[#FF6B00]" />
              <span>Arborescence des Fichiers</span>
            </div>
            <span className="text-[10px] font-mono text-cyan-400">pnpm workspace</span>
          </div>

          {/* Quick Categories */}
          <div className="space-y-1 font-mono text-xs">
            <div className="text-[11px] text-slate-500 uppercase tracking-widest pt-1 pb-1">
              Fichiers Clés du Projet
            </div>

            {MONOREPO_PROJECT_FILES.map((file) => {
              const isSelected = selectedFilePath === file.path;
              const isFirmware = file.path.includes('firmware');
              const isMobile = file.path.includes('mobile');
              const isWeb = file.path.includes('web');
              const isDb = file.path.includes('supabase');

              return (
                <button
                  key={file.path}
                  onClick={() => setSelectedFilePath(file.path)}
                  className={`w-full text-left p-2.5 rounded-xl transition-all flex items-center justify-between ${
                    isSelected
                      ? 'bg-[#FF6B00]/20 text-[#FF6B00] border border-[#FF6B00]/40 font-semibold'
                      : 'text-slate-300 hover:bg-white/5 hover:text-white'
                  }`}
                >
                  <div className="flex items-center space-x-2.5 truncate">
                    {isFirmware && <Cpu className="w-4 h-4 text-amber-400 shrink-0" />}
                    {isMobile && <Smartphone className="w-4 h-4 text-purple-400 shrink-0" />}
                    {isWeb && <Globe className="w-4 h-4 text-cyan-400 shrink-0" />}
                    {isDb && <Database className="w-4 h-4 text-emerald-400 shrink-0" />}
                    {!isFirmware && !isMobile && !isWeb && !isDb && <FileText className="w-4 h-4 text-slate-400 shrink-0" />}
                    <span className="truncate">{file.path}</span>
                  </div>
                  <ChevronRight className={`w-3.5 h-3.5 shrink-0 ${isSelected ? 'text-[#FF6B00]' : 'text-slate-600'}`} />
                </button>
              );
            })}
          </div>

          {/* Quick CLI Run Instructions */}
          <div className="p-4 rounded-2xl bg-black/60 border border-white/5 space-y-2 font-mono text-[11px]">
            <div className="text-slate-400 uppercase font-bold text-[10px]">Commandes de Démarrage</div>
            <div className="text-cyan-300">$ pnpm install</div>
            <div className="text-slate-300">$ pnpm dev:web <span className="text-slate-500"># Next.js port 3000</span></div>
            <div className="text-slate-300">$ pnpm dev:mobile <span className="text-slate-500"># Expo Go app</span></div>
          </div>
        </div>

        {/* Right Column: Code Viewer (8 Cols) */}
        <div className="lg:col-span-8 glass-panel rounded-3xl border border-white/10 p-6 space-y-4">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-3 border-b border-white/10">
            <div>
              <div className="flex items-center space-x-2">
                <FileCode className="w-4 h-4 text-[#FF6B00]" />
                <span className="font-mono font-bold text-sm text-white">
                  {selectedFile.path}
                </span>
              </div>
              <p className="text-xs font-mono text-slate-400 mt-0.5">
                {selectedFile.description}
              </p>
            </div>

            <div className="flex items-center space-x-2 shrink-0">
              <button
                onClick={handleCopy}
                className="flex items-center space-x-1.5 px-3 py-1.5 rounded-xl bg-white/5 hover:bg-white/10 text-xs font-mono text-slate-300 hover:text-white transition-colors"
              >
                {copied ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                <span>{copied ? 'Copié !' : 'Copier'}</span>
              </button>

              <button
                onClick={handleDownloadFile}
                className="flex items-center space-x-1.5 px-3 py-1.5 rounded-xl bg-cyan-500/15 border border-cyan-500/30 text-cyan-300 hover:bg-cyan-500/25 text-xs font-mono transition-colors"
              >
                <Download className="w-3.5 h-3.5" />
                <span>Télécharger</span>
              </button>
            </div>
          </div>

          {/* Syntax Code Box */}
          <div className="relative rounded-2xl bg-black/80 border border-white/5 p-4 font-mono text-xs overflow-x-auto max-h-[550px] leading-relaxed">
            <pre className="text-slate-200">
              <code>{selectedFile.content}</code>
            </pre>
          </div>
        </div>

      </div>

    </div>
  );
};
