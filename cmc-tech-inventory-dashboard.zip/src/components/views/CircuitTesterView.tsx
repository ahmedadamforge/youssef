import React, { useState, useEffect, useRef } from 'react';
import { 
  Terminal as TerminalIcon, 
  Cpu, 
  Zap, 
  WifiOff, 
  RefreshCw, 
  CheckCircle2, 
  XCircle, 
  Send, 
  Radio, 
  Activity, 
  AlertTriangle, 
  ShieldCheck, 
  Box, 
  Sliders, 
  Gauge,
  Play
} from 'lucide-react';
import { InventoryItem, SerialLogMessage } from '../../types';

type ComponentSuite = 'HC_SR04' | 'SERVO' | 'I2C_SCAN' | 'DIGITAL_PINS';
type HealthStatus = 'IDLE' | 'TESTING' | 'WORKING' | 'FAULTY';

interface CircuitTesterViewProps {
  isSupported: boolean;
  isConnected: boolean;
  isSimulated: boolean;
  portDetails: string | null;
  error: string | null;
  logs: SerialLogMessage[];
  connect: (baud: number) => Promise<void>;
  connectSimulation: (baud: number) => void;
  disconnect: () => Promise<void>;
  sendCommand: (cmd: string) => Promise<void>;
  clearLogs: () => void;
  inventory: InventoryItem[];
  selectedItemForTest?: InventoryItem | null;
}

export const CircuitTesterView: React.FC<CircuitTesterViewProps> = ({
  isSupported,
  isConnected,
  isSimulated,
  portDetails,
  error,
  logs,
  connect,
  connectSimulation,
  disconnect,
  sendCommand,
  clearLogs,
  inventory,
  selectedItemForTest,
}) => {
  const [selectedBaud, setSelectedBaud] = useState<number>(115200);
  const [activeSuite, setActiveSuite] = useState<ComponentSuite>('HC_SR04');
  const [healthStatus, setHealthStatus] = useState<HealthStatus>('IDLE');
  const [customCmd, setCustomCmd] = useState<string>('');
  const [servoAngle, setServoAngle] = useState<number>(90);
  const [targetItemSku, setTargetItemSku] = useState<string>(selectedItemForTest?.sku || '');

  // Live parsed telemetry metrics
  const [metric, setMetric] = useState<{ label: string; value: string; unit: string }>({
    label: 'Distance Echo',
    value: '24.8',
    unit: 'cm',
  });

  const [verdictReason, setVerdictReason] = useState<string>('Banc prêt pour la séquence de calibration.');
  const [waveformHistory, setWaveformHistory] = useState<number[]>([20, 35, 45, 60, 55, 40, 25, 30, 48, 65, 50, 42, 38]);

  const terminalEndRef = useRef<HTMLDivElement>(null);

  // Auto-scroll terminal
  useEffect(() => {
    terminalEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [logs]);

  // Set selected item if passed from inventory
  useEffect(() => {
    if (selectedItemForTest) {
      setTargetItemSku(selectedItemForTest.sku);
      if (selectedItemForTest.category === 'Sensors') {
        setActiveSuite('HC_SR04');
      } else if (selectedItemForTest.category === 'Actuators') {
        setActiveSuite('SERVO');
      } else {
        setActiveSuite('I2C_SCAN');
      }
    }
  }, [selectedItemForTest]);

  // Telemetry parsing loop
  useEffect(() => {
    if (logs.length === 0) return;
    const latest = logs[logs.length - 1];
    if (latest.type !== 'RX') return;

    const data = latest.data;

    // Check JSON structured telemetry
    if (data.startsWith('{') && data.endsWith('}')) {
      try {
        const parsed = JSON.parse(data);
        if (parsed.status === 'OK' || parsed.verdict === 'PASS') {
          setHealthStatus('WORKING');
          if (parsed.dist !== undefined) {
            setMetric({ label: 'Distance Echo', value: String(parsed.dist), unit: 'cm' });
            setVerdictReason(`Écho ultrason valide : ${parsed.dist} cm (temps de propagation : ${parsed.echo_us || Math.round(parsed.dist * 58)} µs).`);
            setWaveformHistory((prev) => [...prev.slice(-20), Math.min(100, Math.max(10, Number(parsed.dist) * 1.5))]);
          } else if (parsed.angle !== undefined) {
            setMetric({ label: 'Position Servo', value: String(parsed.angle), unit: '°' });
            setVerdictReason(`Signal PWM stable à ${parsed.pwm_pulse_us || 1500} µs pour angle ${parsed.angle}°. Consommation nominale.`);
            setWaveformHistory((prev) => [...prev.slice(-20), Math.min(100, (Number(parsed.angle) / 180) * 100)]);
          } else if (parsed.devices !== undefined) {
            setMetric({ label: 'Périphériques I2C', value: String(parsed.devices), unit: 'actifs' });
            setVerdictReason(`${parsed.devices} périphériques détectés sur le bus I2C (adresses valides).`);
          } else {
            setVerdictReason('Signal microcontrôleur conforme aux spécifications constructeur.');
          }
        } else if (parsed.status === 'ERR' || parsed.status === 'TIMEOUT') {
          setHealthStatus('FAULTY');
          setVerdictReason(parsed.msg ? `Anomalie détectée : ${parsed.msg}` : 'Timeout de réponse ou circuit ouvert.');
        }
      } catch (e) {
        // Fallback for non-JSON text
      }
    } else {
      if (data.includes('STATUS:OK') || data.includes('PASS') || data.includes('PONG')) {
        setHealthStatus('WORKING');
        setVerdictReason('Signal de synchronisation reçu avec succès.');
      } else if (data.includes('ERR') || data.includes('FAULT') || data.includes('TIMEOUT')) {
        setHealthStatus('FAULTY');
        setVerdictReason('Défaillance signal : boucle fermée non détectée.');
      }
    }
  }, [logs]);

  const runDiagnostic = (suite: ComponentSuite) => {
    setActiveSuite(suite);
    setHealthStatus('TESTING');
    setVerdictReason('Balayage des registres et analyse du signal en cours...');

    if (!isConnected) {
      // Connect simulation automatically if not connected
      connectSimulation(selectedBaud);
    }

    setTimeout(() => {
      switch (suite) {
        case 'HC_SR04':
          sendCommand('TEST:HC_SR04');
          break;
        case 'SERVO':
          sendCommand(`SERVO:${servoAngle}`);
          break;
        case 'I2C_SCAN':
          sendCommand('SCAN:I2C');
          break;
        case 'DIGITAL_PINS':
          sendCommand('TEST:PINS');
          break;
      }
    }, 200);
  };

  const handleCustomSend = (e: React.FormEvent) => {
    e.preventDefault();
    if (!customCmd.trim()) return;
    sendCommand(customCmd.trim());
    setCustomCmd('');
  };

  const handleServoChange = (angle: number) => {
    setServoAngle(angle);
    setMetric({ label: 'Position Servo', value: String(angle), unit: '°' });
    if (isConnected) {
      sendCommand(`SERVO:${angle}`);
    }
  };

  const saveVerdictToInventory = () => {
    const item = inventory.find((i) => i.sku === targetItemSku);
    const itemName = item ? item.name : targetItemSku || 'Composant';
    alert(`✓ Rapport de banc enregistré dans le registre CMC !\nComposant: ${itemName}\nVerdict: ${healthStatus}\nValeur: ${metric.value} ${metric.unit}`);
  };

  return (
    <div className="space-y-6">
      
      {/* Top Banner & Serial Port Controls */}
      <div className="p-6 rounded-3xl glass-panel border border-white/10 flex flex-col md:flex-row md:items-center justify-between gap-6 shadow-2xl">
        <div>
          <div className="flex items-center space-x-2 text-xs font-mono text-[#00F2FE] mb-1">
            <span className="w-2 h-2 rounded-full bg-[#00F2FE] animate-pulse" />
            <span className="uppercase tracking-widest font-semibold">Web Serial Hardware Test Bench</span>
          </div>
          <h1 className="font-['Orbitron'] font-black text-2xl sm:text-3xl text-white">
            CIRCUIT TEST BENCH
          </h1>
          <p className="text-xs text-slate-300 font-mono mt-1 max-w-2xl leading-relaxed">
            Pont de communication USB série direct via l'API Web Serial du navigateur pour valider les cartes Arduino, ESP32, capteurs et servomoteurs.
          </p>
        </div>

        {/* Port Connection Widget */}
        <div className="flex flex-wrap items-center gap-3 shrink-0">
          <select
            value={selectedBaud}
            disabled={isConnected}
            onChange={(e) => setSelectedBaud(Number(e.target.value))}
            className="bg-black/60 border border-white/10 rounded-xl px-3 py-2 text-xs font-mono text-cyan-400 focus:outline-none focus:border-cyan-400"
          >
            <option value={9600}>9600 BAUD</option>
            <option value={57600}>57600 BAUD</option>
            <option value={115200}>115200 BAUD</option>
          </select>

          {!isConnected ? (
            <div className="flex items-center gap-2">
              <button
                onClick={() => connect(selectedBaud)}
                className="flex items-center space-x-2 px-4 py-2.5 rounded-xl bg-gradient-to-r from-[#FF6B00] to-amber-500 text-slate-950 font-['Orbitron'] font-bold text-xs uppercase tracking-wider hover:shadow-[0_0_20px_rgba(255,107,0,0.4)] active:scale-95 transition-all"
                title="Connect via physical USB cable"
              >
                <Zap className="w-4 h-4 fill-slate-950" />
                <span>Ouvrir Port USB</span>
              </button>

              <button
                onClick={() => connectSimulation(selectedBaud)}
                className="flex items-center space-x-1.5 px-3 py-2.5 rounded-xl glass-panel border border-cyan-500/40 text-cyan-300 hover:text-white hover:border-cyan-400 text-xs font-mono transition-all"
                title="Simulate MCU if no physical board connected"
              >
                <Cpu className="w-3.5 h-3.5" />
                <span>Mode Simulation</span>
              </button>
            </div>
          ) : (
            <div className="flex items-center gap-2">
              <div className="px-3 py-1.5 rounded-xl bg-emerald-500/10 border border-emerald-500/30 text-emerald-400 text-xs font-mono flex items-center space-x-1.5">
                <span className="w-2 h-2 rounded-full bg-emerald-400 animate-ping" />
                <span className="truncate max-w-[140px]">{portDetails || 'ONLINE'}</span>
              </div>

              <button
                onClick={disconnect}
                className="flex items-center space-x-1.5 px-3 py-2 rounded-xl bg-rose-500/20 border border-rose-500/40 text-rose-300 hover:bg-rose-500/30 text-xs font-mono transition-all"
              >
                <WifiOff className="w-3.5 h-3.5" />
                <span>Déconnecter</span>
              </button>
            </div>
          )}
        </div>
      </div>

      {/* Browser Warning if Web Serial not natively supported */}
      {!isSupported && (
        <div className="p-4 rounded-2xl bg-amber-500/10 border border-amber-500/30 text-amber-300 text-xs flex items-center space-x-3">
          <AlertTriangle className="w-5 h-5 shrink-0" />
          <div>
            <strong>Info Navigateur :</strong> L'API Web Serial est optimisée sur Google Chrome, Chromium ou Microsoft Edge. 
            Vous pouvez tester toutes les fonctionnalités dès maintenant grâce au <strong>Mode Simulation</strong> inclus.
          </div>
        </div>
      )}

      {/* Main Grid: Suites & Telemetry / Realtime Terminal */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        
        {/* Left Column: Diagnostics & Hardware Health Verdict */}
        <div className="space-y-6">
          
          {/* Health Verdict Card */}
          <div className="p-6 rounded-3xl glass-panel border border-white/10 relative overflow-hidden space-y-4">
            <div className="text-xs font-mono text-slate-400 uppercase tracking-wider flex items-center justify-between">
              <span>Diagnostic Matériel</span>
              {isSimulated && (
                <span className="text-[10px] text-cyan-400 bg-cyan-950/60 px-2 py-0.5 rounded border border-cyan-800">
                  Virtual ESP32
                </span>
              )}
            </div>

            {/* Verdict Indicator */}
            <div className="flex items-center space-x-4">
              {healthStatus === 'WORKING' && (
                <div className="w-14 h-14 rounded-2xl bg-emerald-500/15 border border-emerald-500/40 flex items-center justify-center text-emerald-400 shadow-[0_0_20px_rgba(16,185,129,0.3)]">
                  <CheckCircle2 className="w-8 h-8" />
                </div>
              )}
              {healthStatus === 'FAULTY' && (
                <div className="w-14 h-14 rounded-2xl bg-rose-500/15 border border-rose-500/40 flex items-center justify-center text-rose-400 shadow-[0_0_20px_rgba(244,63,94,0.3)]">
                  <XCircle className="w-8 h-8" />
                </div>
              )}
              {healthStatus === 'TESTING' && (
                <div className="w-14 h-14 rounded-2xl bg-cyan-500/15 border border-cyan-500/40 flex items-center justify-center text-cyan-400 shadow-[0_0_20px_rgba(0,242,254,0.3)] animate-spin">
                  <RefreshCw className="w-8 h-8" />
                </div>
              )}
              {healthStatus === 'IDLE' && (
                <div className="w-14 h-14 rounded-2xl bg-white/5 border border-white/10 flex items-center justify-center text-slate-400">
                  <Activity className="w-8 h-8" />
                </div>
              )}

              <div>
                <h3 className="font-['Orbitron'] font-bold text-lg text-white">
                  {healthStatus === 'WORKING' && 'STATUS: WORKING'}
                  {healthStatus === 'FAULTY' && 'STATUS: FAULTY'}
                  {healthStatus === 'TESTING' && 'DIAGNOSING...'}
                  {healthStatus === 'IDLE' && 'BENCH READY'}
                </h3>
                <p className="text-xs font-mono text-slate-400 mt-0.5">
                  {healthStatus === 'WORKING' && 'Composant 100% nominal.'}
                  {healthStatus === 'FAULTY' && 'Signal hors tolérance.'}
                  {healthStatus === 'TESTING' && 'Balayage fréquence en cours...'}
                  {healthStatus === 'IDLE' && 'Prêt pour injection de signal.'}
                </p>
              </div>
            </div>

            {/* Explanation box */}
            <div className="p-3 rounded-xl bg-black/40 border border-white/5 text-xs font-mono text-slate-300 leading-relaxed">
              {verdictReason}
            </div>

            {/* Live Readout & Waveform */}
            <div className="p-4 rounded-xl bg-black/50 border border-white/5 space-y-2.5">
              <div className="flex justify-between items-center text-xs font-mono">
                <span className="text-slate-400">{metric.label}</span>
                <span className="text-cyan-400 font-bold text-base tabular-nums">
                  {metric.value} {metric.unit}
                </span>
              </div>

              {/* Realtime Waveform Canvas */}
              <div className="h-10 w-full flex items-end gap-1 pt-2">
                {waveformHistory.map((val, idx) => (
                  <div
                    key={idx}
                    className="flex-1 bg-gradient-to-t from-cyan-500 to-[#FF6B00] rounded-t transition-all duration-200"
                    style={{ height: `${val}%` }}
                  />
                ))}
              </div>
            </div>

            {/* Target Inventory Item Selector & Save Action */}
            <div className="space-y-2 pt-2 border-t border-white/5">
              <label className="text-[11px] font-mono text-slate-400 uppercase">
                Associer au Composant d'Inventaire
              </label>
              <select
                value={targetItemSku}
                onChange={(e) => setTargetItemSku(e.target.value)}
                className="glass-input w-full px-3 py-2 rounded-xl text-xs font-mono text-slate-200 bg-[#070B14]"
              >
                <option value="">Sélectionner un composant du labo...</option>
                {inventory.map((i) => (
                  <option key={i.id} value={i.sku}>
                    {i.sku} — {i.name}
                  </option>
                ))}
              </select>

              <button
                disabled={healthStatus === 'IDLE' || healthStatus === 'TESTING'}
                onClick={saveVerdictToInventory}
                className="w-full mt-2 py-2.5 rounded-xl bg-white/5 hover:bg-[#FF6B00]/20 border border-white/10 hover:border-[#FF6B00]/50 text-xs font-mono text-slate-200 hover:text-white transition-all flex items-center justify-center space-x-2 disabled:opacity-40"
              >
                <Box className="w-4 h-4 text-[#FF6B00]" />
                <span>Enregistrer Verdict dans le Registre</span>
              </button>
            </div>
          </div>

          {/* Test Suites Selector */}
          <div className="p-6 rounded-3xl glass-panel border border-white/10 space-y-3">
            <h2 className="font-['Orbitron'] font-bold text-xs uppercase tracking-wider text-white flex items-center space-x-2">
              <Cpu className="w-4 h-4 text-[#FF6B00]" />
              <span>Suites de Diagnostic Embarqué</span>
            </h2>

            <div className="space-y-2">
              {[
                {
                  id: 'HC_SR04',
                  name: 'Capteur Ultrason (HC-SR04)',
                  desc: 'Vérifie l’impulsion Echo et mesure la distance',
                  icon: Radio,
                },
                {
                  id: 'SERVO',
                  name: 'Servomoteur PWM (MG996R / SG90)',
                  desc: 'Balayage continu de l’angle 0° à 180°',
                  icon: Gauge,
                },
                {
                  id: 'I2C_SCAN',
                  name: 'Scanner de Bus I2C',
                  desc: 'Détecte les adresses matérielles 0x01 à 0x7E',
                  icon: Cpu,
                },
                {
                  id: 'DIGITAL_PINS',
                  name: 'Testeur de Broches Digitales (Loopback)',
                  desc: 'Vérifie l’intégrité des signaux logiques D2-D5',
                  icon: Zap,
                },
              ].map((suite) => {
                const Icon = suite.icon;
                const isActive = activeSuite === suite.id;

                return (
                  <div
                    key={suite.id}
                    className={`p-3.5 rounded-2xl border transition-all ${
                      isActive
                        ? 'bg-[#FF6B00]/15 border-[#FF6B00]/50 text-white shadow-[0_0_15px_rgba(255,107,0,0.2)]'
                        : 'bg-white/[0.02] border-white/5 text-slate-400 hover:bg-white/5 hover:text-white'
                    }`}
                  >
                    <div className="flex items-center justify-between">
                      <div className="flex items-center space-x-2.5">
                        <Icon className={`w-4 h-4 ${isActive ? 'text-[#FF6B00]' : 'text-slate-500'}`} />
                        <div>
                          <div className="font-bold text-xs font-['Orbitron']">{suite.name}</div>
                          <div className="text-[11px] font-mono text-slate-400 mt-0.5">{suite.desc}</div>
                        </div>
                      </div>
                      <button
                        onClick={() => runDiagnostic(suite.id as ComponentSuite)}
                        className="px-2.5 py-1 rounded-lg bg-white/10 hover:bg-[#FF6B00] text-slate-200 hover:text-black text-[11px] font-mono transition-colors flex items-center space-x-1 shrink-0"
                      >
                        <Play className="w-3 h-3 fill-current" />
                        <span>Lancer</span>
                      </button>
                    </div>

                    {/* Interactive slider for Servo suite */}
                    {suite.id === 'SERVO' && isActive && (
                      <div className="mt-3 pt-3 border-t border-white/10 space-y-1.5">
                        <div className="flex justify-between text-[11px] font-mono">
                          <span className="text-slate-400">Angle Cible PWM :</span>
                          <span className="text-cyan-400 font-bold">{servoAngle}°</span>
                        </div>
                        <input
                          type="range"
                          min="0"
                          max="180"
                          value={servoAngle}
                          onChange={(e) => handleServoChange(Number(e.target.value))}
                          className="w-full accent-[#FF6B00] cursor-pointer"
                        />
                        <div className="flex justify-between text-[10px] font-mono text-slate-500">
                          <span>0° (1000µs)</span>
                          <span>90° (1500µs)</span>
                          <span>180° (2000µs)</span>
                        </div>
                      </div>
                    )}
                  </div>
                );
              })}
            </div>
          </div>

        </div>

        {/* Center & Right Column: Serial Stream & Interactive Terminal (Span 2) */}
        <div className="lg:col-span-2 rounded-3xl glass-panel border border-white/10 p-6 flex flex-col h-[650px] shadow-2xl relative overflow-hidden">
          
          {/* Terminal Window Header */}
          <div className="flex items-center justify-between border-b border-white/10 pb-4 mb-4">
            <div className="flex items-center space-x-3">
              <div className="p-2 rounded-xl bg-cyan-500/15 border border-cyan-500/30 text-cyan-400">
                <TerminalIcon className="w-4 h-4" />
              </div>
              <div>
                <h2 className="font-['Orbitron'] font-bold text-xs text-white tracking-widest uppercase">
                  MONITEUR SÉRIE // SERIAL STREAM TERMINAL
                </h2>
                <div className="text-[11px] font-mono text-slate-400">
                  PORT: {portDetails || 'NON CONNECTÉ'} • {logs.length} entrées en mémoire
                </div>
              </div>
            </div>

            <div className="flex items-center space-x-2">
              <button
                onClick={clearLogs}
                className="px-3 py-1.5 rounded-lg bg-white/5 hover:bg-white/10 text-[11px] font-mono text-slate-400 hover:text-white transition-colors"
              >
                Vider le flux
              </button>
              <div className="flex space-x-1.5 pl-2 border-l border-white/10">
                <span className="w-2.5 h-2.5 rounded-full bg-rose-500/60" />
                <span className="w-2.5 h-2.5 rounded-full bg-amber-500/60" />
                <span className="w-2.5 h-2.5 rounded-full bg-emerald-500/60" />
              </div>
            </div>
          </div>

          {/* Scrollable Terminal Screen */}
          <div className="flex-1 bg-black/60 rounded-2xl p-4 font-mono text-xs overflow-y-auto space-y-1.5 border border-white/5 relative">
            <div className="pointer-events-none absolute inset-0 bg-gradient-to-b from-transparent via-cyan-500/[0.02] to-transparent h-full" />

            {logs.length === 0 && (
              <div className="h-full flex flex-col items-center justify-center text-slate-500 space-y-2">
                <ShieldCheck className="w-8 h-8 opacity-40 text-cyan-400" />
                <p className="text-center text-xs">
                  Mémoire tampon vide. Connectez un port USB ou lancez le Mode Simulation.
                </p>
              </div>
            )}

            {logs.map((log) => (
              <div key={log.id} className="flex items-start space-x-2.5 leading-relaxed break-all">
                <span className="text-slate-600 select-none text-[10px] pt-0.5">{log.timestamp}</span>

                {log.type === 'TX' && (
                  <span className="px-1.5 py-0.2 rounded bg-purple-500/20 text-purple-300 text-[10px] font-bold">
                    TX &gt;&gt;
                  </span>
                )}
                {log.type === 'RX' && (
                  <span className="px-1.5 py-0.2 rounded bg-cyan-500/20 text-cyan-300 text-[10px] font-bold">
                    &lt;&lt; RX
                  </span>
                )}
                {log.type === 'SYS' && (
                  <span className="px-1.5 py-0.2 rounded bg-amber-500/20 text-amber-300 text-[10px] font-bold">
                    SYS //
                  </span>
                )}

                <span
                  className={
                    log.type === 'TX'
                      ? 'text-purple-200'
                      : log.type === 'SYS'
                      ? 'text-amber-300'
                      : log.data.includes('FAULT') || log.data.includes('ERR')
                      ? 'text-rose-400 font-bold'
                      : 'text-slate-200'
                  }
                >
                  {log.data}
                </span>
              </div>
            ))}
            <div ref={terminalEndRef} />
          </div>

          {/* Terminal Controls, Quick Macros & Command Input */}
          <div className="mt-4 space-y-3">
            {/* Quick Macro Buttons */}
            <div className="flex items-center space-x-2 text-[11px] font-mono text-slate-400 overflow-x-auto pb-1">
              <span className="text-slate-500">Macros:</span>
              {['PING', 'STATUS', 'RESET', 'SCAN:I2C', 'TEST:HC_SR04', 'SERVO:90', 'SERVO:180'].map((cmd) => (
                <button
                  key={cmd}
                  onClick={() => {
                    if (!isConnected) connectSimulation(selectedBaud);
                    setTimeout(() => sendCommand(cmd), 100);
                  }}
                  className="px-2 py-0.5 rounded-lg bg-white/5 border border-white/10 hover:border-cyan-400/50 hover:text-cyan-300 transition-colors whitespace-nowrap"
                >
                  {cmd}
                </button>
              ))}
            </div>

            {/* Command Sender Form */}
            <form onSubmit={handleCustomSend} className="flex items-center gap-2">
              <div className="relative flex-1">
                <span className="absolute left-3.5 top-1/2 -translate-y-1/2 font-mono text-xs text-[#FF6B00] select-none">
                  &gt;
                </span>
                <input
                  type="text"
                  value={customCmd}
                  onChange={(e) => setCustomCmd(e.target.value)}
                  placeholder={
                    isConnected
                      ? 'Entrer commande AT ou série (ex: TEST:HC_SR04, PING, SERVO:45)...'
                      : 'Port déconnecté. Cliquez sur Ouvrir Port USB ou Mode Simulation.'
                  }
                  className="glass-input w-full pl-8 pr-4 py-2.5 rounded-xl text-xs font-mono text-white placeholder-slate-500"
                />
              </div>
              <button
                type="submit"
                disabled={!customCmd.trim()}
                className="px-4 py-2.5 rounded-xl bg-[#FF6B00] text-slate-950 hover:bg-[#FF882E] font-bold text-xs font-mono transition-all disabled:opacity-30"
              >
                <Send className="w-4 h-4" />
              </button>
            </form>
          </div>

        </div>

      </div>

    </div>
  );
};
