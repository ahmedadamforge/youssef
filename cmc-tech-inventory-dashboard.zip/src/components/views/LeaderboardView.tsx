import React, { useState } from 'react';
import { 
  Trophy, 
  Medal, 
  Award, 
  Flame, 
  Zap, 
  Plus, 
  Check, 
  UserPlus, 
  Activity,
  Bot
} from 'lucide-react';
import { MemberProfile } from '../../types';

interface LeaderboardViewProps {
  members: MemberProfile[];
  onAddPoints: (memberId: string, points: number, reason: string) => void;
}

export const LeaderboardView: React.FC<LeaderboardViewProps> = ({ members, onAddPoints }) => {
  const [selectedMember, setSelectedMember] = useState<MemberProfile | null>(null);
  const [bonusPoints, setBonusPoints] = useState<number>(50);
  const [bonusReason, setBonusReason] = useState<string>('Validation circuit sur banc Web Serial');

  const handleGrantXP = () => {
    if (!selectedMember) return;
    onAddPoints(selectedMember.id, bonusPoints, bonusReason);
    alert(`+${bonusPoints} XP accordés à ${selectedMember.name} pour : "${bonusReason}" !`);
    setSelectedMember(null);
  };

  const sortedMembers = [...members].sort((a, b) => b.points - a.points);
  const topThree = sortedMembers.slice(0, 3);

  return (
    <div className="space-y-6">
      
      {/* Top Banner */}
      <div className="p-6 rounded-3xl glass-panel border border-white/10 flex flex-col md:flex-row md:items-center justify-between gap-4 shadow-xl">
        <div>
          <div className="flex items-center space-x-2 text-xs font-mono text-[#FF6B00] mb-1">
            <span className="w-2 h-2 rounded-full bg-[#FF6B00]" />
            <span className="uppercase tracking-wider font-semibold">CELLULE TECHNIQUE HALL OF FAME</span>
          </div>
          <h1 className="font-['Orbitron'] font-black text-2xl sm:text-3xl text-white">
            MEMBER LEADERBOARD & XP
          </h1>
          <p className="text-xs text-slate-400 font-mono mt-0.5">
            Classement d'activité des membres basé sur les tests de composants, présence et robots assemblés
          </p>
        </div>

        <div className="flex items-center space-x-2 px-4 py-2 rounded-2xl bg-amber-500/10 border border-amber-500/30 text-xs font-mono text-amber-300">
          <Trophy className="w-4 h-4 text-amber-400" />
          <span>SAISON 2026/2027</span>
        </div>
      </div>

      {/* Podium Top 3 */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6 pt-2">
        {topThree.map((m, idx) => {
          const isFirst = idx === 0;
          const isSecond = idx === 1;
          const isThird = idx === 2;

          return (
            <div
              key={m.id}
              className={`p-6 rounded-3xl backdrop-blur-xl border flex flex-col items-center text-center relative overflow-hidden transition-all ${
                isFirst
                  ? 'glass-panel border-[#FF6B00] shadow-[0_0_35px_rgba(255,107,0,0.25)] md:-translate-y-2'
                  : 'glass-panel border-white/10'
              }`}
            >
              {/* Crown / Rank Medal */}
              <div
                className={`w-14 h-14 rounded-2xl flex items-center justify-center font-['Orbitron'] font-extrabold text-xl mb-3 shadow-lg ${
                  isFirst
                    ? 'bg-gradient-to-tr from-[#FF6B00] to-amber-400 text-slate-950'
                    : isSecond
                    ? 'bg-gradient-to-tr from-slate-200 to-slate-400 text-slate-950'
                    : 'bg-gradient-to-tr from-amber-700 to-amber-900 text-amber-200'
                }`}
              >
                #{idx + 1}
              </div>

              <h2 className="font-['Orbitron'] font-bold text-lg text-white">{m.name}</h2>
              <p className="text-xs font-mono text-cyan-400 mt-0.5">{m.role}</p>
              <div className="text-[11px] font-mono text-slate-400">Cellule {m.cellule}</div>

              {/* Badge */}
              <div className="my-4 px-3 py-1 rounded-full bg-white/5 border border-white/10 text-[11px] font-mono text-purple-300">
                ★ {m.badge}
              </div>

              {/* XP Counter */}
              <div className="text-3xl font-['Orbitron'] font-black text-transparent bg-clip-text bg-gradient-to-r from-[#FF6B00] to-amber-300">
                {m.points}{' '}
                <span className="text-xs font-mono text-slate-400 font-normal">XP</span>
              </div>

              <div className="mt-2 text-xs font-mono text-slate-400">
                {m.robotsCount} robots livrés
              </div>

              {/* Grant XP button */}
              <button
                onClick={() => setSelectedMember(m)}
                className="mt-4 w-full py-2 rounded-xl bg-white/5 hover:bg-[#FF6B00] text-slate-300 hover:text-slate-950 text-xs font-mono transition-colors flex items-center justify-center space-x-1.5"
              >
                <Zap className="w-3.5 h-3.5" />
                <span>Accorder XP</span>
              </button>
            </div>
          );
        })}
      </div>

      {/* Full Leaderboard Table */}
      <div className="rounded-3xl glass-panel border border-white/10 overflow-hidden font-mono text-xs">
        <div className="p-5 border-b border-white/10 flex items-center justify-between">
          <h2 className="font-['Orbitron'] font-bold text-sm text-white flex items-center space-x-2">
            <Trophy className="w-4 h-4 text-[#FF6B00]" />
            <span>Tableau d'Honneur des Développeurs & Makers</span>
          </h2>
          <span className="text-slate-400 text-xs">5 Membres Actifs</span>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left">
            <thead className="bg-black/50 text-slate-400 uppercase tracking-wider text-[11px] border-b border-white/5">
              <tr>
                <th className="p-4">Rang</th>
                <th className="p-4">Membre</th>
                <th className="p-4 hidden md:table-cell">Cellule</th>
                <th className="p-4 hidden sm:table-cell">Dernière Action Validée</th>
                <th className="p-4">Machines</th>
                <th className="p-4 text-right">Points XP</th>
                <th className="p-4 text-right">Action</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-white/5 text-slate-300">
              {sortedMembers.map((m, index) => (
                <tr key={m.id} className="hover:bg-white/[0.03] transition-colors">
                  <td className="p-4 font-['Orbitron'] font-bold text-white text-sm">
                    #{index + 1}
                  </td>
                  <td className="p-4">
                    <div className="flex items-center space-x-2.5">
                      <div className="w-8 h-8 rounded-xl bg-gradient-to-tr from-cyan-500 to-purple-600 flex items-center justify-center font-bold text-xs text-white">
                        {m.avatarLetter}
                      </div>
                      <div>
                        <div className="font-sans font-semibold text-white">{m.name}</div>
                        <div className="text-[11px] text-cyan-400">{m.badge}</div>
                      </div>
                    </div>
                  </td>
                  <td className="p-4 hidden md:table-cell text-slate-400">
                    {m.cellule}
                  </td>
                  <td className="p-4 hidden sm:table-cell text-slate-300 text-xs max-w-xs truncate">
                    {m.recentActivity}
                  </td>
                  <td className="p-4 text-cyan-300 font-semibold">
                    {m.robotsCount} robots
                  </td>
                  <td className="p-4 text-right font-['Orbitron'] font-bold text-[#FF6B00] text-sm tabular-nums">
                    {m.points} XP
                  </td>
                  <td className="p-4 text-right">
                    <button
                      onClick={() => setSelectedMember(m)}
                      className="px-2.5 py-1 rounded-lg bg-white/5 hover:bg-white/10 text-cyan-400 text-[11px]"
                    >
                      + XP
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Grant XP Modal */}
      {selectedMember && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/85 backdrop-blur-md">
          <div className="glass-panel max-w-md w-full rounded-3xl border border-[#FF6B00]/40 p-6 space-y-4 shadow-[0_0_35px_rgba(255,107,0,0.25)]">
            <h3 className="font-['Orbitron'] font-bold text-base text-white">
              Attribuer des Points XP
            </h3>
            <p className="text-xs font-mono text-slate-300">
              Membre : <strong className="text-cyan-400">{selectedMember.name}</strong> ({selectedMember.role})
            </p>

            <div className="space-y-3 pt-2">
              <div>
                <label className="block text-xs font-mono uppercase text-slate-400 mb-1">
                  Nombre de points XP
                </label>
                <div className="flex gap-2">
                  {[25, 50, 100, 200].map((pts) => (
                    <button
                      key={pts}
                      type="button"
                      onClick={() => setBonusPoints(pts)}
                      className={`flex-1 py-1.5 rounded-xl text-xs font-mono border transition-all ${
                        bonusPoints === pts
                          ? 'bg-[#FF6B00] text-slate-950 font-bold border-[#FF6B00]'
                          : 'bg-white/5 border-white/10 text-slate-300 hover:text-white'
                      }`}
                    >
                      +{pts} XP
                    </button>
                  ))}
                </div>
              </div>

              <div>
                <label className="block text-xs font-mono uppercase text-slate-400 mb-1">
                  Motif de la contribution
                </label>
                <input
                  type="text"
                  value={bonusReason}
                  onChange={(e) => setBonusReason(e.target.value)}
                  className="glass-input w-full px-3 py-2 rounded-xl text-xs font-mono text-white"
                />
              </div>

              <div className="pt-2 flex gap-3">
                <button
                  type="button"
                  onClick={handleGrantXP}
                  className="flex-1 py-2.5 rounded-xl bg-gradient-to-r from-[#FF6B00] to-amber-500 text-slate-950 font-['Orbitron'] font-bold text-xs uppercase tracking-wider hover:shadow-lg transition-all"
                >
                  Valider Points XP
                </button>
                <button
                  type="button"
                  onClick={() => setSelectedMember(null)}
                  className="px-4 py-2.5 rounded-xl bg-white/10 text-slate-300 font-mono text-xs hover:bg-white/20"
                >
                  Annuler
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

    </div>
  );
};
