import React, { useState } from 'react';
import { 
  Calendar, 
  MapPin, 
  Users, 
  CheckCircle, 
  Flame, 
  Clock, 
  X,
  Sparkles
} from 'lucide-react';
import { ClubEvent } from '../../types';

interface EventsViewProps {
  events: ClubEvent[];
  onRegisterEvent: (eventId: string, memberName: string) => void;
}

export const EventsView: React.FC<EventsViewProps> = ({ events, onRegisterEvent }) => {
  const [registeringEvent, setRegisteringEvent] = useState<ClubEvent | null>(null);
  const [userName, setUserName] = useState('');
  const [userCellule, setUserCellule] = useState('Mécatronique');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!registeringEvent || !userName.trim()) return;
    onRegisterEvent(registeringEvent.id, `${userName.trim()} (${userCellule})`);
    alert(`✓ Inscription validée pour ${userName} à "${registeringEvent.title}" !`);
    setRegisteringEvent(null);
    setUserName('');
  };

  return (
    <div className="space-y-6">
      
      {/* Top Banner */}
      <div className="p-6 rounded-3xl glass-panel border border-white/10 flex flex-col md:flex-row md:items-center justify-between gap-4 shadow-xl">
        <div>
          <div className="flex items-center space-x-2 text-xs font-mono text-[#FF6B00] mb-1">
            <span className="w-2 h-2 rounded-full bg-[#FF6B00]" />
            <span className="uppercase tracking-wider font-semibold">CALENDRIER COMPÉTITIONS & FORMATIONS</span>
          </div>
          <h1 className="font-['Orbitron'] font-black text-2xl sm:text-3xl text-white">
            EVENTS & HACKATHONS
          </h1>
          <p className="text-xs text-slate-400 font-mono mt-0.5">
            Sessions intensives, hackathons de mécatronique et compétitions nationales
          </p>
        </div>

        <div className="flex items-center space-x-2 px-4 py-2 rounded-2xl bg-gradient-to-r from-[#FF6B00]/15 to-cyan-500/15 border border-white/10 text-xs font-mono">
          <Flame className="w-4 h-4 text-[#FF6B00] animate-bounce" />
          <span className="text-white font-semibold">SAISON ROBOTIQUE 2026 ACTIVE</span>
        </div>
      </div>

      {/* Events Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {events.map((ev) => (
          <div
            key={ev.id}
            className="glass-panel rounded-3xl p-6 border border-white/10 flex flex-col justify-between hover:border-[#FF6B00]/40 transition-all group"
          >
            <div className="space-y-4">
              {/* Type and Slots Left */}
              <div className="flex items-center justify-between text-xs font-mono">
                <span className="px-2.5 py-0.5 rounded-full bg-[#FF6B00]/15 text-[#FF6B00] border border-[#FF6B00]/30 font-semibold">
                  {ev.type}
                </span>

                <span className="text-cyan-400 font-medium">
                  {ev.slotsRemaining} places dispo
                </span>
              </div>

              {/* Title & Desc */}
              <div>
                <h2 className="font-['Orbitron'] font-bold text-lg text-white group-hover:text-cyan-300 transition-colors">
                  {ev.title}
                </h2>
                <p className="text-xs text-slate-300 mt-2 leading-relaxed">
                  {ev.description}
                </p>
              </div>

              {/* Date & Location Badges */}
              <div className="space-y-2 pt-2 text-xs font-mono text-slate-300">
                <div className="flex items-center space-x-2 text-slate-300">
                  <Calendar className="w-3.5 h-3.5 text-[#FF6B00]" />
                  <span>{ev.date}</span>
                </div>
                <div className="flex items-center space-x-2 text-slate-300">
                  <MapPin className="w-3.5 h-3.5 text-cyan-400" />
                  <span>{ev.location}</span>
                </div>
              </div>

              {/* Registered Members snippet */}
              <div className="pt-2 border-t border-white/5 text-[11px] font-mono text-slate-400">
                <div className="flex items-center space-x-1.5 mb-1.5">
                  <Users className="w-3 h-3 text-slate-500" />
                  <span>Inscrits ({ev.registeredMembers.length}) :</span>
                </div>
                <div className="flex flex-wrap gap-1">
                  {ev.registeredMembers.map((m, idx) => (
                    <span key={idx} className="px-2 py-0.5 rounded bg-white/5 text-slate-300 text-[10px]">
                      {m}
                    </span>
                  ))}
                </div>
              </div>
            </div>

            {/* Registration Action */}
            <div className="mt-6 pt-4 border-t border-white/10">
              <button
                disabled={ev.slotsRemaining <= 0}
                onClick={() => setRegisteringEvent(ev)}
                className="w-full py-2.5 rounded-xl bg-gradient-to-r from-[#FF6B00] to-amber-500 hover:from-[#FF882E] hover:to-amber-400 text-slate-950 font-['Orbitron'] font-bold text-xs uppercase tracking-wider transition-all disabled:opacity-40"
              >
                {ev.slotsRemaining > 0 ? "S'inscrire à l'Événement" : 'Complet'}
              </button>
            </div>
          </div>
        ))}
      </div>

      {/* Registration Modal */}
      {registeringEvent && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/85 backdrop-blur-md">
          <div className="glass-panel max-w-md w-full rounded-3xl border border-[#FF6B00]/40 p-6 space-y-4 shadow-[0_0_35px_rgba(255,107,0,0.25)] relative">
            <button
              onClick={() => setRegisteringEvent(null)}
              className="absolute top-4 right-4 p-2 rounded-xl bg-white/5 text-slate-400 hover:text-white"
            >
              <X className="w-5 h-5" />
            </button>

            <div className="flex items-center space-x-3">
              <div className="p-2 rounded-xl bg-[#FF6B00]/20 text-[#FF6B00]">
                <Calendar className="w-5 h-5" />
              </div>
              <div>
                <h3 className="font-['Orbitron'] font-bold text-base text-white">
                  Inscription Événement
                </h3>
                <p className="text-xs font-mono text-cyan-400 truncate max-w-[280px]">
                  {registeringEvent.title}
                </p>
              </div>
            </div>

            <form onSubmit={handleSubmit} className="space-y-4 pt-2">
              <div>
                <label className="block text-xs font-mono uppercase text-slate-400 mb-1">
                  Nom et Prénom du Membre
                </label>
                <input
                  type="text"
                  required
                  value={userName}
                  onChange={(e) => setUserName(e.target.value)}
                  placeholder="ex: Anas Mansouri"
                  className="glass-input w-full px-3.5 py-2.5 rounded-xl text-xs font-mono text-white"
                />
              </div>

              <div>
                <label className="block text-xs font-mono uppercase text-slate-400 mb-1">
                  Cellule Technique
                </label>
                <select
                  value={userCellule}
                  onChange={(e) => setUserCellule(e.target.value)}
                  className="glass-input w-full px-3.5 py-2.5 rounded-xl text-xs font-mono text-slate-200 bg-[#070B14]"
                >
                  <option value="Mécatronique">Mécatronique</option>
                  <option value="Embedded & IoT">Embedded & IoT</option>
                  <option value="IA & Vision">IA & Vision</option>
                  <option value="Conception 3D">Conception 3D & Usinage</option>
                </select>
              </div>

              <div className="pt-2 flex gap-3">
                <button
                  type="submit"
                  className="flex-1 py-3 rounded-xl bg-gradient-to-r from-[#FF6B00] to-amber-500 text-slate-950 font-['Orbitron'] font-bold text-xs uppercase tracking-wider hover:shadow-lg transition-all"
                >
                  Confirmer Inscription
                </button>
                <button
                  type="button"
                  onClick={() => setRegisteringEvent(null)}
                  className="px-4 py-3 rounded-xl bg-white/10 text-slate-300 font-mono text-xs hover:bg-white/20"
                >
                  Annuler
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

    </div>
  );
};
