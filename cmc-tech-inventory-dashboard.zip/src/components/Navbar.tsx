import React from 'react';
import { 
  Bot, 
  Cpu, 
  Terminal, 
  Calendar, 
  Trophy, 
  FolderGit2, 
  Menu, 
  QrCode,
  Radio,
  Tv
} from 'lucide-react';

interface NavbarProps {
  currentTab: string;
  setCurrentTab: (tab: string) => void;
  openScanner: () => void;
  openMobileMenu: () => void;
  isSerialActive?: boolean;
}

export const Navbar: React.FC<NavbarProps> = ({
  currentTab,
  setCurrentTab,
  openScanner,
  openMobileMenu,
  isSerialActive = false,
}) => {
  const navItems = [
    { id: 'dashboard', label: 'Dashboard', icon: Bot },
    { id: 'inventory', label: 'Inventory', icon: Cpu },
    { id: 'circuit-tester', label: 'Circuit Tester', icon: Terminal, highlight: true },
    { id: 'affichage', label: 'Affichage & Écrans', icon: Tv },
    { id: 'projects', label: 'Robots', icon: Radio },
    { id: 'events', label: 'Events', icon: Calendar },
    { id: 'leaderboard', label: 'Leaderboard', icon: Trophy },
    { id: 'project-folder', label: 'Code & Folder', icon: FolderGit2 },
  ];

  return (
    <header className="sticky top-0 z-40 bg-[#070B14]/85 backdrop-blur-xl border-b border-white/10 px-4 sm:px-6 lg:px-8 py-3 transition-colors">
      <div className="max-w-7xl mx-auto flex items-center justify-between gap-6">
        
        {/* Zone 1: Brand Wordmark */}
        <div className="flex items-center space-x-3 shrink-0">
          <button 
            onClick={openMobileMenu} 
            className="lg:hidden p-2 rounded-xl bg-white/5 border border-white/10 text-slate-300 hover:text-white"
            aria-label="Open Navigation Menu"
          >
            <Menu className="w-5 h-5" />
          </button>

          <button 
            onClick={() => setCurrentTab('dashboard')} 
            className="flex items-center space-x-3 text-left group"
          >
            <div className="w-9 h-9 rounded-xl bg-gradient-to-tr from-[#FF6B00] via-amber-500 to-[#00F2FE] p-[1.5px] shadow-[0_0_15px_rgba(255,107,0,0.35)]">
              <div className="w-full h-full bg-[#070B14] rounded-xl flex items-center justify-center">
                <Bot className="w-5 h-5 text-[#FF6B00] group-hover:scale-110 transition-transform" />
              </div>
            </div>
            <div>
              <div className="flex items-center space-x-2">
                <span className="font-['Orbitron'] font-extrabold text-sm sm:text-base tracking-wider text-white">
                  ROBOTICS.MA
                </span>
                <span className="text-[10px] font-mono px-1.5 py-0.5 rounded bg-[#FF6B00]/15 text-[#FF6B00] border border-[#FF6B00]/30 font-semibold hidden sm:inline">
                  CMC RABAT
                </span>
              </div>
              <p className="text-[10px] font-mono text-cyan-400 hidden sm:block">
                Cellule Technique • Bay 04
              </p>
            </div>
          </button>
        </div>

        {/* Zone 2: Navigation Links (Single-line, unboxed, hover indicator) */}
        <nav className="hidden lg:flex items-center space-x-1 shrink-0">
          {navItems.map((item) => {
            const Icon = item.icon;
            const isActive = currentTab === item.id;

            return (
              <button
                key={item.id}
                onClick={() => setCurrentTab(item.id)}
                className={`flex items-center space-x-2 px-3 py-2 rounded-xl text-xs font-mono whitespace-nowrap shrink-0 transition-all ${
                  isActive
                    ? 'bg-[#FF6B00]/15 text-[#FF6B00] border border-[#FF6B00]/40 font-semibold shadow-[0_0_15px_rgba(255,107,0,0.15)]'
                    : item.highlight
                    ? 'text-cyan-300 hover:text-white hover:bg-cyan-950/30 border border-cyan-500/30'
                    : 'text-slate-400 hover:text-white hover:bg-white/5'
                }`}
              >
                <Icon className="w-3.5 h-3.5" />
                <span>{item.label}</span>
                {item.id === 'circuit-tester' && isSerialActive && (
                  <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-ping" />
                )}
              </button>
            );
          })}
        </nav>

        {/* Zone 3: Primary Actions & User Badge */}
        <div className="flex items-center space-x-3 shrink-0">
          {/* Quick QR Scanner CTA */}
          <button
            onClick={openScanner}
            className="flex items-center space-x-2 px-3.5 py-2 rounded-xl bg-gradient-to-r from-[#FF6B00] to-amber-500 text-slate-950 font-['Orbitron'] font-bold text-xs uppercase tracking-wider hover:shadow-[0_0_20px_rgba(255,107,0,0.4)] active:scale-95 transition-all whitespace-nowrap shrink-0"
          >
            <QrCode className="w-4 h-4 text-slate-950" />
            <span className="hidden sm:inline">Scan QR</span>
          </button>

          {/* User Badge: Chef de Cellule */}
          <div className="flex items-center space-x-2.5 pl-2 border-l border-white/10">
            <div className="relative">
              <div className="w-8 h-8 rounded-xl bg-gradient-to-br from-cyan-500 to-purple-600 flex items-center justify-center text-xs font-['Orbitron'] font-bold text-white shadow-sm">
                YB
              </div>
              <span className="absolute -bottom-0.5 -right-0.5 w-2.5 h-2.5 rounded-full bg-emerald-500 ring-2 ring-[#070B14]" />
            </div>
            <div className="hidden xl:block text-left text-xs leading-tight">
              <div className="font-semibold text-slate-200">Yassine B.</div>
              <div className="text-[10px] font-mono text-[#FF6B00]">Chef Cellule</div>
            </div>
          </div>
        </div>

      </div>
    </header>
  );
};
