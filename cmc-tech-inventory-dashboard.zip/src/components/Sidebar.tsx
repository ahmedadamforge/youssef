import React from 'react';
import { 
  Bot, 
  Cpu, 
  Terminal, 
  Calendar, 
  Trophy, 
  FolderGit2, 
  X, 
  QrCode, 
  Radio, 
  Wrench, 
  Server,
  Tv
} from 'lucide-react';

interface SidebarProps {
  isOpen: boolean;
  onClose: () => void;
  currentTab: string;
  setCurrentTab: (tab: string) => void;
  openScanner: () => void;
  openBreakdownModal: () => void;
  totalComponents: number;
}

export const Sidebar: React.FC<SidebarProps> = ({
  isOpen,
  onClose,
  currentTab,
  setCurrentTab,
  openScanner,
  openBreakdownModal,
  totalComponents,
}) => {
  const menuItems = [
    { id: 'dashboard', label: 'Dashboard & Overview', icon: Bot, badge: 'Live' },
    { id: 'inventory', label: 'Hardware Matrix', icon: Cpu, badge: `${totalComponents}` },
    { id: 'circuit-tester', label: 'Circuit Tester (Web Serial)', icon: Terminal, badge: 'USB' },
    { id: 'affichage', label: 'Affichage & Écrans (OLED/LCD)', icon: Tv, badge: 'Display' },
    { id: 'projects', label: 'Robots Showcase', icon: Radio, badge: '4 Bots' },
    { id: 'events', label: 'Events & Hackathons', icon: Calendar, badge: '4' },
    { id: 'leaderboard', label: 'Members & Leaderboard', icon: Trophy, badge: 'XP' },
    { id: 'project-folder', label: 'Project Code & Export', icon: FolderGit2, badge: 'Monorepo' },
  ];

  const handleSelect = (tabId: string) => {
    setCurrentTab(tabId);
    onClose();
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 lg:hidden flex">
      {/* Backdrop */}
      <div 
        className="fixed inset-0 bg-black/80 backdrop-blur-md transition-opacity" 
        onClick={onClose} 
      />

      {/* Drawer Content */}
      <aside className="relative w-80 max-w-[85%] bg-[#0B1220] border-r border-white/10 flex flex-col justify-between p-5 z-10 overflow-y-auto">
        
        {/* Top Header */}
        <div>
          <div className="flex items-center justify-between pb-4 border-b border-white/10 mb-4">
            <div className="flex items-center space-x-3">
              <div className="w-9 h-9 rounded-xl bg-gradient-to-tr from-[#FF6B00] to-cyan-400 p-[1.5px]">
                <div className="w-full h-full bg-[#070B14] rounded-xl flex items-center justify-center">
                  <Bot className="w-5 h-5 text-[#FF6B00]" />
                </div>
              </div>
              <div>
                <h2 className="font-['Orbitron'] font-bold text-sm text-white">ROBOTICS.MA</h2>
                <p className="text-[10px] font-mono text-cyan-400">Cellule Technique CMC</p>
              </div>
            </div>
            <button 
              onClick={onClose}
              className="p-1.5 rounded-lg bg-white/5 text-slate-400 hover:text-white"
            >
              <X className="w-5 h-5" />
            </button>
          </div>

          {/* Quick Scanner Action */}
          <button
            onClick={() => {
              openScanner();
              onClose();
            }}
            className="w-full mb-4 py-3 px-4 rounded-xl bg-gradient-to-r from-[#FF6B00] to-amber-500 text-slate-950 font-['Orbitron'] font-bold text-xs uppercase tracking-wider flex items-center justify-center space-x-2 shadow-lg"
          >
            <QrCode className="w-4 h-4 text-slate-950" />
            <span>Launch Optical QR Scanner</span>
          </button>

          {/* Nav List */}
          <div className="text-[11px] font-mono uppercase tracking-wider text-slate-500 px-2 mb-2">
            Navigation Menu
          </div>
          <nav className="space-y-1">
            {menuItems.map((item) => {
              const Icon = item.icon;
              const isActive = currentTab === item.id;

              return (
                <button
                  key={item.id}
                  onClick={() => handleSelect(item.id)}
                  className={`w-full flex items-center justify-between px-3.5 py-3 rounded-xl text-xs font-mono transition-all text-left ${
                    isActive
                      ? 'bg-[#FF6B00]/15 text-[#FF6B00] border border-[#FF6B00]/40 font-semibold'
                      : 'text-slate-300 hover:text-white hover:bg-white/5'
                  }`}
                >
                  <div className="flex items-center space-x-3">
                    <Icon className="w-4 h-4" />
                    <span>{item.label}</span>
                  </div>
                  <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-white/5 text-slate-400">
                    {item.badge}
                  </span>
                </button>
              );
            })}
          </nav>
        </div>

        {/* Bottom Card */}
        <div className="pt-6 border-t border-white/10 mt-6 space-y-3">
          <button
            onClick={() => {
              openBreakdownModal();
              onClose();
            }}
            className="w-full py-2 px-3 rounded-xl bg-rose-500/15 border border-rose-500/30 text-rose-300 hover:bg-rose-500/20 text-xs font-mono flex items-center justify-center space-x-2"
          >
            <Wrench className="w-3.5 h-3.5" />
            <span>Signaler Panne Matériel</span>
          </button>

          <div className="p-3 rounded-xl bg-black/40 border border-white/5 text-[11px] font-mono text-slate-400 flex items-center justify-between">
            <span className="flex items-center space-x-1.5">
              <Server className="w-3 h-3 text-cyan-400" />
              <span>Lab Node 01</span>
            </span>
            <span className="text-emerald-400 font-semibold">ONLINE</span>
          </div>
        </div>

      </aside>
    </div>
  );
};
