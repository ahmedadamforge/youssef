import { useState, useRef, useCallback, useEffect } from 'react';
import { SerialLogMessage } from '../types';

export function useWebSerial() {
  const [isConnected, setIsConnected] = useState<boolean>(false);
  const [isSimulated, setIsSimulated] = useState<boolean>(false);
  const [portDetails, setPortDetails] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [logs, setLogs] = useState<SerialLogMessage[]>([]);
  const [isSupported, setIsSupported] = useState<boolean>(true);

  const portRef = useRef<any>(null);
  const readerRef = useRef<ReadableStreamDefaultReader<string> | null>(null);
  const writerRef = useRef<WritableStreamDefaultWriter<string> | null>(null);
  const keepReadingRef = useRef<boolean>(false);
  const simIntervalRef = useRef<any>(null);

  useEffect(() => {
    if (typeof window !== 'undefined' && !('serial' in navigator)) {
      setIsSupported(false);
    }
  }, []);

  const appendLog = useCallback((type: 'TX' | 'RX' | 'SYS', data: string) => {
    const now = new Date();
    const timeStr = now.toLocaleTimeString('en-GB', { hour12: false }) + '.' + String(now.getMilliseconds()).padStart(3, '0');
    const newMsg: SerialLogMessage = {
      id: Math.random().toString(36).substring(2, 9),
      timestamp: timeStr,
      type,
      data: data.trim(),
    };
    setLogs((prev) => [...prev.slice(-250), newMsg]);
  }, []);

  const connect = async (baudRate: number = 115200) => {
    setError(null);
    if (isSimulated) {
      disconnect();
    }

    try {
      if (!('serial' in navigator)) {
        throw new Error('Web Serial API is not available on this browser. Launching Simulation Mode instead.');
      }

      const port = await (navigator as any).serial.requestPort();
      await port.open({ baudRate });

      portRef.current = port;
      setIsConnected(true);
      setIsSimulated(false);

      const info = port.getInfo();
      const usbVendor = info.usbVendorId ? `USB: 0x${info.usbVendorId.toString(16).toUpperCase()}` : 'Microcontroller USB';
      setPortDetails(`${usbVendor} @ ${baudRate} BAUD`);
      appendLog('SYS', `[HARDWARE] Connected to ${usbVendor} at ${baudRate} BAUD.`);
      appendLog('SYS', `SYS: CMC TESTBENCH READY [v2.4 - ROBOTICS.MA]`);

      const textDecoder = new TextDecoderStream();
      port.readable.pipeTo(textDecoder.writable);
      const reader = textDecoder.readable.getReader();
      readerRef.current = reader;

      const textEncoder = new TextEncoderStream();
      textEncoder.readable.pipeTo(port.writable);
      writerRef.current = textEncoder.writable.getWriter();

      keepReadingRef.current = true;
      readLoop(reader);
    } catch (err: any) {
      if (err.name === 'NotFoundError') {
        // User cancelled port picker, do not error loudly
        return;
      }
      setError(err.message || 'Failed to open serial port');
      // If Web Serial fails or user wants simulation, offer simulated connection
      appendLog('SYS', `Notice: ${err.message}. You can switch to Simulated Bench.`);
    }
  };

  const connectSimulation = (baudRate: number = 115200) => {
    disconnect();
    setIsConnected(true);
    setIsSimulated(true);
    setPortDetails(`ESP32-S3 SIMULATOR @ ${baudRate} BAUD`);
    appendLog('SYS', `[SIMULATOR] Bench Emulator active (Virtual MCU at ${baudRate} BAUD).`);
    appendLog('SYS', `SYS: CMC TESTBENCH READY [v2.4 - ROBOTICS.MA]`);
    appendLog('RX', `{"boot":"ESP32-S3-WROOM-1","cpu_mhz":240,"status":"READY"}`);
  };

  const readLoop = async (reader: ReadableStreamDefaultReader<string>) => {
    let buffer = '';
    try {
      while (keepReadingRef.current) {
        const { value, done } = await reader.read();
        if (done) break;
        if (value) {
          buffer += value;
          const lines = buffer.split('\n');
          buffer = lines.pop() || '';
          for (const line of lines) {
            if (line.trim().length > 0) {
              appendLog('RX', line);
            }
          }
        }
      }
    } catch (err: any) {
      if (keepReadingRef.current) {
        appendLog('SYS', `Stream Read Error: ${err.message}`);
      }
    } finally {
      reader.releaseLock();
    }
  };

  const sendCommand = async (command: string) => {
    if (!isConnected) {
      appendLog('SYS', 'Cannot send: Serial port is not connected.');
      return;
    }

    appendLog('TX', command);

    if (isSimulated) {
      // Simulate authentic microcontroller responses
      handleSimulatedCommand(command);
      return;
    }

    if (writerRef.current) {
      try {
        await writerRef.current.write(command + '\r\n');
      } catch (err: any) {
        appendLog('SYS', `Write Error: ${err.message}`);
      }
    }
  };

  const handleSimulatedCommand = (cmd: string) => {
    setTimeout(() => {
      const clean = cmd.trim().toUpperCase();

      if (clean === 'PING') {
        appendLog('RX', 'PONG: TESTBENCH_ONLINE [LATENCY: 2ms]');
      } else if (clean === 'STATUS') {
        appendLog('RX', '{"vcc":5.02,"temperature_c":29.4,"i2c_bus":"OK","timer":"NOMINAL"}');
      } else if (clean === 'RESET') {
        appendLog('SYS', 'SYS: REBOOT OK. Firmware v2.4 initialized.');
      } else if (clean.startsWith('TEST:HC_SR04') || clean === 'TEST:HC_SR04') {
        const simulatedDist = (Math.random() * 80 + 12).toFixed(1);
        appendLog('RX', `{"sensor":"HC_SR04","status":"OK","dist":${simulatedDist},"echo_us":${Math.round(Number(simulatedDist) * 58)}}`);
      } else if (clean.startsWith('TEST:SERVO') || clean.startsWith('SERVO:')) {
        let angle = 90;
        if (clean.includes(':')) {
          const parts = clean.split(':');
          const last = parseInt(parts[parts.length - 1]);
          if (!isNaN(last)) angle = last;
        }
        appendLog('RX', `{"sensor":"SERVO_MG996R","status":"OK","angle":${angle},"pwm_pulse_us":${1000 + Math.round((angle / 180) * 1000)}}`);
      } else if (clean.startsWith('SCAN:I2C') || clean === 'I2C:SCAN') {
        appendLog('SYS', 'SYS: Scanning I2C Bus (0x01 - 0x7E)...');
        setTimeout(() => {
          appendLog('RX', 'SYS: I2C device detected at address 0x68 (MPU-6050 6-DOF IMU)');
          appendLog('RX', 'SYS: I2C device detected at address 0x3C (SSD1306 0.96" OLED Display)');
          appendLog('RX', '{"sensor":"I2C_BUS","status":"OK","devices":2,"bus_speed_khz":400}');
        }, 300);
      } else if (clean.startsWith('TEST:PINS')) {
        appendLog('RX', '{"pins":{"D2":"HIGH","D3":"HIGH","D4":"HIGH","D5":"HIGH"},"status":"OK","verdict":"PASS"}');
      } else {
        appendLog('RX', `ACK: ${cmd} (processed by virtual MCU)`);
      }
    }, 150);
  };

  const disconnect = async () => {
    keepReadingRef.current = false;
    if (simIntervalRef.current) {
      clearInterval(simIntervalRef.current);
      simIntervalRef.current = null;
    }

    try {
      if (readerRef.current) {
        await readerRef.current.cancel();
        readerRef.current = null;
      }
      if (writerRef.current) {
        await writerRef.current.close();
        writerRef.current = null;
      }
      if (portRef.current) {
        await portRef.current.close();
        portRef.current = null;
      }
    } catch (err: any) {
      // Ignored during cleanup
    }

    setIsConnected(false);
    setIsSimulated(false);
    setPortDetails(null);
    appendLog('SYS', 'Disconnected from serial device.');
  };

  const clearLogs = () => {
    setLogs([]);
  };

  return {
    isSupported,
    isConnected,
    isSimulated,
    portDetails,
    error,
    logs,
    connect,
    connectSimulation,
    disconnect,
    sendCommand,
    clearLogs,
    appendLog,
  };
}
