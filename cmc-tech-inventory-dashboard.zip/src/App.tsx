import React, { useState } from 'react';
import { Navbar } from './components/Navbar';
import { Sidebar } from './components/Sidebar';
import { DashboardView } from './components/views/DashboardView';
import { InventoryView } from './components/views/InventoryView';
import { CircuitTesterView } from './components/views/CircuitTesterView';
import { DisplayStudioView } from './components/views/DisplayStudioView';
import { ProjectsView } from './components/views/ProjectsView';
import { EventsView } from './components/views/EventsView';
import { LeaderboardView } from './components/views/LeaderboardView';
import { ProjectExplorerView } from './components/views/ProjectExplorerView';

import { QRScannerModal } from './components/modals/QRScannerModal';
import { NewItemModal } from './components/modals/NewItemModal';
import { BorrowModal } from './components/modals/BorrowModal';
import { ReportBreakdownModal } from './components/modals/ReportBreakdownModal';

import { 
  INITIAL_INVENTORY, 
  INITIAL_PROJECTS, 
  INITIAL_EVENTS, 
  INITIAL_MEMBERS 
} from './data/mockData';
import { InventoryItem, ProjectBot, ClubEvent, MemberProfile } from './types';
import { useWebSerial } from './hooks/useWebSerial';

export default function App() {
  // Navigation & View State
  const [currentTab, setCurrentTab] = useState<string>('dashboard');
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState<boolean>(false);

  // Modals
  const [isScannerOpen, setIsScannerOpen] = useState<boolean>(false);
  const [isNewItemOpen, setIsNewItemOpen] = useState<boolean>(false);
  const [isBreakdownOpen, setIsBreakdownOpen] = useState<boolean>(false);
  const [borrowingItem, setBorrowingItem] = useState<InventoryItem | null>(null);
  const [selectedItemForTest, setSelectedItemForTest] = useState<InventoryItem | null>(null);

  // Application Data States
  const [inventory, setInventory] = useState<InventoryItem[]>(INITIAL_INVENTORY);
  const [projects] = useState<ProjectBot[]>(INITIAL_PROJECTS);
  const [events, setEvents] = useState<ClubEvent[]>(INITIAL_EVENTS);
  const [members, setMembers] = useState<MemberProfile[]>(INITIAL_MEMBERS);

  // Web Serial API Hook (Shared across App)
  const {
    isSupported,
    isConnected,
    isSimulated,
    portDetails,
    error: serialError,
    logs: serialLogs,
    connect,
    connectSimulation,
    disconnect,
    sendCommand,
    clearLogs,
    appendLog,
  } = useWebSerial();

  // Handlers for Inventory & Borrowing
  const handleAddItem = (newItem: Omit<InventoryItem, 'id'>) => {
    const itemWithId: InventoryItem = {
      ...newItem,
      id: `inv-${Date.now()}`,
    };
    setInventory((prev) => [itemWithId, ...prev]);
    appendLog('SYS', `Nouveau composant enregistré : [${itemWithId.sku}] ${itemWithId.name}`);
  };

  const handleConfirmBorrow = (itemId: string, borrowerName: string, projectName: string) => {
    setInventory((prev) =>
      prev.map((item) => {
        if (item.id === itemId && item.available > 0) {
          const newAvail = item.available - 1;
          return {
            ...item,
            available: newAvail,
            status: newAvail === 0 ? 'BORROWED' : item.status,
            borrower: borrowerName,
            borrowedAt: "À l'instant",
          };
        }
        return item;
      })
    );

    const it = inventory.find((i) => i.id === itemId);
    if (it) {
      appendLog('SYS', `Emprunt validé : ${it.name} (${it.sku}) -> ${borrowerName} pour ${projectName}`);
    }
  };

  const handleReturnItem = (itemId: string) => {
    setInventory((prev) =>
      prev.map((item) => {
        if (item.id === itemId && item.available < item.stock) {
          const newAvail = item.available + 1;
          return {
            ...item,
            available: newAvail,
            status: 'AVAILABLE',
            borrower: undefined,
            borrowedAt: undefined,
          };
        }
        return item;
      })
    );

    const it = inventory.find((i) => i.id === itemId);
    if (it) {
      appendLog('SYS', `Restitution validée : ${it.name} (${it.sku}) remis au tiroir ${it.location}`);
    }
  };

  const handleReportBreakdown = (
    sku: string,
    severity: 'Critical' | 'Moderate' | 'Minor',
    desc: string,
    reporter: string
  ) => {
    setInventory((prev) =>
      prev.map((item) => {
        if (item.sku === sku) {
          return { ...item, status: 'FAULTY' };
        }
        return item;
      })
    );
    appendLog('SYS', `ALERTE PANNE [${severity}] sur ${sku} par ${reporter} : ${desc}`);
    alert(`Signalement de panne transmis à la Cellule Technique pour ${sku}. Statut mis à jour.`);
  };

  const handleGrantXP = (memberId: string, points: number, reason: string) => {
    setMembers((prev) =>
      prev.map((m) => {
        if (m.id === memberId) {
          return {
            ...m,
            points: m.points + points,
            recentActivity: reason,
          };
        }
        return m;
      })
    );
    appendLog('SYS', `XP attribué : +${points} XP à un membre pour "${reason}"`);
  };

  const handleRegisterEvent = (eventId: string, memberName: string) => {
    setEvents((prev) =>
      prev.map((ev) => {
        if (ev.id === eventId && ev.slotsRemaining > 0) {
          return {
            ...ev,
            slotsRemaining: ev.slotsRemaining - 1,
            registeredMembers: [...ev.registeredMembers, memberName],
          };
        }
        return ev;
      })
    );
    appendLog('SYS', `Inscription événement : ${memberName} inscrit`);
  };

  const handleTestOnBench = (item: InventoryItem) => {
    setSelectedItemForTest(item);
    setCurrentTab('circuit-tester');
  };

  return (
    <div className="min-h-screen bg-[#070B14] text-slate-100 flex flex-col font-sans selection:bg-[#FF6B00] selection:text-black">
      
      {/* Top Navigation */}
      <Navbar
        currentTab={currentTab}
        setCurrentTab={setCurrentTab}
        openScanner={() => setIsScannerOpen(true)}
        openMobileMenu={() => setIsMobileMenuOpen(true)}
        isSerialActive={isConnected}
      />

      {/* Mobile Drawer */}
      <Sidebar
        isOpen={isMobileMenuOpen}
        onClose={() => setIsMobileMenuOpen(false)}
        currentTab={currentTab}
        setCurrentTab={setCurrentTab}
        openScanner={() => setIsScannerOpen(true)}
        openBreakdownModal={() => setIsBreakdownOpen(true)}
        totalComponents={inventory.reduce((a, b) => a + b.stock, 0)}
      />

      {/* Main View Container */}
      <main className="flex-1 max-w-7xl w-full mx-auto p-4 sm:p-6 lg:p-8">
        {currentTab === 'dashboard' && (
          <DashboardView
            inventory={inventory}
            onOpenScanner={() => setIsScannerOpen(true)}
            onOpenNewItem={() => setIsNewItemOpen(true)}
            onOpenBreakdown={() => setIsBreakdownOpen(true)}
            onNavigateTab={setCurrentTab}
            onInspectItem={(item) => handleTestOnBench(item)}
            terminalLogs={serialLogs}
          />
        )}

        {currentTab === 'inventory' && (
          <InventoryView
            inventory={inventory}
            onOpenNewItem={() => setIsNewItemOpen(true)}
            onOpenBreakdown={() => setIsBreakdownOpen(true)}
            onOpenBorrow={(item) => setBorrowingItem(item)}
            onReturnItem={handleReturnItem}
            onTestOnBench={handleTestOnBench}
          />
        )}

        {currentTab === 'circuit-tester' && (
          <CircuitTesterView
            isSupported={isSupported}
            isConnected={isConnected}
            isSimulated={isSimulated}
            portDetails={portDetails}
            error={serialError}
            logs={serialLogs}
            connect={connect}
            connectSimulation={connectSimulation}
            disconnect={disconnect}
            sendCommand={sendCommand}
            clearLogs={clearLogs}
            inventory={inventory}
            selectedItemForTest={selectedItemForTest}
          />
        )}

        {currentTab === 'affichage' && (
          <DisplayStudioView
            onSendCommand={sendCommand}
            isSerialConnected={isConnected}
          />
        )}

        {currentTab === 'projects' && (
          <ProjectsView projects={projects} />
        )}

        {currentTab === 'events' && (
          <EventsView
            events={events}
            onRegisterEvent={handleRegisterEvent}
          />
        )}

        {currentTab === 'leaderboard' && (
          <LeaderboardView
            members={members}
            onAddPoints={handleGrantXP}
          />
        )}

        {currentTab === 'project-folder' && (
          <ProjectExplorerView />
        )}
      </main>

      {/* Universal Footer */}
      <footer className="border-t border-white/5 bg-[#070B14]/90 backdrop-blur-xl py-6 px-4 text-xs font-mono text-slate-500 mt-auto">
        <div className="max-w-7xl mx-auto flex flex-col md:flex-row items-center justify-between gap-4">
          <div className="flex items-center space-x-2">
            <span className="font-['Orbitron'] font-bold text-[#FF6B00]">robotics.ma</span>
            <span>—</span>
            <span>CMC Robotique Rabat • Cellule Technique (Session 2026/2027)</span>
          </div>

          <div className="flex items-center space-x-5">
            <button
              onClick={() => setCurrentTab('affichage')}
              className="hover:text-cyan-400 transition-colors"
            >
              Écrans & Affichage
            </button>
            <button
              onClick={() => setCurrentTab('circuit-tester')}
              className="hover:text-cyan-400 transition-colors"
            >
              Web Serial API
            </button>
            <button
              onClick={() => setCurrentTab('project-folder')}
              className="hover:text-cyan-400 transition-colors"
            >
              Export Monorepo
            </button>
            <span className="text-emerald-400 font-semibold">Banc Opérationnel</span>
          </div>
        </div>
      </footer>

      {/* Global Modals */}
      <QRScannerModal
        isOpen={isScannerOpen}
        onClose={() => setIsScannerOpen(false)}
        inventory={inventory}
        onOpenBorrow={(item) => setBorrowingItem(item)}
        onReturnItem={handleReturnItem}
        onTestOnBench={handleTestOnBench}
      />

      <NewItemModal
        isOpen={isNewItemOpen}
        onClose={() => setIsNewItemOpen(false)}
        onAddItem={handleAddItem}
      />

      <BorrowModal
        item={borrowingItem}
        isOpen={!!borrowingItem}
        onClose={() => setBorrowingItem(null)}
        onConfirmBorrow={handleConfirmBorrow}
      />

      <ReportBreakdownModal
        isOpen={isBreakdownOpen}
        onClose={() => setIsBreakdownOpen(false)}
        inventory={inventory}
        onSubmitReport={handleReportBreakdown}
      />

    </div>
  );
}
