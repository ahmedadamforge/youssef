import { InventoryItem, ProjectBot, ClubEvent, MemberProfile, BreakdownReport } from '../types';

export const INITIAL_INVENTORY: InventoryItem[] = [
  {
    id: 'inv-1',
    sku: 'SKU-ESP-9042',
    name: 'ESP32-WROOM-32D Dual-Core',
    category: 'Microcontrollers',
    stock: 16,
    available: 7,
    status: 'BORROWED',
    location: 'Tiroir A-01',
    borrower: 'Anas M.',
    borrowedAt: '15 mins ago',
    specs: '240MHz, Wi-Fi & BLE, 520KB SRAM',
    voltage: '3.3V',
  },
  {
    id: 'inv-2',
    sku: 'SKU-LDR-1102',
    name: 'RPLiDAR A1 360° Laser Scanner',
    category: 'Sensors',
    stock: 4,
    available: 3,
    status: 'AVAILABLE',
    location: 'Armoire B-02',
    specs: '12m range, 5.5Hz - 10Hz scan rate, 8000 samples/s',
    voltage: '5V',
  },
  {
    id: 'inv-3',
    sku: 'SKU-SRV-8820',
    name: 'Dynamixel MX-28T Smart Servo',
    category: 'Actuators',
    stock: 8,
    available: 0,
    status: 'FAULTY',
    location: 'Bay Triage 01',
    borrower: 'Karim L.',
    borrowedAt: 'Yesterday',
    specs: 'TTL Multi-drop Bus, 2.5 N.m torque, 12V DC',
    voltage: '12V',
  },
  {
    id: 'inv-4',
    sku: 'SKU-NV-0044',
    name: 'NVIDIA Jetson Nano 4GB Dev Kit',
    category: 'Microcontrollers',
    stock: 3,
    available: 1,
    status: 'BORROWED',
    location: 'Locker B-04',
    borrower: 'Sara E.',
    borrowedAt: 'Oct 28',
    specs: '128-core Maxwell GPU, Quad-core ARM A57',
    voltage: '5V / 4A',
  },
  {
    id: 'inv-5',
    sku: 'SKU-STM-4460',
    name: 'STM32 Nucleo-F446RE',
    category: 'Microcontrollers',
    stock: 12,
    available: 9,
    status: 'AVAILABLE',
    location: 'Tiroir A-03',
    specs: 'ARM Cortex-M4 180MHz with FPU, 512KB Flash',
    voltage: '3.3V / 5V',
  },
  {
    id: 'inv-6',
    sku: 'SKU-SNS-HC04',
    name: 'Ultrasonic Sensor HC-SR04+',
    category: 'Sensors',
    stock: 35,
    available: 26,
    status: 'AVAILABLE',
    location: 'Tiroir B-01',
    specs: '2cm - 400cm non-contact range, 15° angle',
    voltage: '3.3V - 5V',
  },
  {
    id: 'inv-7',
    sku: 'SKU-ACT-996R',
    name: 'TowerPro MG996R Metal Gear Servo',
    category: 'Actuators',
    stock: 24,
    available: 18,
    status: 'AVAILABLE',
    location: 'Tiroir C-02',
    specs: '11 kg-cm torque at 6V, metal gear train',
    voltage: '4.8V - 6.6V',
  },
  {
    id: 'inv-8',
    sku: 'SKU-PWR-4S15',
    name: 'Gens Ace LiPo 4S 14.8V 1500mAh 100C',
    category: 'Power',
    stock: 6,
    available: 2,
    status: 'BORROWED',
    location: 'Lipo Fire Safe Bay',
    borrower: 'Combat Team',
    borrowedAt: '2 days ago',
    specs: 'XT60 connector, 100C continuous discharge',
    voltage: '14.8V',
  },
  {
    id: 'inv-9',
    sku: 'SKU-SNS-MPU6',
    name: 'MPU-6050 6-DOF IMU Gyro + Accel',
    category: 'Sensors',
    stock: 18,
    available: 14,
    status: 'AVAILABLE',
    location: 'Tiroir B-04',
    specs: 'I2C digital output, integrated DMP motion processor',
    voltage: '3.3V - 5V',
  },
  {
    id: 'inv-10',
    sku: 'SKU-DRV-BTS7',
    name: 'BTS7960 43A High-Power H-Bridge Driver',
    category: 'Actuators',
    stock: 10,
    available: 7,
    status: 'AVAILABLE',
    location: 'Tiroir C-04',
    specs: 'Dual BTS7960 chips, up to 43A peak current',
    voltage: '6V - 27V',
  },
  {
    id: 'inv-11',
    sku: 'SKU-COM-SX12',
    name: 'LoRa SX1278 433MHz Transceiver',
    category: 'Communication',
    stock: 8,
    available: 5,
    status: 'AVAILABLE',
    location: 'Tiroir D-01',
    specs: '+20 dBm output, range up to 5km line of sight',
    voltage: '3.3V',
  },
  {
    id: 'inv-12',
    sku: 'SKU-TOOL-LA24',
    name: 'USB Logic Analyzer 24MHz 8-Channel',
    category: 'Lab Tools',
    stock: 5,
    available: 4,
    status: 'AVAILABLE',
    location: 'Armoire Outils Bench',
    specs: 'Compatible with Sigrok / PulseView software',
    voltage: '5V USB',
  },
];

export const INITIAL_PROJECTS: ProjectBot[] = [
  {
    id: 'bot-atlas',
    title: 'ATLAS ROVER 4WD',
    category: 'ROVER',
    categoryLabel: 'Autonomous Search & Rescue',
    team: ['Yassine Benali', 'Anas Mansouri', 'Sara El Amrani'],
    description: 'Plateforme mobile tout-terrain autonome équipée de suspension boggie-rocker, LiDAR 360° et vision par ordinateur stéréoscopique pour la cartographie SLAM en environnement confiné.',
    status: 'National Winner',
    specs: {
      compute: 'NVIDIA Jetson Orin Nano + STM32F446RE',
      actuation: '4x Planetary Gear DC Motors 24V 300RPM (Encoder feedback)',
      power: 'LiFePO4 24V 10Ah (BMS auto-protection)',
      sensors: 'RPLiDAR A1 360°, Intel RealSense D435i, IMU MPU-6050',
      weight: '8.4 kg',
      dimensions: '480 x 360 x 280 mm',
    },
    tags: ['ROS2 Humble', 'SLAM Navigation', 'Stereo Depth', 'Micro-ROS'],
    lead: 'Yassine B.',
    features: [
      'Cartographie 2D/3D temps réel avec slam_toolbox',
      'Évitement autonome d’obstacles dynamiques',
      'Télémétrie sans fil longue portée LoRa 433MHz',
      'Châssis aluminium usiné sur fraiseuse CNC CMC',
    ],
  },
  {
    id: 'bot-cerberus',
    title: 'CERBERUS COMBAT 3KG',
    category: 'COMBAT',
    categoryLabel: 'Beetleweight Battlebot',
    team: ['Anas Mansouri', 'Karim Lazrak'],
    description: 'Robot de combat haute puissance muni d’un tambour rotatif horizontal asymétrique en acier trempé Hardox 500 tournant à 14,000 RPM avec énergie d’impact destructrice.',
    status: 'Competition Ready',
    specs: {
      compute: 'Custom ATmega328P avec protection opto-isolée',
      actuation: 'Weapon: Brushless 3548 1100KV / Drive: 2x Repeat Robotics Planetary',
      power: 'LiPo 4S 1500mAh 100C Graphene',
      sensors: 'Capteurs de choc piezocéramiques, Fail-Safe RF 2.4GHz',
      weight: '2.98 kg',
      dimensions: '290 x 260 x 110 mm',
    },
    tags: ['Battlebot', 'Brushless Weapon', 'Hardox 500', 'Kinetic Energy'],
    lead: 'Anas M.',
    features: [
      'Tambour d’impact 1.1 kg usiné avec équilibrage dynamique',
      'Blindage sandwich Titane Grade 5 & UHMW Polyéthylène',
      'Système d’inversion automatique en cas de retournement',
      'Coupure d’urgence magnétique obligatoire de sécurité',
    ],
  },
  {
    id: 'bot-bionic',
    title: 'BIONIC HAND CMC-V2',
    category: 'BIONIC',
    categoryLabel: 'Myoelectric Prosthesis',
    team: ['Sara El Amrani', 'Mehdi Tazi', 'Yassine Benali'],
    description: 'Prothèse myoélectrique anthropomorphe imprimée en 3D SLS avec classification des gestes par réseau de neurones embarqué traitant les signaux EMG de l’avant-bras.',
    status: 'In Testing',
    specs: {
      compute: 'ESP32-S3 Dual-Core AI Accelerator (TinyML)',
      actuation: '5x Micro Metal Gear Actuators avec capteurs de courant',
      power: 'Li-ion 2S 7.4V 2200mAh',
      sensors: '4-Channel MyoWare 2.0 EMG + capteurs de pression piézorésistifs',
      weight: '440 g',
      dimensions: 'Échelle 1:1 main humaine adulte',
    },
    tags: ['EMG Myoelectric', 'TinyML TensorFlow Lite', 'Haptic Touch', '3D Printed'],
    lead: 'Sara E.',
    features: [
      'Reconnaissance de 8 prises distinctes (pince fine, poignée, clé, etc.)',
      'Boucle de rétroaction haptique pour éviter d’écraser les objets fragiles',
      'Autonomie continue de 14 heures en usage normal',
      'Application mobile compagnon Bluetooth pour calibrer les seuils EMG',
    ],
  },
  {
    id: 'bot-vortex',
    title: 'VORTEX HEXACOPTER AI',
    category: 'DRONE',
    categoryLabel: 'Autonomous Inspection Drone',
    team: ['Mehdi Tazi', 'Karim Lazrak'],
    description: 'Drone hexacoptère de reconnaissance en milieu industriel avec suivi visuel d’actifs et atterrissage de précision sur cible optique QR Code.',
    status: 'Fabrication',
    specs: {
      compute: 'Raspberry Pi 5 + Pixhawk 6C Flight Controller',
      actuation: '6x T-Motor F60 Pro 2550KV Brushless Motors',
      power: 'LiPo 6S 4500mAh',
      sensors: 'Caméra Global Shutter, Lidar unidirectionnel TF-Mini, Flux optique',
      weight: '1.85 kg',
      dimensions: 'Envergure 550 mm diagonale',
    },
    tags: ['PX4 Autopilot', 'Optical Flow', 'Precision Landing', 'Edge AI'],
    lead: 'Mehdi T.',
    features: [
      'Contrôle automatique de trajectoire sous pilote PX4 et ArduPilot',
      'Détection automatique de fissures et tags de maintenance par IA',
      'Gimbal 2 axes stabilisé pour flux vidéo ultra-fluide',
      'Balise de secours GPS intégrée',
    ],
  },
];

export const INITIAL_EVENTS: ClubEvent[] = [
  {
    id: 'ev-1',
    title: 'NATIONAL HACKATHON CMC ROBOTICS 2026',
    type: 'National Hackathon',
    date: '14 - 15 Novembre 2026',
    location: 'Grand Hall CMC Rabat',
    slotsTotal: 40,
    slotsRemaining: 12,
    description: '48 heures non-stop de défi mécatronique intense : concevoir et programmer en équipe un robot mobile autonome capable de trier des colis d’entrepôt logistique.',
    registeredMembers: ['Yassine Benali', 'Anas Mansouri', 'Sara El Amrani', 'Mehdi Tazi'],
  },
  {
    id: 'ev-2',
    title: 'WORKSHOP : ROS2 & Micro-ROS sur ESP32',
    type: 'Hands-on Training',
    date: '22 Novembre 2026',
    location: 'Laboratoire Technique Bay 02',
    slotsTotal: 20,
    slotsRemaining: 5,
    description: 'Atelier pratique de publication/souscription de topics ROS2 depuis un microcontrôleur ESP32 via Micro-XRCE-DDS et pilotage de moteurs pas-à-pas.',
    registeredMembers: ['Karim Lazrak', 'Hiba Kabbaj'],
  },
  {
    id: 'ev-3',
    title: 'COMBAT BOT SCRIMMAGE : ARENA CLASH',
    type: 'Internal Arena Clash',
    date: '05 Décembre 2026',
    location: 'Arène blindée Club Robotique',
    slotsTotal: 16,
    slotsRemaining: 7,
    description: 'Combats d’échauffement et tests de résistance pour les robots 3kg avant le championnat national marocain de robotique de combat.',
    registeredMembers: ['Anas Mansouri', 'Omar Chraibi'],
  },
  {
    id: 'ev-4',
    title: 'SESSION EMBEDDED AI & OPENCV SUR JETSON',
    type: 'Tech Talk',
    date: '12 Décembre 2026',
    location: 'Amphi Innovation CMC',
    slotsTotal: 50,
    slotsRemaining: 28,
    description: 'Pipeline de traitement vidéo temps réel à 60 FPS avec accélération TensorRT et inférence de modèles YOLOv8 nano pour la détection de cibles.',
    registeredMembers: ['Sara El Amrani'],
  },
];

export const INITIAL_MEMBERS: MemberProfile[] = [
  {
    id: 'mem-1',
    rank: 1,
    name: 'Yassine Benali',
    role: 'Chef de Cellule Technique',
    cellule: 'Mécatronique',
    points: 2840,
    robotsCount: 6,
    badge: 'Master Architect',
    avatarLetter: 'YB',
    recentActivity: 'Validé calibration SLAM sur Atlas Rover 4WD',
  },
  {
    id: 'mem-2',
    rank: 2,
    name: 'Anas Mansouri',
    role: 'Hardware & Power Specialist',
    cellule: 'Embedded & IoT',
    points: 2410,
    robotsCount: 4,
    badge: 'Firmware Guru',
    avatarLetter: 'AM',
    recentActivity: 'Test banc de puissance Brushless 14,000 RPM',
  },
  {
    id: 'mem-3',
    rank: 3,
    name: 'Sara El Amrani',
    role: 'AI & Computer Vision Lead',
    cellule: 'IA & Vision',
    points: 2190,
    robotsCount: 3,
    badge: 'Neural Ninja',
    avatarLetter: 'SE',
    recentActivity: 'Entraînement modèle TinyML pour main bionique',
  },
  {
    id: 'mem-4',
    rank: 4,
    name: 'Karim Lazrak',
    role: '3D CAD & CNC Machinist',
    cellule: 'Conception 3D',
    points: 1850,
    robotsCount: 2,
    badge: 'CAD Titan',
    avatarLetter: 'KL',
    recentActivity: 'Usinage pièces aluminium Châssis Cerberus',
  },
  {
    id: 'mem-5',
    rank: 5,
    name: 'Mehdi Tazi',
    role: 'Avionics & Embedded Dev',
    cellule: 'Embedded & IoT',
    points: 1420,
    robotsCount: 1,
    badge: 'Serial Hacker',
    avatarLetter: 'MT',
    recentActivity: 'Configuration bus CAN sur Hexacopter',
  },
];

export const INITIAL_BREAKDOWNS: BreakdownReport[] = [
  {
    id: 'brk-1',
    itemSku: 'SKU-SRV-8820',
    itemName: 'Dynamixel MX-28T Smart Servo',
    reportedBy: 'Karim L.',
    date: 'Hier à 17:40',
    severity: 'Critical',
    description: 'Surchauffe du pont en H interne suite à blocage mécanique pendant test d’effort de préhension.',
    status: 'Under Triage',
  },
  {
    id: 'brk-2',
    itemSku: 'SKU-PWR-4S15',
    itemName: 'LiPo 4S 1500mAh #LP-03',
    reportedBy: 'Anas M.',
    date: 'Il y a 3 jours',
    severity: 'Moderate',
    description: 'Déséquilibre de tension sur la cellule 3 (3.1V vs 3.8V). Mise en quarantaine pour charge lente d’équilibrage.',
    status: 'Parts Ordered',
  },
];

// Full Monorepo Project Structure & Files content to fulfill user request "3tini folder d projet kaml"
export const MONOREPO_PROJECT_FILES: { path: string; language: string; description: string; content: string }[] = [
  {
    path: 'package.json',
    language: 'json',
    description: 'Turborepo root workspace configuration',
    content: `{
  "name": "robotics-ma-monorepo",
  "private": true,
  "workspaces": [
    "apps/*",
    "packages/*"
  ],
  "scripts": {
    "build": "turbo run build",
    "dev": "turbo run dev",
    "dev:web": "turbo run dev --filter=web",
    "dev:mobile": "turbo run dev --filter=mobile",
    "lint": "turbo run lint"
  },
  "devDependencies": {
    "turbo": "^2.1.0"
  },
  "packageManager": "pnpm@9.0.0"
}`,
  },
  {
    path: 'turbo.json',
    language: 'json',
    description: 'Turborepo pipeline caching rules',
    content: `{
  "$schema": "https://turbo.build/schema.json",
  "tasks": {
    "build": {
      "dependsOn": ["^build"],
      "outputs": [".next/**", "!.next/cache/**", "dist/**"]
    },
    "dev": {
      "cache": false,
      "persistent": true
    }
  }
}`,
  },
  {
    path: 'firmware/cmc_testbench_firmware.ino',
    language: 'cpp',
    description: 'Arduino / ESP32 Companion Test Bench Sketch for Web Serial Circuit Tester',
    content: `/*
 * CMC Robotique Rabat (robotics.ma) — Hardware Test Bench Firmware
 * Compatible with: Arduino Uno, Nano, ESP32, STM32 Nucleo
 * Baud Rate: 115200
 */

#include <Arduino.h>
#include <Wire.h>

#define TRIG_PIN 9
#define ECHO_PIN 10
#define SERVO_PWM_PIN 6
#define STATUS_LED_PIN 13

void setup() {
  Serial.begin(115200);
  pinMode(TRIG_PIN, OUTPUT);
  pinMode(ECHO_PIN, INPUT);
  pinMode(STATUS_LED_PIN, OUTPUT);
  Wire.begin();

  Serial.println("SYS: CMC TESTBENCH READY [v2.4 - ROBOTICS.MA]");
}

// 1. HC-SR04 Diagnostic Suite
void testUltrasonic() {
  digitalWrite(TRIG_PIN, LOW);
  delayMicroseconds(2);
  digitalWrite(TRIG_PIN, HIGH);
  delayMicroseconds(10);
  digitalWrite(TRIG_PIN, LOW);

  long duration = pulseIn(ECHO_PIN, HIGH, 35000); // 35ms timeout
  if (duration == 0) {
    Serial.println("{\\"sensor\\":\\"HC_SR04\\",\\"status\\":\\"ERR\\",\\"msg\\":\\"TIMEOUT_NO_ECHO\\"}");
  } else {
    float distanceCm = duration * 0.0343 / 2.0;
    Serial.print("{\\"sensor\\":\\"HC_SR04\\",\\"status\\":\\"OK\\",\\"dist\\":");
    Serial.print(distanceCm);
    Serial.println("}");
  }
}

// 2. I2C Bus Diagnostic Scanner
void scanI2CBus() {
  byte error, address;
  int nDevices = 0;
  Serial.println("SYS: Scanning I2C Bus (0x01 - 0x7E)...");

  for (address = 1; address < 127; address++) {
    Wire.beginTransmission(address);
    error = Wire.endTransmission();

    if (error == 0) {
      Serial.print("SYS: I2C device detected at address 0x");
      if (address < 16) Serial.print("0");
      Serial.println(address, HEX);
      nDevices++;
    }
  }

  if (nDevices > 0) {
    Serial.println("{\\"sensor\\":\\"I2C_BUS\\",\\"status\\":\\"OK\\",\\"devices\\":" + String(nDevices) + "}");
  } else {
    Serial.println("{\\"sensor\\":\\"I2C_BUS\\",\\"status\\":\\"ERR\\",\\"msg\\":\\"NO_DEVICES_FOUND\\"}");
  }
}

void loop() {
  if (Serial.available() > 0) {
    String cmd = Serial.readStringUntil('\\n');
    cmd.trim();

    if (cmd == "PING") {
      Serial.println("PONG: TESTBENCH_ONLINE");
    } else if (cmd == "TEST:HC_SR04") {
      testUltrasonic();
    } else if (cmd == "SCAN:I2C") {
      scanI2CBus();
    } else if (cmd.startsWith("SERVO:")) {
      Serial.println("{\\"sensor\\":\\"SERVO\\",\\"status\\":\\"OK\\",\\"angle\\":90}");
    } else if (cmd == "RESET") {
      digitalWrite(STATUS_LED_PIN, LOW);
      Serial.println("SYS: REBOOT OK");
    } else {
      Serial.println("SYS: UNKNOWN_CMD -> " + cmd);
    }
  }
}`,
  },
  {
    path: 'packages/supabase/migrations/001_schema.sql',
    language: 'sql',
    description: 'PostgreSQL database schema for inventory and test logs',
    content: `-- Supabase Database Schema for CMC Robotique (robotics.ma)
CREATE TYPE component_status AS ENUM ('AVAILABLE', 'BORROWED', 'MAINTENANCE', 'FAULTY');
CREATE TYPE test_verdict AS ENUM ('PASSED', 'FAILED', 'INCONCLUSIVE');

-- 1. Hardware Inventory Matrix
CREATE TABLE inventory_items (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    sku VARCHAR(64) UNIQUE NOT NULL,
    name VARCHAR(255) NOT NULL,
    category VARCHAR(64) NOT NULL,
    location VARCHAR(64) DEFAULT 'Workshop Bay 01',
    status component_status DEFAULT 'AVAILABLE',
    total_qty INT DEFAULT 1,
    available_qty INT DEFAULT 1,
    borrower_name VARCHAR(128),
    borrowed_at TIMESTAMPTZ,
    created_at TIMESTAMPTZ DEFAULT NOW()
);

-- 2. Hardware Test Bench Logs (Linked to Circuit Tester)
CREATE TABLE circuit_test_logs (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    item_id UUID REFERENCES inventory_items(id) ON DELETE SET NULL,
    tester_name VARCHAR(128) NOT NULL,
    suite_type VARCHAR(64) NOT NULL,
    baud_rate INT NOT NULL,
    verdict test_verdict NOT NULL,
    telemetry_payload JSONB NOT NULL,
    raw_terminal_log TEXT,
    tested_at TIMESTAMPTZ DEFAULT NOW()
);

ALTER PUBLICATION supabase_realtime ADD TABLE circuit_test_logs;`,
  },
  {
    path: 'apps/web/hooks/useWebSerial.ts',
    language: 'typescript',
    description: 'Browser Web Serial API Hook for Arduino / ESP32 USB connectivity',
    content: `"use client";
import { useState, useRef, useCallback, useEffect } from "react";

export interface SerialMessage {
  id: string;
  timestamp: string;
  type: "TX" | "RX" | "SYS";
  data: string;
}

export function useWebSerial() {
  const [isConnected, setIsConnected] = useState<boolean>(false);
  const [portDetails, setPortDetails] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [logs, setLogs] = useState<SerialMessage[]>([]);
  const [isSupported, setIsSupported] = useState<boolean>(true);

  const portRef = useRef<any>(null);
  const readerRef = useRef<ReadableStreamDefaultReader<string> | null>(null);
  const writerRef = useRef<WritableStreamDefaultWriter<string> | null>(null);
  const keepReadingRef = useRef<boolean>(false);

  useEffect(() => {
    if (typeof window !== "undefined" && !("serial" in navigator)) {
      setIsSupported(false);
    }
  }, []);

  const appendLog = useCallback((type: "TX" | "RX" | "SYS", data: string) => {
    const newMsg: SerialMessage = {
      id: Math.random().toString(36).substring(2, 9),
      timestamp: new Date().toLocaleTimeString("en-GB", { hour12: false }) + "." + String(Date.now() % 1000).padStart(3, "0"),
      type,
      data: data.trim(),
    };
    setLogs((prev) => [...prev.slice(-300), newMsg]);
  }, []);

  const connect = async (baudRate: number = 115200) => {
    setError(null);
    try {
      if (!("serial" in navigator)) throw new Error("Web Serial is unsupported.");
      const port = await (navigator as any).serial.requestPort();
      await port.open({ baudRate });
      portRef.current = port;
      setIsConnected(true);

      const info = port.getInfo();
      const usbVendor = info.usbVendorId ? \`USB: 0x\${info.usbVendorId.toString(16)}\` : "Microcontroller";
      setPortDetails(usbVendor);
      appendLog("SYS", \`Connected to \${usbVendor} at \${baudRate} BAUD.\`);

      const textDecoder = new TextDecoderStream();
      port.readable.pipeTo(textDecoder.writable);
      const reader = textDecoder.readable.getReader();
      readerRef.current = reader;

      const textEncoder = new TextEncoderStream();
      textEncoder.readable.pipeTo(port.writable);
      writerRef.current = textEncoder.writable.getWriter();

      keepReadingRef.current = true;
      readLoop(reader);
    } catch (err: any) {
      setError(err.message || "Failed to open serial port");
      setIsConnected(false);
    }
  };

  const readLoop = async (reader: ReadableStreamDefaultReader<string>) => {
    let buffer = "";
    try {
      while (keepReadingRef.current) {
        const { value, done } = await reader.read();
        if (done) break;
        if (value) {
          buffer += value;
          const lines = buffer.split("\\n");
          buffer = lines.pop() || "";
          for (const line of lines) {
            if (line.trim().length > 0) appendLog("RX", line);
          }
        }
      }
    } catch (err: any) {
      if (keepReadingRef.current) appendLog("SYS", \`Stream Read Error: \${err.message}\`);
    } finally {
      reader.releaseLock();
    }
  };

  const sendCommand = async (command: string) => {
    if (!writerRef.current || !isConnected) return;
    try {
      appendLog("TX", command);
      await writerRef.current.write(command + "\\r\\n");
    } catch (err: any) {
      appendLog("SYS", \`Write Error: \${err.message}\`);
    }
  };

  const disconnect = async () => {
    keepReadingRef.current = false;
    try {
      if (readerRef.current) { await readerRef.current.cancel(); readerRef.current = null; }
      if (writerRef.current) { await writerRef.current.close(); writerRef.current = null; }
      if (portRef.current) { await portRef.current.close(); portRef.current = null; }
      setIsConnected(false);
      setPortDetails(null);
      appendLog("SYS", "Disconnected safely.");
    } catch (err: any) {
      setError(err.message);
    }
  };

  return { isSupported, isConnected, portDetails, error, logs, connect, disconnect, sendCommand, clearLogs: () => setLogs([]) };
}`,
  },
  {
    path: 'apps/mobile/app/(tabs)/inventory.tsx',
    language: 'typescript',
    description: 'React Native Expo mobile screen for camera QR scanning in workshop',
    content: `import React, { useState } from "react";
import { View, Text, TouchableOpacity, StyleSheet, Alert } from "react-native";
import { CameraView, useCameraPermissions } from "expo-camera";

export default function MobileInventoryScan() {
  const [permission, requestPermission] = useCameraPermissions();
  const [scanned, setScanned] = useState(false);

  if (!permission || !permission.granted) {
    return (
      <View style={styles.center}>
        <Text style={styles.text}>La caméra est nécessaire pour scanner les QR codes du matériel.</Text>
        <TouchableOpacity style={styles.btn} onPress={requestPermission}>
          <Text style={styles.btnText}>Autoriser la Caméra</Text>
        </TouchableOpacity>
      </View>
    );
  }

  const handleBarCodeScanned = ({ data }: { data: string }) => {
    setScanned(true);
    Alert.alert("Tag Détecté", \`Composant: \${data}\\nStatut: Prêt à être emprunté\`, [
      { text: "Valider Emprunt", onPress: () => setScanned(false) },
    ]);
  };

  return (
    <View style={styles.container}>
      <Text style={styles.title}>SCANNER DE COMPOSANTS CMC</Text>
      <View style={styles.cameraBox}>
        <CameraView
          style={StyleSheet.absoluteFillObject}
          onBarcodeScanned={scanned ? undefined : handleBarCodeScanned}
          barcodeScannerSettings={{ barcodeTypes: ["qr"] }}
        />
        <View style={styles.reticle} />
      </View>
      {scanned && (
        <TouchableOpacity style={styles.btn} onPress={() => setScanned(false)}>
          <Text style={styles.btnText}>Scanner à nouveau</Text>
        </TouchableOpacity>
      )}
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: "#070B14", padding: 20, paddingTop: 50 },
  center: { flex: 1, backgroundColor: "#070B14", justifyContent: "center", alignItems: "center" },
  text: { color: "#94A3B8", textAlign: "center", marginBottom: 20 },
  title: { color: "#FFFFFF", fontSize: 18, fontWeight: "bold", marginBottom: 15 },
  cameraBox: { flex: 1, borderRadius: 20, overflow: "hidden", borderWidth: 1, borderColor: "#FF6B00" },
  reticle: { position: "absolute", top: "25%", left: "15%", right: "15%", bottom: "25%", borderWidth: 2, borderColor: "#00F2FE", borderRadius: 16 },
  btn: { backgroundColor: "#FF6B00", padding: 14, borderRadius: 12, alignItems: "center", marginTop: 15 },
  btnText: { color: "#000", fontWeight: "bold" },
});`,
  },
];
