export type ComponentCategory = 'Microcontrollers' | 'Sensors' | 'Actuators' | 'Power' | 'Communication' | 'Lab Tools' | 'Displays & Screens';

export type ComponentStatus = 'AVAILABLE' | 'BORROWED' | 'MAINTENANCE' | 'FAULTY';

export type VirtualDisplayType = 'OLED_SSD1306' | 'LCD_1602' | 'SEVEN_SEG' | 'LED_MATRIX';

export interface InventoryItem {
  id: string;
  sku: string;
  name: string;
  category: ComponentCategory;
  stock: number;
  available: number;
  status: ComponentStatus;
  location: string;
  borrower?: string;
  borrowedAt?: string;
  specs?: string;
  voltage?: string;
  priceEstimate?: string;
}

export interface ProjectBot {
  id: string;
  title: string;
  category: 'ROVER' | 'COMBAT' | 'BIONIC' | 'DRONE';
  categoryLabel: string;
  team: string[];
  description: string;
  status: 'Competition Ready' | 'In Testing' | 'Fabrication' | 'National Winner';
  specs: {
    compute: string;
    actuation: string;
    power: string;
    sensors: string;
    weight: string;
    dimensions: string;
  };
  tags: string[];
  lead: string;
  features: string[];
}

export interface ClubEvent {
  id: string;
  title: string;
  type: 'National Hackathon' | 'Hands-on Training' | 'Internal Arena Clash' | 'Tech Talk';
  date: string;
  location: string;
  slotsTotal: number;
  slotsRemaining: number;
  description: string;
  registeredMembers: string[];
}

export interface MemberProfile {
  id: string;
  rank: number;
  name: string;
  role: string;
  cellule: 'Mécatronique' | 'Embedded & IoT' | 'IA & Vision' | 'Conception 3D';
  points: number;
  robotsCount: number;
  badge: string;
  avatarLetter: string;
  recentActivity: string;
}

export interface SerialLogMessage {
  id: string;
  timestamp: string;
  type: 'TX' | 'RX' | 'SYS';
  data: string;
}

export interface BreakdownReport {
  id: string;
  itemSku: string;
  itemName: string;
  reportedBy: string;
  date: string;
  severity: 'Critical' | 'Moderate' | 'Minor';
  description: string;
  status: 'Under Triage' | 'Parts Ordered' | 'Repaired';
}
